function br(e,t,n,r){return r||(e===void 0&&t===void 0&&n===void 0?"not-reported":(e??0)>0?"hit":((t??0)>0,"write"))}function yr(e){return e.cacheStatus==="n/a"||e.cacheStatus==="not-reported"?e.cacheStatus:br(e.cacheRead,e.cacheWrite,e.cacheUncached,e.cacheStatus)}var J={anthropic5mWrite:1.25,anthropic1hWrite:2,anthropicRead:.1,openaiWrite:1.25,openaiRead:.5},kr=[{test:e=>/claude-opus/i.test(e),inputPerMTok:15,outputPerMTok:75,family:"Claude Opus"},{test:e=>/claude-sonnet/i.test(e),inputPerMTok:3,outputPerMTok:15,family:"Claude Sonnet"},{test:e=>/claude-haiku/i.test(e),inputPerMTok:1,outputPerMTok:5,family:"Claude Haiku"},{test:e=>/gpt-5|o3|o4/i.test(e),inputPerMTok:10,outputPerMTok:30,family:"OpenAI reasoning"},{test:e=>/gpt-4o|gpt-4\.1/i.test(e),inputPerMTok:2.5,outputPerMTok:10,family:"GPT-4o"},{test:e=>/gpt-4/i.test(e),inputPerMTok:10,outputPerMTok:30,family:"GPT-4"}];function xr(e){return kr.find(t=>t.test(e))??null}function $e(e,t,n){if(e.cacheStatus==="n/a"||e.cacheStatus==="not-reported"||e.cacheRead===void 0&&e.cacheWrite===void 0&&e.cacheUncached===void 0)return null;let r=xr(t);if(!r)return null;let s=e.cacheRead??0,a=e.cacheWrite??0,o=e.cacheUncached??0,L=e.outputTokens??0,c=n==="anthropic"||/claude/i.test(t),p=c?e.cacheTtl==="5m"?J.anthropic5mWrite:J.anthropic1hWrite:J.openaiWrite,u=c?J.anthropicRead:J.openaiRead,l=(k,_)=>k/1e6*r.inputPerMTok*_,d=l(o,1)+l(a,p)+l(s,u)+L/1e6*r.outputPerMTok,g=l(o+a+s,1),h=l(o,1)+l(a,p)+l(s,u);return{usd:d,savedUsd:g-h,label:"estimate, list price",family:r.family}}function Te(e){let t=Math.abs(e);return t>0&&t<.01?`${e<0?"-":""}\u2248$0.01`:`\u2248$${t.toFixed(2)}`}function q(e,t){if(!e.length)return null;let n=[...e].sort((s,a)=>s-a),r=Math.ceil(t/100*n.length);return n[Math.min(n.length-1,Math.max(0,r-1))]}function Oe(e){let t=[],n=[],r=[],s=0,a=0,o=0,L=0,c=0;for(let u of e){if(u.event==="rating")continue;c++;let l=yr({cacheRead:u.cacheRead,cacheWrite:u.cacheWrite,cacheUncached:u.cacheUncached,cacheStatus:u.cacheStatus});if(l==="n/a"){typeof u.ttftMs=="number"&&r.push(u.ttftMs);continue}l!=="not-reported"&&(L++,typeof u.cacheRead=="number"&&(s+=u.cacheRead),typeof u.cacheWrite=="number"&&(a+=u.cacheWrite),typeof u.cacheUncached=="number"&&(o+=u.cacheUncached),typeof u.ttftMs=="number"&&(l==="hit"?t.push(u.ttftMs):n.push(u.ttftMs)))}let p=s+a+o;return{asks:c,reported:L,hitRate:p>0?s/p:null,tokensRead:s,tokensWrite:a,tokensUncached:o,ttftHitP50Ms:q(t,50),ttftHitP95Ms:q(t,95),ttftMissP50Ms:q(n,50),ttftMissP95Ms:q(n,95),ttftNaP50Ms:q(r,50),ttftNaP95Ms:q(r,95)}}function Ot(e){if(typeof e!="string")return null;let t=e.trim().slice(0,64);return/^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/.test(t)?t:null}function It(e){if(typeof e!="string")return null;let t=e.trim().toLowerCase().slice(0,120);return/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/i.test(t)?t:null}var X={ts:"x-metis-ts",nonce:"x-metis-nonce",device:"x-metis-device",sig:"x-metis-sig"};function Nt(e,t,n,r){return`${e}.${t}.${n}.${r}`}var ce=new TextEncoder,wr=new TextDecoder;function Ie(e){let t="";for(let n of e)t+=String.fromCharCode(n);return btoa(t)}function de(e){let t=atob(e),n=new Uint8Array(t.length);for(let r=0;r<t.length;r++)n[r]=t.charCodeAt(r);return n}function Zt(e){return Ie(e).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"")}async function ue(e){let t=typeof e=="string"?ce.encode(e):e;return[...new Uint8Array(await crypto.subtle.digest("SHA-256",t))].map(r=>r.toString(16).padStart(2,"0")).join("")}function pe(e,t){let n=e.trim();try{let r=de(n);if(r.length===32)return r}catch{}throw new Error(`${t} must be 32 bytes, base64`)}async function Ft(e,t){let n=crypto.getRandomValues(new Uint8Array(12)),r=await crypto.subtle.importKey("raw",t,"AES-GCM",!1,["encrypt"]),s=new Uint8Array(await crypto.subtle.encrypt({name:"AES-GCM",iv:n},r,ce.encode(e)));return{cipher:Ie(s),iv:Ie(n)}}async function Ut(e,t,n){let r=await crypto.subtle.importKey("raw",n,"AES-GCM",!1,["decrypt"]),s=await crypto.subtle.decrypt({name:"AES-GCM",iv:de(t)},r,de(e));return wr.decode(s)}async function Bt(e,t){return Ft(e,pe(t,"OPERATOR_PROMPT_KEY"))}async function Dt(e,t,n){return Ut(e,t,pe(n,"OPERATOR_PROMPT_KEY"))}async function Ne(e,t){return Ft(e,pe(t,"OPERATOR_VAULT_KEY"))}async function Q(e,t,n){return Ut(e,t,pe(n,"OPERATOR_VAULT_KEY"))}async function Ht(e,t){let n=t.includes("BEGIN")?t:atob(t),r=_r(n),s=await crypto.subtle.importKey("pkcs8",r,{name:"Ed25519"},!1,["sign"]),a=Zt(ce.encode(JSON.stringify(e))),o=new Uint8Array(await crypto.subtle.sign("Ed25519",s,ce.encode(a)));return`${a}.${Zt(o)}`}function _r(e){let t=e.replace(/-----BEGIN [^-]+-----/,"").replace(/-----END [^-]+-----/,"").replace(/\s+/g,""),n=de(t);return n.buffer.slice(n.byteOffset,n.byteOffset+n.byteLength)}var qt=new TextEncoder;async function me(e,t){let n=await crypto.subtle.importKey("raw",qt.encode(e),{name:"HMAC",hash:"SHA-256"},!1,["sign"]);return[...new Uint8Array(await crypto.subtle.sign("HMAC",n,qt.encode(t)))].map(s=>s.toString(16).padStart(2,"0")).join("")}function Ze(e,t){if(e.length!==t.length)return!1;let n=0;for(let r=0;r<e.length;r++)n|=e.charCodeAt(r)^t.charCodeAt(r);return n===0}async function Vt(e,t,n,r=Date.now(),s){if(!n)return{ok:!1,status:500,error:"ingest secret not configured"};let a=e.headers.get(X.ts)??"",o=e.headers.get(X.nonce)??"",L=e.headers.get(X.device)??"",c=(e.headers.get(X.sig)??"").toLowerCase();if(!a||!o||!L||!c)return{ok:!1,status:401,error:"missing HMAC headers"};let p=Number(a);if(!Number.isFinite(p)||Math.abs(r-p)>3e5)return{ok:!1,status:401,error:"timestamp skew"};if(s&&await s(o))return{ok:!1,status:401,error:"replay nonce"};let u=await ue(t),l=await me(n,Nt(a,o,L,u));return Ze(l,c)?{ok:!0,deviceId:L,ts:p,nonce:o}:{ok:!1,status:401,error:"bad HMAC signature"}}var Kt=["tony.walteur@gmail.com","twalteur@amaris.com"],He="metis_operator_session",Mr=["/","/keys","/licenses","/devices","/map","/cloudflare","/cloudflare/connect","/cloudflare/callback","/overview","/events","/profiles","/realtime","/macos","/windows","/skills","/login","/dashboards","/insights","/pages","/seo","/sessions","/groups","/cohorts","/settings","/references","/notifications","/session"];function qe(e){return e.trim().toLowerCase()}function Ue(e){return Kt.includes(qe(e))}function Ve(e){return Mr.includes(e)}function Ke(e){return e.startsWith("/v1/admin")}function Be(e){if(!e)return null;let t=e.trim();if(!t)return null;try{let n=new URL(t);return n.protocol!=="https:"||!n.hostname.endsWith(".cloudflareaccess.com")||n.hostname==="cloudflareaccess.com"?null:`${n.protocol}//${n.host}`}catch{return null}}function Ar(e,t){let n=new URL(e.url),r=new URL(`${t}/cdn-cgi/access/login/${n.host}`);return r.searchParams.set("redirect_url",n.toString()),r.searchParams.set("next",n.pathname),r.toString()}function je(e){return Response.json({ok:!1,error:e},{status:503})}function jt(e,t){let n=Be(t.TEAM_DOMAIN);return n?new Response(null,{status:302,headers:{Location:Ar(e,n)}}):je("Cloudflare Access is misconfigured: TEAM_DOMAIN is unset")}var Gt=720*60*1e3;function zt(){return`${He}=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0`}function De(e,t){let n=e.headers.get("cookie")||"";for(let r of n.split(";")){let s=r.indexOf("=");if(s<0||r.slice(0,s).trim()!==t)continue;let a=r.slice(s+1).trim();if(a)try{return decodeURIComponent(a)}catch{return a}}return null}function Fe(e){return!!(e&&e.split(".").length===3)}function Er(e){let t=e.headers.get("cf-access-jwt-assertion")?.trim();if(Fe(t))return t;let n=De(e,"CF_Authorization");if(Fe(n))return n;let r=De(e,"CF_AppSession");return Fe(r)?r:null}async function Wt(e,t,n){let s=`v1|${t+Gt}|${qe(e)}`,a=await me(n,`metis-operator-session:${s}`);return`${s}|${a}`}function Yt(e){let t=Math.floor(Gt/1e3);return`${He}=${encodeURIComponent(e)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${t}`}function Rr(e){let t=(e.headers.get("authorization")||"").trim(),n=/^Bearer\s+(\S+)/i.exec(t);if(n?.[1])try{return decodeURIComponent(n[1])}catch{return n[1]}return De(e,He)}async function Cr(e,t,n){if(!t?.trim()||!e)return null;let r=e.split("|");if(r.length!==4||r[0]!=="v1")return null;let s=Number(r[1]),a=qe(r[2]||""),o=(r[3]||"").toLowerCase();if(!Number.isFinite(s)||s<n||!Ue(a)||!o)return null;let L=await me(t,`metis-operator-session:v1|${s}|${a}`);return Ze(L,o)?a:null}async function Pr(e,t,n){return Cr(Rr(e),t,n)}async function Jt(e,t,n,r=Date.now()){if(t.access)try{let L=(await t.access.getIdentity())?.email?.trim().toLowerCase();if(L)return Ue(L)?{status:"ok",email:L}:{status:"denied"}}catch{}let s=Er(e);if(s){if(!Be(n.TEAM_DOMAIN))return{status:"misconfigured",error:"Cloudflare Access is misconfigured: TEAM_DOMAIN is unset"};if(!n.POLICY_AUD?.trim())return{status:"misconfigured",error:"Cloudflare Access is misconfigured: POLICY_AUD is unset"};let o=await $r(s,Be(n.TEAM_DOMAIN),n.POLICY_AUD.trim());if(o&&Ue(o))return{status:"ok",email:o}}let a=await Pr(e,n.OPERATOR_PROMPT_KEY,r);return a?{status:"ok",email:a}:s?{status:"denied"}:{status:"none"}}async function $r(e,t,n){try{let r=`${t.replace(/\/$/,"")}/cdn-cgi/access/certs`,s=await fetch(r);if(!s.ok)return null;let a=await s.json(),o=e.split(".");if(o.length!==3)return null;let L=JSON.parse(atob(o[0].replace(/-/g,"+").replace(/_/g,"/"))),c=a.keys?.find(k=>k.kid===L.kid);if(!c)return null;let p=await crypto.subtle.importKey("jwk",c,{name:"RSASSA-PKCS1-v1_5",hash:"SHA-256"},!1,["verify"]),u=new TextEncoder().encode(`${o[0]}.${o[1]}`),l=Uint8Array.from(atob(o[2].replace(/-/g,"+").replace(/_/g,"/")),k=>k.charCodeAt(0));if(!await crypto.subtle.verify("RSASSA-PKCS1-v1_5",p,l,u))return null;let g=JSON.parse(atob(o[1].replace(/-/g,"+").replace(/_/g,"/")));return(Array.isArray(g.aud)?g.aud:[g.aud]).includes(n)&&(g.email?.trim().toLowerCase()||g.identity?.email?.trim().toLowerCase())||null}catch{return null}}function Xt(){return Response.json({ok:!1,error:"Access required"},{status:401})}var Tr="https://dash.cloudflare.com/login";var Or="/cloudflare/callback";function Ir(e){let t=new URL(e.url),n=new URL(Tr);return n.searchParams.set("redirect_uri",new URL(Or,t.origin).toString()),n.toString()}function Qt(e){return new Response(null,{status:302,headers:{Location:Ir(e)}})}function en(){return new Response(null,{status:303,headers:{Location:"/#keys"}})}var Nr=["anthropic","openai","gemini","nvidia","deepseek","minimax","qwen","kimi","openrouter","groq","mistral","grok","custom"],Zr=["claude-cli","codex-cli","dust","local"],V="cloudflare-account",fe="metis-operator",ge="8eb5a081-594c-407c-9470-6a5aa28b9f7c",Ge="metis-operator",tn=new Set(Nr),Fr=new Set(Zr);function he(e){return Fr.has(e)}function ze(e){return tn.has(e)}function nn(e){return e===V||tn.has(e)}function We(e){let t=e.trim(),n=t.replace(/[^a-zA-Z0-9]/g,""),r=n.length>=4?n:t;return r.length<2?"----":r.slice(-4)}function Ye(e,t){return t?JSON.stringify({secret:e,accountId:t}):e}function ee(e){let t=e.trim();if(t.startsWith("{"))try{let n=JSON.parse(t);if(typeof n.secret=="string"&&n.secret)return{secret:n.secret,accountId:typeof n.accountId=="string"?n.accountId:void 0}}catch{}return{secret:t}}function rn(e){let t=[],n=new Set;for(let r of e)r.status==="active"&&ze(r.provider)&&(n.has(r.provider)||(n.add(r.provider),t.push(r.provider)));return t}var Ur="Connect Cloudflare (login) on Keys.",Br="Cloudflare API rejected the token. Rotate it on Keys.";function D(e="24h"){return{worker:fe,connected:!1,error:Ur,requests:null,errors:null,cpuMs:null,range:e,workers:[],d1Name:null,d1Id:null}}function Dr(e){return{authorization:`Bearer ${e}`,"content-type":"application/json"}}function sn(e){if(!e||typeof e!="object")return[];let t=e;return Array.isArray(t.result)?t.result:[]}function Hr(e){let n=(e&&typeof e=="object"?e.data:null)?.viewer?.accounts?.[0]?.workersInvocationsAdaptive;if(!Array.isArray(n)||!n.length)return{requests:0,errors:0,cpuMs:0};let r=0,s=0,a=0;for(let o of n)r+=Number(o.sum?.requests??0),s+=Number(o.sum?.errors??0),a+=Number(o.sum?.cpuTimeMs??0);return{requests:r,errors:s,cpuMs:a}}async function an(e){let t=e.range??"24h",n=e.fetchImpl??globalThis.fetch,r=e.now??Date.now(),s=t==="30d"?720:t==="7d"?168:24,a=new Date(r-s*60*60*1e3).toISOString(),o=Dr(e.token),L=e.accountId.trim(),c=await n(`https://api.cloudflare.com/client/v4/accounts/${L}/workers/scripts`,{method:"GET",headers:o});if(c.status===401||c.status===403)return{...D(t),connected:!0,error:Br};if(c.status<200||c.status>=300)return{...D(t),connected:!0,error:`Cloudflare Workers list failed (${c.status}).`};let p=await c.json(),u=sn(p).map(y=>typeof y.id=="string"?y.id:typeof y.name=="string"?y.name:"").filter(Boolean),l=await n(`https://api.cloudflare.com/client/v4/accounts/${L}/d1/database`,{method:"GET",headers:o}),d=null,g=null;if(l.status>=200&&l.status<300){let y=sn(await l.json()),S=y.find(C=>C.uuid===ge||C.id===ge)??y.find(C=>C.name===Ge);d=S?.name??Ge,g=(S?.uuid||S?.id)??ge}let h=await n("https://api.cloudflare.com/client/v4/graphql",{method:"POST",headers:o,body:JSON.stringify({query:`query($accountTag: string!, $scriptName: string!, $datetimeStart: string!) {
        viewer {
          accounts(filter: { accountTag: $accountTag }) {
            workersInvocationsAdaptive(
              limit: 1
              filter: { scriptName: $scriptName, datetime_geq: $datetimeStart }
            ) { sum { requests errors cpuTimeMs } }
          }
        }
      }`,variables:{accountTag:L,scriptName:fe,datetimeStart:a}})}),k=null,_=null,m=null;if(h.status>=200&&h.status<300){let y=Hr(await h.json());y&&(k=y.requests,_=y.errors,m=Math.round(y.cpuMs))}return{worker:fe,connected:!0,error:null,requests:k,errors:_,cpuMs:m,range:t,workers:u,d1Name:d,d1Id:g}}var on=["pending","in_progress","in_review","submitted","success","failed","expired"],ln=["pending","failed","success","in_progress","in_review","expired","submitted"];var qr={pending:"pending",failed:"failed",success:"success",expired:"expired",submitted:"submitted",in_progress:"in_progress","in-progress":"in_progress",in_review:"in_review","in-review":"in_review",dead_letter:"expired","dead-letter":"expired"};function Je(e){return typeof e!="string"?null:qr[e.trim().toLowerCase()]??null}function ve(e){return{id:e.id,device_id:e.device_id,ts:e.ts,status:Je(e.status)??"pending",title:e.title,connector:e.connector,meeting_file:e.meeting_file??null,meeting_hash:e.meeting_hash??null,last_error:e.last_error??null,retry_requested:e.retry_requested===1?1:0,attempt:Number.isFinite(e.attempt)?Math.max(0,Math.floor(e.attempt)):0,latency_ms:Number.isFinite(e.latency_ms)?Math.max(0,Math.floor(e.latency_ms)):0,remote_id:e.remote_id??null,remote_url:e.remote_url??null,action:e.action??null}}var Ln=new Set(["token","access_token","refresh_token","id_token","api_key","apikey","authorization","bearer","secret","hmac","signature","sig","password","prompt_cipher","prompt_iv","cipher","iv","private_key","signed","operator_ingest_secret","operator_prompt_key","operator_skill_private_key"]),Vr=[/bearer\s+[a-z0-9._\-+/=]{8,}/i,/\bsk-[a-z0-9_-]{10,}/i,/\bsk-ant-[a-z0-9_-]{8,}/i,/\bsk-proj-[a-z0-9_-]{8,}/i,/\bAIza[0-9A-Za-z_-]{20,}/,/\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/,/\b[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}\b/,/\b[a-f0-9]{64}\b/i,/\b[A-Za-z0-9+/]{40,}={0,2}\b/];function b(e){if(typeof e!="string")return!1;let t=e.trim();return t?Ln.has(t.toLowerCase())?!0:Vr.some(n=>n.test(t)):!1}function Kr(e){let t=e.trim().toLowerCase().replace(/[\s-]/g,"_");return Ln.has(t)||t.endsWith("_token")||t.endsWith("_secret")||t.endsWith("_key")}function be(e){if(!e)return[];let t=[];for(let[n,r]of Object.entries(e)){if(r==null||r===""||Kr(n))continue;let s=String(r).trim();!s||b(s)||b(n)||t.push({key:n.slice(0,24),value:s.slice(0,48)})}return t}var te=120*1e3,gn=1800*1e3,K=3600*1e3,$=24*K,jr=60*1e3,Gr=new Set(["claude-cli","codex-cli"]),zr=new Set(["anthropic","openai","gemini","nvidia","deepseek","minimax","qwen","kimi","openrouter","groq","mistral","grok","custom"]);function cn(e,t,n){let r=e-t*n;return Array.from({length:t},(s,a)=>r+a*n)}function ye(e,t,n,r){let s=0;for(let a of e)a.kind===r&&a.ts>=t&&a.ts<n&&s++;return s}function Xe(e){let t=new Map;for(let n of e){let r=n||"unknown";t.set(r,(t.get(r)??0)+1)}return[...t.entries()].map(([n,r])=>({label:n,value:r})).sort((n,r)=>r.value-n.value)}function dn(e){return{ts:e.ts,cacheRead:e.cache_read??void 0,cacheWrite:e.cache_write??void 0,cacheUncached:e.cache_uncached??void 0,cacheStatus:e.cache_status??void 0,cacheTtl:e.cache_ttl??void 0,model:e.model??void 0,provider:e.provider??void 0,outputTokens:e.output_tokens??void 0,ttftMs:e.ttft_ms??void 0}}function un(e){let t=0,n=!1;for(let r of e){let s=$e({cacheRead:r.cache_read??void 0,cacheWrite:r.cache_write??void 0,cacheUncached:r.cache_uncached??void 0,cacheStatus:r.cache_status??void 0,cacheTtl:r.cache_ttl??void 0,outputTokens:r.output_tokens??void 0},r.model||"",r.provider||void 0);s&&(n=!0,t+=s.usd)}return n?Te(t):null}function Wr(e){let t=new Date(e);return Date.UTC(t.getUTCFullYear(),t.getUTCMonth(),t.getUTCDate())}function Yr(e,t=Date.now()){let n=Wr(t),r=0,s=0,a=0,o=0,L=0;for(let c of e)c.status==="success"&&c.ts>=n&&(r+=1),c.status!=="pending"&&(s+=1),(c.status==="failed"||c.status==="expired")&&(a+=1),c.status==="expired"&&(L+=1),(c.retry_requested===1||c.attempt>1)&&(o+=1);return{landedToday:r,failRatePct:s===0?null:Math.round(a/s*1e3)/10,retries:o,deadLetters:L}}function Jr(e){let t=new Map;for(let n of e){let r=n.connector.trim()||"unknown",s=t.get(r)??{connector:r,attempted:0,submitted:0,success:0,failed:0};n.status!=="pending"&&(s.attempted+=1),(n.status==="submitted"||n.status==="in_review"||n.status==="success")&&(s.submitted+=1),n.status==="success"&&(s.success+=1),(n.status==="failed"||n.status==="expired")&&(s.failed+=1),t.set(r,s)}return[...t.values()].sort((n,r)=>r.attempted-n.attempted||n.connector.localeCompare(r.connector))}function hn(e,t,n,r,s){let a=r-s,o=new Set;for(let L of e)L.last_seen>=a&&o.add(L.device_id);for(let L of t)L.kind==="heartbeat"&&L.ts>=a&&L.device_id&&o.add(L.device_id);for(let L of n)L.kind==="heartbeat"&&L.ts>=a&&L.device_id&&o.add(L.device_id);return o}function Xr(e,t,n,r){return hn(e,t,n,r,gn)}function Qr(e,t,n,r=0){let s=Array.from({length:30},()=>new Set),a=n-gn,o=(c,p)=>{if(!p||c<a||c>n)return;let u=Math.min(29,Math.max(0,Math.floor((c-a)/jr)));s[u].add(p)};for(let c of e)c.kind==="heartbeat"&&o(c.ts,c.device_id);for(let c of t)c.kind==="heartbeat"&&o(c.ts,c.device_id);let L=s.map(c=>c.size);return r>0&&L.every(c=>c===0)&&(L[29]=r),L}function pn(e,t){let n=new Set;for(let r of e)r.last_seen>=t&&n.add(r.device_id);return n.size}function mn(e,t,n){let r=new Set;for(let s of e)s.ts>=t&&s.ts<n&&r.add(s.device_id);return r.size}function es(e){if(!e.length)return null;let t=[...e].sort((n,r)=>n-r);return t[Math.floor((t.length-1)/2)]??null}function ts(e){let t=(e||"").trim().toLowerCase();return Gr.has(t)?"cli":zr.has(t)?"operator":"unknown"}function ns(e){let t=0,n=!1;for(let r of e){if(!/^listen$/i.test(r.kind))continue;let s=/^(\d+(?:\.\d+)?)m$/.exec((r.detail||"").trim());s&&(t+=Number(s[1]),n=!0)}return n?t:null}function fn(e){let t=0,n=!1;for(let r of[e.input_tokens,e.output_tokens])r!=null&&(t+=r,n=!0);return n?t:null}function Qe(e){return{hostname:e?.hostname&&!b(e.hostname)?e.hostname:null,email:e?.sso_email&&!b(e.sso_email)?e.sso_email:null}}function rs(e){return e&&e.split(/\s+/).find(n=>n.startsWith("/")&&!b(n))||"/"}function ss(e,t){let n=e.device_id?t.get(e.device_id):void 0,r=Qe(n);return{id:e.id,ts:e.ts,name:b(e.kind)?"event":e.kind,device:e.device_id?e.device_id.slice(0,8):null,hostname:r.hostname,email:r.email||(e.actor&&!b(e.actor)?e.actor:null),country:e.country&&!b(e.country)?e.country:n?.country||null,city:n?.city&&!b(n.city)?n.city:null,os:n?.os&&n.os!=="unknown"&&!b(n.os)?n.os:null,browser:n?"Electron":null,chips:be({country:e.country,os:n?.os,detail:e.detail,path:rs(e.detail)})}}function as(e,t){let n=new Map;for(let r of[...e,...t])n.has(r.id)||n.set(r.id,r);return[...n.values()].sort((r,s)=>s.ts-r.ts).slice(0,80)}function is(e){return{id:e.id&&!b(e.id)?e.id:"key",provider:b(e.provider)?"provider":e.provider,label:b(e.label)?"key":e.label,last4:/^\w{2,8}$/.test(e.last4)?e.last4:"----",status:e.status,createdAt:e.createdAt,rotatedAt:e.rotatedAt,revokedAt:e.revokedAt}}async function ke(e,t,n,r={ingestBound:!1,promptBound:!1,skillBound:!1,vaultBound:!1},s=D()){let a=await e.listSeats(),o=await e.listAsks(2e3),L=await e.listPulses(n-7*$),c=await e.listProposals(),p=await e.listAudit(80),u=await e.listCrm(200),l=await e.listPacks(),d=await e.listEvents(80),g=await e.listVaultMeta(),h=new Map(a.map(i=>[i.device_id,i])),k=hn(a,L,d,n,te).size,_=pn(a,n-$),m=pn(a,n-7*$),y=new Set(a.map(i=>i.app_version).filter(Boolean)).size,S=c.filter(i=>i.status==="pending").length,C=a.reduce((i,v)=>v.last_index_at==null?i:i==null?v.last_index_at:Math.max(i,v.last_index_at),null),R=cn(n,24,K),E=cn(n,7,$),Ae=R.map((i,v)=>{let w=v===R.length-1?n+1:i+K;return{t:i,heartbeats:ye(L,i,w,"heartbeat"),asks:ye(L,i,w,"ask")}}),Y=E.map((i,v)=>{let w=v===E.length-1?n+1:i+$;return{t:i,heartbeats:ye(L,i,w,"heartbeat"),asks:ye(L,i,w,"ask")}}),vt=o.filter(i=>i.ts>=n-$),F=o.filter(i=>i.ts>=n-7*$),bt=Oe(vt.map(dn)),Lr=un(vt),cr=un(F),yt=R.map(i=>{let v=0,w=0,P=0;for(let M of o)M.ts<i||M.ts>=i+K||(M.cache_read!=null&&(v+=M.cache_read),M.cache_write!=null&&(w+=M.cache_write),M.cache_uncached!=null&&(P+=M.cache_uncached));return{t:i,read:v,write:w,uncached:P}}),Ee=new Map;for(let i of F){let v=i.provider||"unknown",w=i.mode||"unknown",P=`${v}\0${w}`,M=Ee.get(P)??{provider:v,mode:w,asks:0,read:null,write:null,uncached:null,estimate:null,usd:0,anyCost:!1};M.asks++,i.cache_read!=null&&(M.read=(M.read??0)+i.cache_read),i.cache_write!=null&&(M.write=(M.write??0)+i.cache_write),i.cache_uncached!=null&&(M.uncached=(M.uncached??0)+i.cache_uncached);let Tt=$e({cacheRead:i.cache_read??void 0,cacheWrite:i.cache_write??void 0,cacheUncached:i.cache_uncached??void 0,cacheStatus:i.cache_status??void 0,cacheTtl:i.cache_ttl??void 0,outputTokens:i.output_tokens??void 0},i.model||"",i.provider||void 0);Tt&&(M.anyCost=!0,M.usd+=Tt.usd),Ee.set(P,M)}let dr=[...Ee.values()].map(i=>({provider:i.provider,mode:i.mode,asks:i.asks,read:i.read,write:i.write,uncached:i.uncached,estimate:i.anyCost?Te(i.usd):null})),Re=Xr(a,L,d,n),kt=a.filter(i=>Re.has(i.device_id)),Ce=new Map;for(let i of kt){if(!i.country)continue;let v=Ce.get(i.country)??new Set;v.add(i.device_id),Ce.set(i.country,v)}let xt=[...Ce.entries()].map(([i,v])=>({iso:i,devices:v.size})).sort((i,v)=>v.devices-i.devices),wt=kt.filter(i=>i.lat!=null&&i.lon!=null&&i.country).map(i=>({lat:i.lat,lon:i.lon,city:i.city,country:i.country})),_t=n-119*$,Pe=Array.from({length:119},()=>0),Le=i=>{if(i<_t||i>n)return;let v=Math.floor((i-_t)/$);v>=0&&v<Pe.length&&Pe[v]++};for(let i of p)Le(i.ts);for(let i of l)Le(i.pushed_at);for(let i of c)Le(i.created_at),i.decided_at&&Le(i.decided_at);let St=Object.fromEntries(on.map(i=>[i,0]));for(let i of u)St[i.status]++;let Mt=Yr(u,n),At=Re.size,ur=Qr(L,d,n,At),pr=es(F.map(i=>i.total_ms).filter(i=>i!=null&&i>0)),Et=0,Rt=!1;for(let i of F){let v=fn(i);v!=null&&(Et+=v,Rt=!0)}let Ct=0,Pt=0,$t=0;for(let i of F){let v=ts(i.provider);v==="cli"?Ct++:v==="operator"?Pt++:$t++}let mr=F.filter(i=>(i.mode||"").toLowerCase()==="recap").length+d.filter(i=>/recap/i.test(i.kind)).length,fr=u.filter(i=>i.meeting_hash||i.status==="success").length,gr=E.map((i,v)=>{let w=v===E.length-1?n+1:i+$;return F.filter(P=>P.ts>=i&&P.ts<w&&(P.mode||"").toLowerCase()==="recap").length}),hr=R.map(i=>{let v=0;for(let w of o){if(w.ts<i||w.ts>=i+K)continue;let P=fn(w);P!=null&&(v+=P)}return v}),vr={uniqueSessions:m,sessionsDay:_,liveNow:k,live30:At,live30Series:ur,timeSaved:null,durationMs:pr,meetings:fr,tokens:g.some(i=>i.status==="active")&&Rt?Et:0,apiCalls:F.length,listenMinutes:ns(d),recapCount:mr,cliAsks:Ct,operatorAsks:Pt,unknownAsks:$t,crmFailRate:Mt.failRatePct,uniqueSeries:Y.map(i=>mn(L,i.t,i.t+$)),sessionsDaySeries:Y.map(i=>mn(L,i.t,i.t+$)),liveSeries:Ae.map(i=>i.heartbeats),apiSeries:Y.map(i=>i.asks),tokenSeries:hr,recapSeries:gr};return{email:t,now:n,kpis:{live:k,dau:_,wau:m,versions:y,cacheHit:bt.hitRate==null?null:`${Math.round(bt.hitRate*100)}%`,costToday:Lr,cost7d:cr,pendingDiffs:S,lastIndexAt:C,liveSeries:Ae.map(i=>i.heartbeats),dauSeries:Y.map(i=>i.heartbeats),costSeries:yt.map(i=>i.read+i.write+i.uncached),hitSeries:R.map(i=>{let v=Oe(o.filter(w=>w.ts>=i&&w.ts<i+K).map(dn));return v.hitRate==null?0:Math.round(v.hitRate*100)})},ops:vr,scale:{hours24:Ae,days7:Y,versions:Xe(a.map(i=>i.app_version)),os:Xe(a.map(i=>i.os))},cost:{tokens:yt,table:dr},change:{timeline:p.map(i=>({ts:i.ts,actor:i.actor,action:i.action,detail:i.detail})),heatmap:Pe,adoption:Xe(a.map(i=>i.app_version))},map:{countries:xt,dots:wt,empty:xt.length===0&&wt.length===0},asks:o.slice(0,40).map(i=>({id:i.id,ts:i.ts,mode:i.mode||"",preview:i.preview||"Ask",cache_status:i.cache_status||"not-reported",provider:i.provider||""})),proposals:c.map(i=>({id:i.id,skill_id:i.skill_id,from_version:i.from_version,status:i.status,rationale:i.rationale,diff:i.diff,evidence:JSON.parse(i.evidence_json||"[]"),created_by:i.created_by,created_at:i.created_at})),crm:{counts:St,landing:Mt,funnel:Jr(u),rows:u.map(i=>({id:i.id,status:i.status,title:i.title,connector:i.connector,ts:i.ts,error:i.last_error,retryRequested:i.retry_requested===1,device:i.device_id.slice(0,8),attempt:i.attempt,latencyMs:i.latency_ms,remoteId:i.remote_id,remoteUrl:i.remote_url,meetingHash:i.meeting_hash,action:i.action}))},events:as(d.map(i=>ss(i,h)),[...o.slice(0,40).map(i=>{let v=h.get(i.device_id),w=Qe(v);return{id:`ask-${i.id}`,ts:i.ts,name:"ask",device:i.device_id.slice(0,8),hostname:w.hostname,email:w.email,country:v?.country||null,city:v?.city||null,os:v?.os&&v.os!=="unknown"?v.os:null,browser:v?"Electron":null,chips:be({mode:i.mode,provider:i.provider,cache:i.cache_status,os:v?.os,path:"/"})}}),...u.slice(0,40).map(i=>{let v=h.get(i.device_id),w=Qe(v);return{id:`crm-${i.id}`,ts:i.ts,name:"crm",device:i.device_id.slice(0,8),hostname:w.hostname,email:w.email,country:v?.country||null,city:v?.city||null,os:v?.os&&v.os!=="unknown"?v.os:null,browser:v?"Electron":null,chips:be({status:i.status,connector:i.connector,action:i.action,path:"/"})}})]),profiles:a.slice().sort((i,v)=>v.last_seen-i.last_seen).map(i=>({device:i.device_id.slice(0,8),hostname:i.hostname&&!b(i.hostname)?i.hostname:null,email:i.sso_email&&!b(i.sso_email)?i.sso_email:null,os:i.os,appVersion:i.app_version,country:i.country,city:i.city,lastSeen:i.last_seen,firstSeen:i.first_seen,live:n-i.last_seen<te,live30:Re.has(i.device_id),license:i.license&&!b(i.license)?i.license:null})),keys:{ingestBound:r.ingestBound,promptBound:r.promptBound,skillBound:r.skillBound,vaultBound:r.vaultBound,vault:g.map(is)},cloudflare:{worker:s.worker,connected:s.connected,error:s.error,requests:s.requests,errors:s.errors,cpuMs:s.cpuMs,range:s.range,workers:s.workers.filter(i=>!b(i)),d1Name:s.d1Name&&!b(s.d1Name)?s.d1Name:null,d1Id:s.d1Id&&!b(s.d1Id)?s.d1Id:null}}}var os=/^[A-Z]{2}$/,ls=new Set(["XX","T1"]);function Ls(e){if(typeof e!="string")return null;let t=e.trim().toUpperCase();return os.test(t)||ls.has(t)?t:null}function cs(e){return typeof e!="string"?null:e.trim().slice(0,80)||null}function vn(e,t,n){let r=typeof e=="number"?e:typeof e=="string"?Number(e):NaN;return!Number.isFinite(r)||r<t||r>n?null:Math.round(r*1e3)/1e3}function bn(e){let t=e.cf;return!t||typeof t!="object"?{country:null,city:null,lat:null,lon:null}:{country:Ls(t.country),city:cs(t.city),lat:vn(t.latitude,-90,90),lon:vn(t.longitude,-180,180)}}var ds=11520*60*1e3;function yn(){let e=new Set,t=new Map,n=new Map,r=new Map,s=[],a=new Map,o=new Map,L=new Map,c=[],p=new Map,u=new Map;return{async takeNonce(l){return e.has(l)?!0:(e.add(l),!1)},async hitRate(l,d,g,h){let k=t.get(l);return!k||d-k.window_start>g?(t.set(l,{window_start:d,count:1}),!1):(k.count++,k.count>h)},async upsertSeat(l){let d=n.get(l.device_id);n.set(l.device_id,{...l,os:l.os&&l.os!=="unknown"?l.os:d?.os??l.os,app_version:l.app_version||d?.app_version||"",first_seen:d?.first_seen??l.first_seen,country:l.country??d?.country??null,city:l.city??d?.city??null,lat:l.lat??d?.lat??null,lon:l.lon??d?.lon??null,last_index_at:l.last_index_at??d?.last_index_at??null,hostname:l.hostname??d?.hostname??null,sso_email:l.sso_email??d?.sso_email??null,license:l.license??d?.license??null})},async insertAsk(l){r.set(l.id,l)},async updateAskRating(l,d){let g=r.get(l);g&&(g.rating=d,d==="down"&&(g.outcome="thumbs-down"))},async listAsks(l){return[...r.values()].sort((d,g)=>g.ts-d.ts).slice(0,l)},async getAsk(l){return r.get(l)??null},async listSeats(){return[...n.values()]},async insertPulse(l){s.push(l);let d=l.ts-ds;for(let g=s.length-1;g>=0;g--)s[g].ts<d&&s.splice(g,1)},async listPulses(l){return s.filter(d=>d.ts>=l)},async listProposals(){return[...a.values()].sort((l,d)=>d.created_at-l.created_at)},async getProposal(l){return a.get(l)??null},async putProposal(l){a.set(l.id,l)},async listPacks(){return[...o.values()]},async latestPacks(){let l=new Map;for(let d of o.values()){let g=l.get(d.skill_id);(!g||d.pushed_at>g.pushed_at)&&l.set(d.skill_id,d)}return[...l.values()]},async putPack(l){o.set(l.id,l)},async upsertCrm(l){L.set(l.id,l)},async getCrm(l){return L.get(l)??null},async listCrm(l){return[...L.values()].sort((d,g)=>g.ts-d.ts).slice(0,l)},async listCrmRetries(l){return[...L.values()].filter(d=>d.device_id===l&&d.retry_requested===1&&(d.status==="pending"||d.status==="failed"||d.status==="expired"))},async audit(l,d,g,h,k,_){c.push({id:l,ts:d,actor:g,action:h,ask_id:k,detail:_})},async listAudit(l){return c.slice(-l).reverse()},async insertEvent(l){p.set(l.id,l)},async listEvents(l){return[...p.values()].sort((d,g)=>g.ts-d.ts).slice(0,l)},async listVaultMeta(){return[...u.values()].sort((l,d)=>d.created_at-l.created_at).map(et)},async listVaultRows(){return[...u.values()].sort((l,d)=>d.created_at-l.created_at)},async getVaultKey(l){return u.get(l)??null},async putVaultKey(l){u.set(l.id,l)}}}function et(e){return{id:e.id,provider:e.provider,label:e.label,last4:e.last4,status:e.status,createdAt:e.created_at,rotatedAt:e.rotated_at,revokedAt:e.revoked_at}}var us=600*1e3,ps=11520*60*1e3;function kn(e){return{async takeNonce(t,n){return await e.prepare("SELECT nonce FROM nonces WHERE nonce = ?").bind(t).first()?!0:(await e.prepare("INSERT INTO nonces (nonce, ts) VALUES (?, ?)").bind(t,n).run(),await e.prepare("DELETE FROM nonces WHERE ts < ?").bind(n-us).run(),!1)},async hitRate(t,n,r,s){let a=await e.prepare("SELECT window_start, count FROM rate_limits WHERE device_id = ?").bind(t).first();if(!a||n-a.window_start>r)return await e.prepare("INSERT INTO rate_limits (device_id, window_start, count) VALUES (?, ?, 1) ON CONFLICT(device_id) DO UPDATE SET window_start = ?, count = 1").bind(t,n,n).run(),!1;let o=a.count+1;return await e.prepare("UPDATE rate_limits SET count = ? WHERE device_id = ?").bind(o,t).run(),o>s},async upsertSeat(t){let n=await e.prepare("SELECT first_seen FROM seats WHERE device_id = ?").bind(t.device_id).first();await e.prepare(`INSERT INTO seats (device_id, seat_hash, os, app_version, first_seen, last_seen, country, city, lat, lon, last_index_at, hostname, sso_email, license)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(device_id) DO UPDATE SET
             seat_hash = excluded.seat_hash,
             os = CASE WHEN excluded.os IS NULL OR excluded.os = '' OR excluded.os = 'unknown' THEN seats.os ELSE excluded.os END,
             app_version = CASE WHEN excluded.app_version IS NULL OR excluded.app_version = '' THEN seats.app_version ELSE excluded.app_version END,
             last_seen = excluded.last_seen,
             country = COALESCE(excluded.country, seats.country),
             city = COALESCE(excluded.city, seats.city),
             lat = COALESCE(excluded.lat, seats.lat),
             lon = COALESCE(excluded.lon, seats.lon),
             last_index_at = COALESCE(excluded.last_index_at, seats.last_index_at),
             hostname = COALESCE(excluded.hostname, seats.hostname),
             sso_email = COALESCE(excluded.sso_email, seats.sso_email),
             license = COALESCE(excluded.license, seats.license)`).bind(t.device_id,t.seat_hash,t.os,t.app_version,n?.first_seen??t.first_seen,t.last_seen,t.country,t.city,t.lat,t.lon,t.last_index_at,t.hostname,t.sso_email,t.license).run()},async insertAsk(t){await e.prepare(`INSERT OR REPLACE INTO asks (
            id, device_id, ts, mode, skill_id, skill_version, provider, model,
            ttft_ms, total_ms, input_tokens, output_tokens, cache_read, cache_write,
            cache_uncached, cache_status, cache_ttl, outcome, rating, prompt_cipher, prompt_iv, preview
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(t.id,t.device_id,t.ts,t.mode,t.skill_id,t.skill_version,t.provider,t.model,t.ttft_ms,t.total_ms,t.input_tokens,t.output_tokens,t.cache_read,t.cache_write,t.cache_uncached,t.cache_status,t.cache_ttl,t.outcome,t.rating,t.prompt_cipher,t.prompt_iv,t.preview).run()},async updateAskRating(t,n){let r=n==="down"?"thumbs-down":null;r?await e.prepare("UPDATE asks SET rating = ?, outcome = ? WHERE id = ?").bind(n,r,t).run():await e.prepare("UPDATE asks SET rating = ? WHERE id = ?").bind(n,t).run()},async listAsks(t){return(await e.prepare("SELECT * FROM asks ORDER BY ts DESC LIMIT ?").bind(t).all()).results},async getAsk(t){return await e.prepare("SELECT * FROM asks WHERE id = ?").bind(t).first()??null},async listSeats(){return(await e.prepare("SELECT * FROM seats").all()).results.map(n=>({...n,hostname:n.hostname??null,sso_email:n.sso_email??null,license:n.license??null}))},async insertPulse(t){await e.prepare("INSERT OR REPLACE INTO pulses (id, device_id, ts, kind, country, city) VALUES (?, ?, ?, ?, ?, ?)").bind(t.id,t.device_id,t.ts,t.kind,t.country,t.city).run(),await e.prepare("DELETE FROM pulses WHERE ts < ?").bind(t.ts-ps).run()},async listPulses(t){return(await e.prepare("SELECT * FROM pulses WHERE ts >= ? ORDER BY ts ASC").bind(t).all()).results},async listProposals(){return(await e.prepare("SELECT * FROM proposals ORDER BY created_at DESC").all()).results},async getProposal(t){return await e.prepare("SELECT * FROM proposals WHERE id = ?").bind(t).first()??null},async putProposal(t){await e.prepare(`INSERT OR REPLACE INTO proposals (
            id, skill_id, from_version, evidence_json, diff, rationale, status,
            created_by, created_at, decided_at, reject_reason
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(t.id,t.skill_id,t.from_version,t.evidence_json,t.diff,t.rationale,t.status,t.created_by,t.created_at,t.decided_at,t.reject_reason).run()},async listPacks(){return(await e.prepare("SELECT * FROM packs").all()).results},async latestPacks(){let t=await e.prepare("SELECT * FROM packs ORDER BY pushed_at DESC").all(),n=new Map;for(let r of t.results)n.has(r.skill_id)||n.set(r.skill_id,r);return[...n.values()]},async putPack(t){await e.prepare(`INSERT OR REPLACE INTO packs (
            id, skill_id, version, sha256, body, signed, pushed_at, pushed_by
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).bind(t.id,t.skill_id,t.version,t.sha256,t.body,t.signed,t.pushed_at,t.pushed_by).run()},async upsertCrm(t){await e.prepare(`INSERT INTO crm_sends (
             id, device_id, ts, status, title, connector, meeting_file, meeting_hash,
             last_error, retry_requested, attempt, latency_ms, remote_id, remote_url, action
           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(id) DO UPDATE SET
             ts = excluded.ts,
             status = excluded.status,
             title = excluded.title,
             connector = excluded.connector,
             meeting_file = excluded.meeting_file,
             meeting_hash = excluded.meeting_hash,
             last_error = excluded.last_error,
             retry_requested = excluded.retry_requested,
             attempt = excluded.attempt,
             latency_ms = excluded.latency_ms,
             remote_id = excluded.remote_id,
             remote_url = excluded.remote_url,
             action = excluded.action`).bind(t.id,t.device_id,t.ts,t.status,t.title,t.connector,t.meeting_file,t.meeting_hash,t.last_error,t.retry_requested,t.attempt,t.latency_ms,t.remote_id,t.remote_url,t.action).run()},async getCrm(t){let n=await e.prepare("SELECT * FROM crm_sends WHERE id = ?").bind(t).first();return n?ve(n):null},async listCrm(t){return(await e.prepare("SELECT * FROM crm_sends ORDER BY ts DESC LIMIT ?").bind(t).all()).results.map(ve)},async listCrmRetries(t){return(await e.prepare(`SELECT * FROM crm_sends
           WHERE device_id = ? AND retry_requested = 1 AND status IN ('pending', 'failed', 'expired')`).bind(t).all()).results.map(ve)},async audit(t,n,r,s,a,o){await e.prepare("INSERT INTO audit (id, ts, actor, action, ask_id, detail) VALUES (?, ?, ?, ?, ?, ?)").bind(t,n,r,s,a,o).run()},async listAudit(t){return(await e.prepare("SELECT ts, actor, action, ask_id, detail FROM audit ORDER BY ts DESC LIMIT ?").bind(t).all()).results},async insertEvent(t){await e.prepare("INSERT OR REPLACE INTO events (id, ts, kind, actor, device_id, country, detail) VALUES (?, ?, ?, ?, ?, ?, ?)").bind(t.id,t.ts,t.kind,t.actor,t.device_id,t.country,t.detail).run()},async listEvents(t){return(await e.prepare("SELECT id, ts, kind, actor, device_id, country, detail FROM events ORDER BY ts DESC LIMIT ?").bind(t).all()).results},async listVaultMeta(){return(await e.prepare(`SELECT id, provider, label, last4, cipher, iv, status, created_at, created_by, rotated_at, revoked_at
           FROM vault_keys ORDER BY created_at DESC`).all()).results.map(et)},async listVaultRows(){return(await e.prepare(`SELECT id, provider, label, last4, cipher, iv, status, created_at, created_by, rotated_at, revoked_at
           FROM vault_keys ORDER BY created_at DESC`).all()).results},async getVaultKey(t){return await e.prepare(`SELECT id, provider, label, last4, cipher, iv, status, created_at, created_by, rotated_at, revoked_at
             FROM vault_keys WHERE id = ?`).bind(t).first()??null},async putVaultKey(t){await e.prepare(`INSERT OR REPLACE INTO vault_keys (
            id, provider, label, last4, cipher, iv, status, created_at, created_by, rotated_at, revoked_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(t.id,t.provider,t.label,t.last4,t.cipher,t.iv,t.status,t.created_at,t.created_by,t.rotated_at,t.revoked_at).run()}}}function ms(e){return{id:e.id,provider:e.provider,label:e.label,last4:e.last4,status:e.status,createdAt:e.createdAt,rotatedAt:e.rotatedAt,revokedAt:e.revokedAt}}async function xn(e,t){let n=(await e.listVaultMeta()).map(ms);return{...t,vault:n}}function fs(e,t){return typeof e.label=="string"&&e.label.trim()&&!b(e.label)?e.label.trim().slice(0,80):t}function wn(e){return typeof e.secret=="string"&&e.secret.trim()?e.secret.trim():typeof e.token=="string"&&e.token.trim()?e.token.trim():""}async function _n(e,t,n,r,s){if(!t.OPERATOR_VAULT_KEY)return{ok:!1,error:"vault key missing",status:500};let a=typeof s.provider=="string"?s.provider.trim():"";if(!nn(a)||he(a))return{ok:!1,error:"provider not allowed",status:400};let o=wn(s);if(!o)return{ok:!1,error:"secret required",status:400};if(b(a))return{ok:!1,error:"provider not allowed",status:400};let L=a===V&&typeof s.accountId=="string"?s.accountId.trim():void 0;if(a===V&&!L)return{ok:!1,error:"accountId required",status:400};let c=fs(s,L||a),p=We(o),u=await Ne(Ye(o,L),t.OPERATOR_VAULT_KEY),l=crypto.randomUUID(),d={id:l,provider:a,label:c,last4:p,cipher:u.cipher,iv:u.iv,status:"active",created_at:r,created_by:n,rotated_at:null,revoked_at:null};return await e.putVaultKey(d),await e.audit(crypto.randomUUID(),r,n,"vault-write",null,`${a} \xB7${p}`),await e.insertEvent({id:crypto.randomUUID(),ts:r,kind:"vault",actor:n,device_id:null,country:null,detail:`write ${a}`}),{ok:!0,id:l,last4:p,status:"active"}}async function Sn(e,t,n,r,s,a){if(!t.OPERATOR_VAULT_KEY)return{ok:!1,error:"vault key missing",status:500};let o=await e.getVaultKey(s);if(!o)return{ok:!1,error:"not found",status:404};if(o.status==="revoked")return{ok:!1,error:"revoked",status:400};let L=wn(a);if(!L)return{ok:!1,error:"secret required",status:400};let c;if(o.provider===V)try{let l=ee(await Q(o.cipher,o.iv,t.OPERATOR_VAULT_KEY));c=typeof a.accountId=="string"&&a.accountId.trim()?a.accountId.trim():l.accountId}catch{c=typeof a.accountId=="string"?a.accountId.trim():void 0}let p=We(L),u=await Ne(Ye(L,c),t.OPERATOR_VAULT_KEY);return await e.putVaultKey({...o,last4:p,cipher:u.cipher,iv:u.iv,status:"active",rotated_at:r}),await e.audit(crypto.randomUUID(),r,n,"vault-rotate",null,`${o.provider} \xB7${p}`),await e.insertEvent({id:crypto.randomUUID(),ts:r,kind:"vault",actor:n,device_id:null,country:null,detail:`rotate ${o.provider}`}),{ok:!0,id:o.id,last4:p,status:"active"}}async function Mn(e,t,n,r){let s=await e.getVaultKey(r);return s?(await e.putVaultKey({...s,status:"revoked",revoked_at:n}),await e.audit(crypto.randomUUID(),n,t,"vault-revoke",null,`${s.provider} \xB7${s.last4}`),await e.insertEvent({id:crypto.randomUUID(),ts:n,kind:"vault",actor:t,device_id:null,country:null,detail:`revoke ${s.provider}`}),{ok:!0,id:s.id,status:"revoked"}):{ok:!1,error:"not found",status:404}}async function An(e){return rn(await e.listVaultMeta())}async function En(e,t){if(!t)return null;let r=(await e.listVaultRows()).find(s=>s.provider===V&&s.status==="active");if(!r)return null;try{let s=ee(await Q(r.cipher,r.iv,t));return s.secret?{accountId:s.accountId||r.label,token:s.secret}:null}catch{return null}}var tt={FJ:"M995 299L996 299L994 301L992 299L995 299ZM0 295L0 296L998 297L996 296L998 295L0 295Z",TZ:"M594 253L605 259L609 263L608 268L610 270L609 272L610 275L612 279L607 281L604 282L601 283L596 282L594 277L591 276L588 274L585 273L582 268L582 265L583 262L585 260L585 258L585 257L586 255L585 253L594 253Z",CA:"M159 114L153 111L146 109L145 105L141 101L137 98L139 95L131 90L127 86L124 84L118 86L114 83L108 82L108 56L118 58L123 57L131 57L139 55L143 56L146 55L154 55L158 57L163 56L173 58L180 59L180 61L192 62L198 63L198 60L203 59L207 60L213 61L222 62L226 60L233 60L235 61L238 58L232 55L236 50L242 52L243 56L248 60L256 59L257 63L262 59L266 56L274 58L272 61L274 64L265 66L261 67L257 70L250 72L248 75L241 78L237 83L241 87L244 91L253 92L257 94L264 96L271 97L272 102L278 108L282 104L278 98L286 95L287 91L282 87L284 81L285 76L293 77L297 77L302 80L307 83L310 87L316 87L321 82L326 88L328 94L335 97L341 98L344 101L345 105L341 107L333 110L323 110L316 110L310 114L302 120L309 116L319 113L319 116L321 122L329 123L332 121L330 124L322 127L316 129L321 124L314 125L312 119L309 119L306 120L304 124L302 124L296 125L291 126L288 128L284 129L280 129L281 131L277 132L271 134L269 134L269 133L271 131L271 127L268 123L268 122L266 121L265 121L264 120L260 118L255 116L251 117L245 116L240 115L237 114L236 113L230 114L211 114L194 114L178 114L167 114L159 114ZM267 77L269 75L273 75L273 76L269 77L267 77ZM278 48L275 45L283 45L288 48L282 48L278 48ZM277 78L278 77L279 77L280 77L279 79L278 79L277 78ZM240 42L238 43L234 43L231 42L233 41L237 40L239 41L240 42ZM239 35L238 35L233 35L232 34L238 34L240 34L239 35ZM231 31L234 33L227 33L226 31L231 31ZM255 43L243 42L242 39L233 38L231 36L240 37L248 38L250 39L256 40L264 40L275 40L278 42L272 43L261 43L255 43ZM191 33L195 33L194 34L189 35L185 34L187 33L191 33ZM192 31L195 32L192 32L187 32L190 31L192 31ZM346 107L342 112L346 111L347 113L351 113L353 115L354 118L351 121L350 118L346 120L346 118L341 118L335 117L335 115L341 109L345 107L346 107ZM267 69L273 71L276 72L275 74L269 72L262 75L258 73L260 70L263 68L265 68L267 69ZM281 49L290 49L294 52L302 53L311 55L309 59L320 62L328 64L322 69L315 66L311 68L317 70L320 74L316 75L313 75L316 78L303 75L300 73L292 70L284 72L284 69L295 68L295 66L297 62L292 60L288 58L283 56L279 56L264 56L254 54L254 52L249 49L254 46L260 47L264 46L276 48L281 49ZM237 44L249 45L241 48L235 50L233 46L237 44ZM159 39L169 35L177 34L175 37L167 39L159 39ZM131 100L133 103L135 105L132 103L130 100L131 100ZM207 30L220 31L223 34L214 32L211 31L207 30ZM157 115L151 114L148 112L144 111L143 109L148 110L152 111L156 114L157 115ZM162 43L173 44L179 46L169 49L165 52L157 52L151 49L156 45L162 43ZM201 39L206 39L205 42L188 43L184 42L177 42L177 38L187 38L197 40L196 37L199 38L201 39ZM204 47L209 51L214 54L219 57L216 58L210 59L202 58L190 59L184 58L177 58L176 55L184 55L182 54L172 54L177 52L168 51L173 48L183 47L188 47L195 47L199 51L199 47L204 47ZM221 48L221 45L230 45L228 47L231 51L224 52L215 49L221 48ZM204 46L208 45L210 46L207 48L203 46L204 46ZM226 37L229 40L223 42L220 40L215 38L222 37L226 37ZM233 26L238 25L243 24L252 26L258 29L258 30L248 33L239 31L241 30L233 29L233 26ZM246 23L253 22L263 20L269 21L275 19L288 19L298 19L310 19L323 20L328 21L315 23L318 24L307 26L297 29L286 30L288 31L288 33L282 35L279 36L284 37L269 38L257 38L251 36L255 34L264 35L256 32L263 31L260 29L266 27L273 26L257 26L249 24L246 23ZM291 63L286 64L287 61L291 61L291 63ZM233 57L233 59L227 58L225 56L230 56L233 57ZM321 111L322 111L325 112L328 113L328 114L327 114L323 113L321 111ZM322 119L325 121L326 122L322 121L322 119Z",US:"M159 114L175 114L186 114L203 114L220 114L236 114L237 113L238 115L243 115L248 116L252 117L257 117L262 119L265 120L265 121L266 121L267 122L268 122L271 124L272 129L270 132L269 133L270 134L274 133L281 131L281 130L281 129L287 129L288 128L292 125L301 125L303 124L305 122L308 118L310 118L312 123L314 126L308 128L304 130L303 132L305 134L306 134L304 135L300 135L298 135L299 136L296 137L295 137L295 138L292 142L291 141L291 142L292 143L289 147L290 145L288 141L288 144L288 145L289 148L290 151L285 154L282 156L280 158L275 161L274 165L275 169L276 172L278 177L277 180L275 180L273 178L270 174L270 171L267 167L264 168L262 166L257 166L252 166L252 167L252 169L251 169L248 169L243 168L239 167L234 170L230 173L230 176L230 178L227 178L224 175L222 172L220 168L215 167L211 169L209 166L207 164L204 162L199 163L192 163L181 160L178 159L174 158L171 156L169 155L166 154L165 152L160 146L158 144L156 140L155 136L154 131L156 126L155 120L154 116L158 117L160 118L159 114ZM68 194L69 195L70 196L68 197L67 197L66 195L67 195L67 194L68 194ZM67 192L66 193L65 192L67 192ZM65 191L64 191L63 191L65 191ZM61 190L62 191L60 190L61 190ZM57 188L57 189L56 189L57 188ZM38 82L40 83L40 84L38 84L37 83L35 83L38 82ZM74 89L77 90L72 92L70 90L74 89ZM108 56L108 82L114 83L118 86L124 84L127 86L131 90L139 95L137 98L133 96L129 91L125 88L117 87L109 84L100 83L91 81L89 83L84 84L79 86L79 81L82 80L76 83L74 86L69 90L65 92L60 94L55 95L49 97L42 99L45 97L51 95L55 93L60 91L62 88L61 87L58 88L56 87L52 87L50 85L49 83L43 83L41 80L40 78L43 75L47 75L51 74L53 72L53 70L49 71L46 71L38 70L33 68L43 65L45 66L49 65L43 62L37 60L43 59L47 56L53 54L61 53L69 52L73 53L77 54L84 54L95 55L101 55L108 56ZM23 73L26 73L31 74L29 75L26 74L23 74L23 73Z",KZ:"M743 113L738 115L737 119L729 124L722 125L723 131L721 132L716 131L710 131L705 130L700 131L697 133L692 135L690 137L685 136L683 133L680 129L672 129L667 126L663 123L655 135L652 133L647 133L646 133L646 131L641 128L640 126L643 124L647 124L647 120L642 119L636 121L635 119L631 117L631 113L632 110L635 109L645 106L655 109L662 108L666 109L671 108L669 104L671 103L671 100L682 98L692 96L698 100L704 100L707 101L713 100L722 109L728 109L733 109L736 111L741 112L743 113Z",UZ:"M655 135L663 123L667 126L672 129L680 129L683 133L685 136L690 137L692 135L697 133L696 135L700 135L699 138L696 138L696 136L692 139L688 140L689 142L688 147L685 146L681 143L676 141L672 136L668 135L667 133L661 133L659 135L655 135Z",PG:"M892 257L902 261L905 264L910 267L908 269L911 272L915 275L917 277L919 279L917 280L914 279L909 276L906 272L900 272L898 275L895 275L892 266L892 257ZM924 260L925 262L924 262L922 260L919 258L921 258L923 259L924 260ZM920 266L917 268L914 267L912 265L916 265L917 264L919 265L921 263L923 262L923 264L921 265L920 266ZM930 265L932 267L933 269L931 268L929 264L930 265Z",ID:"M892 257L892 275L886 272L882 273L885 270L883 265L875 262L870 261L869 260L867 258L872 257L867 256L864 254L866 252L872 252L873 258L879 256L884 255L889 257L892 257ZM847 275L847 276L843 279L843 277L847 275ZM873 269L873 267L873 266L874 265L874 266L874 267L873 269ZM827 239L828 244L831 247L826 250L824 254L823 261L819 261L816 260L811 260L808 258L806 254L803 251L803 246L805 246L809 247L812 246L816 247L820 242L822 238L827 239ZM859 258L863 261L859 259L855 259L859 258ZM852 261L851 260L850 259L853 259L853 260L852 261ZM855 244L857 246L857 249L855 251L856 252L854 247L855 244ZM841 248L847 245L846 249L841 249L834 249L836 254L843 252L841 253L838 255L840 260L842 265L840 265L838 263L838 262L836 257L834 261L833 266L832 262L831 260L831 256L833 250L836 246L841 248ZM834 278L830 277L833 276L835 277L835 278L834 278ZM837 274L841 272L837 275L833 273L837 274ZM828 273L831 274L826 275L825 273L827 272L828 273ZM801 268L807 269L813 269L818 272L818 274L813 273L807 273L802 271L796 270L793 269L798 267L801 268ZM790 253L791 257L795 259L794 266L789 264L784 260L780 256L776 249L774 245L770 241L765 236L766 235L773 238L777 241L782 244L786 248L787 252L790 253Z",AR:"M309 396L312 400L319 402L315 403L312 402L309 396ZM340 334L338 339L338 342L338 346L341 350L342 353L335 358L327 358L327 362L326 364L320 363L320 367L323 367L321 369L319 374L315 375L312 379L318 381L313 385L309 390L309 394L310 395L300 394L299 391L296 390L298 386L299 383L301 377L302 374L301 373L300 371L301 367L301 361L303 357L302 352L304 348L306 342L304 337L306 332L308 326L309 324L310 318L314 314L316 311L321 313L325 311L331 316L337 319L340 321L340 326L345 326L348 321L351 323L349 326L344 330L340 334Z",CL:"M309 396L312 402L313 404L309 404L306 403L299 401L293 397L299 399L304 399L307 396L309 396ZM307 299L308 303L309 307L312 314L314 314L310 318L309 324L308 326L306 332L304 337L306 342L304 348L302 352L303 357L301 361L301 367L300 371L301 373L302 374L301 377L299 383L298 386L296 390L299 391L300 394L310 395L306 396L303 400L298 399L292 395L292 392L290 385L294 380L293 377L297 373L296 367L294 370L295 361L296 356L297 353L300 344L301 336L301 330L304 321L305 309L305 301L307 299Z",CD:"M581 262L582 267L584 270L584 273L580 274L580 277L579 283L582 284L582 287L579 285L576 284L574 283L571 281L568 281L566 280L563 281L562 281L561 276L561 273L560 270L557 269L556 270L553 271L551 272L549 272L547 270L545 266L536 267L534 267L535 266L535 264L537 264L539 263L541 264L544 261L544 258L547 253L549 251L550 249L550 245L551 242L552 238L554 236L558 238L562 239L563 237L568 236L570 236L571 235L575 236L578 238L580 238L583 237L586 240L587 244L585 246L583 248L582 252L581 255L581 256L581 259L581 262Z",SO:"M636 218L636 219L636 224L633 228L621 224L619 222L619 220L621 219L623 221L627 220L632 219L634 218L636 218Z",KE:"M609 263L605 259L594 253L595 249L597 245L596 240L596 237L599 235L600 238L606 240L607 240L610 240L613 238L616 239L614 252L614 256L612 257L611 260L609 263Z",SD:"M568 227L565 225L565 223L564 220L564 218L562 216L561 215L562 213L563 211L563 208L566 207L566 194L569 189L591 189L603 192L603 195L605 199L605 202L602 203L601 209L601 212L598 216L596 220L594 223L594 224L594 222L592 220L592 216L591 217L590 218L588 221L586 223L582 222L581 223L578 224L575 223L574 223L572 221L569 223L567 226L568 227Z",TD:"M566 196L564 206L562 210L562 212L561 214L562 215L563 218L564 219L560 221L556 225L552 225L551 227L546 229L545 228L542 229L542 227L540 225L539 222L541 222L541 220L541 216L541 213L539 211L539 206L543 200L544 193L543 192L541 186L555 190L566 196Z",HT:"M301 195L301 198L301 199L299 199L296 199L293 199L296 199L299 198L298 196L297 195L301 195Z",DO:"M301 200L300 198L301 197L301 195L305 195L306 196L308 197L310 198L308 199L306 199L304 199L303 199L301 201L301 200Z",RU:"M760 25L772 26L778 31L764 30L757 27L760 25ZM786 30L793 31L792 32L776 34L781 30L784 30L786 30ZM886 39L903 40L891 42L880 41L886 39ZM912 41L919 41L915 43L911 42L906 41L907 40L912 41ZM889 46L891 45L895 45L899 46L899 47L895 47L889 46ZM625 26L634 26L636 26L643 26L638 27L635 27L629 27L625 26ZM563 99L555 99L559 97L563 98L563 99ZM649 45L655 41L670 38L684 37L691 37L680 40L662 44L654 49L660 54L649 53L643 51L646 49L651 45L649 45ZM897 101L898 106L902 114L896 117L899 122L895 122L894 117L895 112L893 106L896 101L896 99L897 101ZM863 133L863 131L865 127L866 124L872 122L874 118L870 116L864 117L859 113L854 109L852 106L847 102L840 102L834 103L835 106L831 109L827 112L821 112L818 110L810 113L804 113L800 112L794 110L788 111L784 108L778 107L772 108L770 112L763 111L759 110L752 110L744 113L741 112L736 111L733 109L728 109L722 109L713 100L707 101L704 100L698 100L692 96L682 98L671 100L671 103L669 104L671 108L666 109L662 108L655 109L645 106L635 109L632 110L631 113L631 117L635 119L636 121L632 123L632 129L635 134L633 136L630 134L627 133L624 131L622 131L614 129L611 129L604 126L604 124L605 120L609 119L606 118L610 117L610 114L611 112L606 111L602 110L598 109L595 108L596 106L591 105L589 105L588 103L587 102L591 102L588 101L587 100L586 97L583 95L581 95L577 92L576 90L576 87L578 85L578 82L586 77L583 73L582 70L581 64L579 60L582 58L589 56L601 58L614 63L611 66L594 65L597 67L597 71L603 73L601 70L610 71L610 68L619 66L624 65L623 61L628 60L627 62L629 65L634 62L649 59L649 61L654 60L663 59L670 58L668 56L680 58L692 59L689 57L687 56L685 53L692 48L702 48L700 52L702 54L705 60L698 66L702 65L706 63L707 60L705 58L707 54L708 50L709 48L709 52L711 50L721 49L724 48L728 45L741 45L742 41L751 40L759 39L769 39L780 38L783 35L795 35L797 36L800 37L815 38L816 41L806 43L807 44L814 45L817 46L830 46L842 47L848 46L857 47L857 50L865 53L872 52L882 52L889 51L890 48L918 51L936 53L944 54L947 57L956 56L966 57L974 58L973 55L988 56L0 58L14 63L16 66L23 64L25 68L21 71L17 71L11 70L8 68L3 67L0 67L0 70L996 71L995 72L998 75L998 77L985 78L978 81L973 84L962 84L958 84L953 86L950 89L953 94L949 96L945 99L940 103L936 108L933 102L933 92L936 89L945 85L955 80L953 76L945 82L935 79L931 86L920 87L916 84L904 85L886 91L880 98L884 101L889 99L893 105L890 111L885 119L880 125L875 129L869 131L864 132L863 133ZM0 51L3 51L6 52L0 53L996 53L0 51ZM593 122L596 122L597 123L601 124L598 125L593 126L590 124L593 123L593 122Z",BS:"M281 176L282 175L284 175L284 176L281 177L281 176ZM284 175L286 176L286 178L285 178L285 176L284 175ZM283 180L284 180L285 182L285 184L284 184L283 183L282 182L283 180Z",NO:"M542 29L547 28L560 31L551 34L548 37L538 35L537 33L529 29L538 29L542 29ZM586 57L579 58L577 55L571 58L566 59L559 57L556 58L550 60L547 61L542 66L539 71L535 72L533 78L534 83L531 87L523 88L516 87L514 78L524 74L534 67L546 60L559 55L568 53L578 52L583 55L586 57ZM576 28L564 29L555 28L548 27L561 27L571 27L576 28ZM569 34L562 35L558 34L559 34L558 33L564 32L565 33L569 34Z",TL:"M847 275L850 273L853 273L853 274L847 276L847 275Z",ZA:"M545 329L548 329L550 330L553 330L555 319L558 322L558 325L561 323L563 321L566 321L570 321L572 320L574 318L575 315L582 311L584 312L587 312L589 318L588 322L586 321L585 323L587 326L589 324L590 326L589 330L587 332L585 335L580 339L576 342L572 344L570 344L566 344L563 344L557 346L554 347L552 346L551 345L551 342L551 340L549 335L547 333L545 329ZM580 330L578 330L575 333L578 335L580 334L581 331L580 330Z",LS:"M580 330L581 333L579 334L577 335L576 331L579 330L580 330Z",MX:"M175 160L181 159L185 161L197 163L199 162L205 163L208 165L210 168L214 170L218 167L221 170L224 173L225 177L229 178L229 181L228 186L229 189L230 193L233 196L237 198L240 199L244 198L248 196L249 192L251 191L257 190L259 191L257 194L257 196L256 199L255 199L253 200L252 200L250 201L247 202L247 203L248 204L249 205L244 208L244 209L241 207L237 205L233 206L230 206L225 204L220 202L217 200L213 199L208 196L206 193L207 192L208 190L206 188L203 184L199 180L196 178L195 176L193 173L190 171L188 169L186 164L184 162L181 162L181 164L182 167L185 170L186 171L187 173L188 175L191 179L192 181L194 183L196 185L195 187L194 185L190 182L188 179L187 177L184 176L182 175L181 173L183 172L181 169L178 166L176 162L175 160Z",UY:"M340 334L345 336L348 337L352 341L352 344L347 347L344 347L339 346L338 342L338 339L340 334Z",BR:"M352 344L352 341L348 337L345 336L340 334L347 327L351 325L350 321L349 320L349 317L347 317L346 315L345 312L342 312L339 308L339 305L340 303L340 299L338 297L333 295L333 292L332 290L330 287L327 287L324 285L318 282L318 279L315 278L311 280L309 281L305 281L304 276L299 278L297 276L296 273L295 270L297 268L297 266L301 263L303 262L307 254L307 252L306 248L308 248L306 247L311 245L313 245L314 247L318 248L321 246L322 245L324 243L321 241L320 239L323 239L326 239L331 237L331 236L333 236L334 238L334 240L334 244L336 246L338 246L340 245L342 245L344 245L344 244L346 243L349 244L351 243L352 244L354 243L357 238L358 240L361 245L359 249L365 251L367 252L375 254L376 257L385 258L393 260L399 264L402 265L404 270L401 277L395 284L393 286L392 294L391 300L390 304L386 311L383 314L376 315L371 317L365 322L365 325L364 330L359 336L355 340L352 344Z",BO:"M307 280L310 281L313 279L319 277L319 280L321 285L326 286L329 287L332 288L333 291L332 292L338 295L338 298L340 300L339 304L338 306L336 304L328 305L327 308L325 311L321 313L316 311L312 314L309 307L308 303L307 299L307 294L307 292L309 288L309 285L307 280Z",PE:"M306 262L303 262L298 265L297 267L295 269L294 271L297 275L298 276L302 278L304 281L307 280L309 286L308 290L308 293L308 296L306 300L302 299L296 295L289 291L288 288L283 279L279 272L276 268L275 266L275 261L277 261L277 262L279 262L282 263L284 258L290 254L291 250L293 251L295 254L299 257L302 257L305 258L304 260L306 262Z",CO:"M314 247L313 245L311 245L306 247L308 248L306 248L307 252L307 254L304 260L305 258L302 257L299 257L295 254L293 251L291 250L288 249L285 249L284 248L281 245L281 244L284 243L286 239L285 237L285 234L284 230L285 229L285 226L287 226L290 224L290 221L294 219L296 219L299 217L302 216L302 217L299 219L297 221L296 225L298 226L299 228L299 229L300 231L305 231L308 233L312 233L312 235L312 237L313 240L312 242L313 244L314 247Z",PA:"M285 226L285 228L284 229L283 229L283 227L282 226L279 225L277 227L276 228L277 229L275 230L274 229L273 227L271 227L270 228L270 227L270 226L270 225L271 223L272 225L273 225L275 225L278 224L280 223L282 224L284 225L285 226Z",CR:"M271 223L270 225L270 226L270 227L268 227L268 225L267 224L265 223L264 222L264 223L262 222L262 221L261 220L262 219L265 219L266 220L268 220L269 222L271 223Z",NI:"M268 220L266 220L265 219L262 219L261 218L259 216L256 214L257 214L258 214L259 213L260 212L261 211L262 211L263 210L264 210L264 209L265 209L267 209L268 208L269 209L269 210L268 212L268 214L268 216L268 218L267 219L268 220Z",HN:"M269 208L268 209L266 209L265 209L264 209L263 210L262 211L262 212L260 212L259 212L259 213L257 214L256 213L256 211L254 212L253 211L252 210L252 209L254 207L255 206L257 206L260 206L261 206L263 206L264 206L266 206L267 207L269 208Z",SV:"M252 210L253 211L254 212L256 211L256 213L254 213L252 213L250 212L251 211L251 210L252 210Z",GT:"M244 210L244 208L245 205L249 204L248 204L246 202L247 201L252 201L252 206L254 206L255 206L252 208L252 209L251 210L251 211L250 212L247 211L244 210Z",BZ:"M252 201L253 200L254 199L255 199L255 200L255 201L255 203L254 205L253 206L252 203L252 201Z",VE:"M331 236L331 237L326 239L323 239L320 239L321 241L324 243L322 245L321 246L318 248L314 247L313 243L313 241L312 239L312 235L313 233L310 233L307 233L304 230L299 230L299 229L299 227L298 225L297 223L298 220L300 218L302 218L301 220L300 223L302 225L302 222L305 218L306 216L309 218L311 221L316 220L320 222L321 220L328 220L327 222L331 224L333 226L332 228L333 230L330 231L329 233L331 236Z",GY:"M343 245L341 245L339 246L337 246L334 245L333 242L335 239L333 237L333 235L329 233L330 231L333 230L332 228L336 228L338 231L340 232L341 236L339 237L340 241L341 242L343 245Z",SR:"M349 244L346 243L344 244L344 245L341 242L340 241L339 237L341 236L345 234L347 233L349 236L350 240L349 242L349 244Z",FR:"M357 238L354 243L352 244L351 243L349 244L349 241L349 238L350 234L353 235L357 238ZM517 113L522 114L521 118L519 118L517 120L518 121L519 123L519 125L521 127L518 130L509 130L505 132L501 132L495 129L497 122L492 118L487 115L496 115L497 113L505 108L507 109L510 110L513 111L516 113L517 113ZM524 132L526 131L527 133L526 135L524 134L524 133L524 132Z",EC:"M291 250L290 254L284 258L282 263L279 262L277 262L277 261L278 257L277 257L276 255L276 253L278 249L279 247L284 248L285 249L288 249L291 250Z",PR:"M316 199L318 199L315 200L313 199L316 199Z",JM:"M285 199L288 200L286 200L284 200L283 199L285 199Z",CU:"M271 186L276 186L280 188L283 188L287 191L290 192L292 193L294 194L290 195L284 195L285 193L282 192L280 190L276 189L272 188L270 187L267 188L265 189L265 188L267 187L271 186Z",ZW:"M587 312L584 312L582 311L578 310L577 307L573 304L571 301L573 300L575 300L579 296L580 295L584 293L587 294L588 295L591 296L591 302L591 305L590 307L587 312Z",BW:"M582 311L575 315L574 318L572 320L570 321L566 321L563 321L561 323L558 325L558 322L555 319L558 311L560 301L565 301L568 300L570 299L572 302L576 307L577 308L580 310L582 311Z",NA:"M555 319L553 330L550 330L548 329L545 329L542 325L541 321L540 313L539 310L536 305L533 300L534 298L537 297L539 298L553 299L564 299L569 298L570 299L567 300L564 300L558 301L555 311L555 319Z",SN:"M454 212L451 209L454 207L455 204L458 204L461 205L464 207L466 211L468 213L468 215L466 215L465 216L462 215L456 215L454 216L456 214L457 213L459 213L462 212L460 212L458 211L457 212L454 212Z",ML:"M468 215L468 213L466 211L467 209L468 207L472 207L473 207L485 205L483 193L486 181L505 193L507 195L509 197L512 203L510 207L504 207L501 209L499 208L494 210L492 212L490 213L488 213L485 217L485 220L484 222L483 221L481 221L479 222L478 222L477 220L476 220L477 218L475 216L474 216L473 216L471 217L469 216L468 216L468 215Z",MR:"M453 192L464 191L464 185L467 178L476 174L482 181L485 205L485 207L473 208L470 208L468 207L466 209L463 205L460 204L457 205L454 205L455 202L455 197L455 194L453 192Z",BJ:"M507 233L504 231L504 224L503 222L502 219L504 218L506 217L508 216L510 219L510 221L509 224L508 226L507 233Z",NE:"M541 186L543 192L544 193L543 200L539 206L539 211L541 213L539 214L539 215L536 212L532 213L530 213L526 214L522 213L519 214L515 211L511 212L510 215L508 216L506 217L503 214L501 211L501 209L504 207L510 207L512 203L516 196L533 185L539 188L541 186Z",NG:"M507 233L508 226L509 224L510 221L510 219L510 215L511 212L515 211L519 214L522 213L526 214L530 213L532 213L536 212L539 215L540 216L540 218L537 222L536 224L534 227L533 229L531 232L528 230L526 232L524 237L520 238L516 238L514 234L510 233L507 233Z",CM:"M540 214L542 218L543 222L541 222L539 223L542 226L543 229L541 232L540 235L540 237L542 239L544 242L544 244L542 245L536 244L534 244L531 244L527 241L525 239L524 238L524 235L526 232L529 230L533 231L534 228L535 226L537 223L538 220L540 217L539 215L540 214Z",TG:"M502 219L503 222L504 224L504 231L503 234L502 231L502 227L501 224L500 220L502 219Z",GH:"M500 219L501 222L501 226L501 229L502 233L499 235L495 237L492 235L492 229L492 223L492 220L498 220L500 219Z",CI:"M478 222L479 222L481 221L483 221L484 222L486 222L488 223L490 222L493 227L491 233L492 236L489 236L484 236L479 238L479 236L479 234L477 233L477 231L477 229L477 227L478 224L477 222L478 222Z",GN:"M462 215L465 216L466 215L468 215L469 216L470 216L472 217L473 216L475 216L476 217L476 219L477 220L477 221L477 222L478 224L477 227L477 229L475 230L474 229L473 226L472 227L471 226L470 224L469 222L466 223L465 223L463 225L461 223L460 222L459 220L459 218L461 218L462 217L462 216L462 215Z",GW:"M454 216L456 215L462 215L462 216L461 218L460 218L458 219L455 218L455 217L454 216Z",LR:"M477 229L477 231L477 233L479 234L479 236L478 238L472 234L468 231L469 229L472 227L473 226L474 229L475 230L477 229Z",SL:"M463 225L465 223L466 223L469 222L470 224L471 226L472 227L469 229L468 231L465 230L464 227L463 225Z",BF:"M485 221L486 218L488 215L489 213L491 212L494 210L497 208L499 209L501 210L503 213L506 215L505 218L503 219L500 219L498 220L492 220L492 223L489 223L487 223L485 221Z",CF:"M576 235L573 236L570 236L569 236L565 237L563 237L560 238L556 237L553 237L551 240L548 240L544 244L544 242L542 239L540 237L540 235L541 232L545 229L546 229L550 228L553 226L553 225L558 224L562 220L564 220L565 223L565 225L568 227L570 229L573 232L576 235Z",CG:"M551 240L550 243L549 248L549 250L549 252L546 255L544 260L542 262L539 263L538 262L536 263L534 263L531 261L532 258L535 257L536 257L540 256L540 252L540 247L537 246L536 244L542 245L544 244L548 240L551 240Z",GA:"M531 244L534 244L536 244L537 246L540 247L540 252L540 256L536 257L535 257L532 258L531 261L526 256L525 252L526 249L527 247L531 244Z",GQ:"M527 244L531 244L531 247L527 247L526 247L527 244Z",ZM:"M585 273L588 274L591 276L593 279L592 282L592 286L592 289L584 293L580 295L579 296L575 300L573 300L570 299L569 298L564 299L561 295L567 286L567 284L567 281L567 280L569 281L572 283L575 282L578 284L580 287L582 284L580 283L579 280L579 275L581 273L585 273Z",MW:"M591 276L594 277L596 282L596 288L598 289L599 294L597 297L595 293L596 291L594 290L591 288L593 285L593 280L592 277L591 276Z",MZ:"M596 282L601 283L604 282L607 281L612 279L612 283L613 289L612 293L610 296L604 299L600 302L597 305L598 309L598 311L599 314L599 316L597 318L592 320L591 323L591 324L589 323L588 321L588 316L590 309L591 306L591 304L591 300L590 296L588 295L584 294L584 291L594 290L596 291L595 293L597 297L599 294L598 289L596 288L596 282Z",SZ:"M589 324L587 326L585 323L586 321L588 322L589 324Z",AO:"M536 263L535 265L534 266L534 263L536 263ZM534 267L536 267L545 266L547 270L549 272L551 272L553 271L556 270L557 269L560 270L561 273L561 276L562 281L563 281L566 280L566 283L566 285L561 286L563 297L559 300L551 298L539 298L536 297L533 298L533 294L534 290L535 286L538 283L538 280L536 277L536 275L536 271L534 267Z",BI:"M585 257L585 258L585 260L583 262L581 259L582 258L585 257Z",IL:"M599 159L598 160L598 162L597 163L598 164L597 167L596 162L597 161L597 158L599 158L600 158L599 159Z",LB:"M600 158L599 158L599 156L600 154L602 155L600 158Z",MG:"M638 285L639 288L640 292L639 294L638 294L638 297L637 300L635 307L632 316L629 320L625 320L622 318L620 313L621 309L622 308L624 304L622 301L623 297L625 295L627 294L630 292L633 289L634 288L636 285L638 285Z",PS:"M598 163L597 162L597 161L599 160L598 163Z",GM:"M454 212L457 211L459 212L461 212L460 213L458 212L456 213L453 213L454 212Z",TN:"M526 166L523 160L521 157L523 154L523 149L526 146L528 148L531 147L529 150L530 153L529 156L531 158L532 160L530 162L528 164L526 166Z",DZ:"M476 174L476 173L480 168L485 167L490 164L491 162L496 160L496 159L495 154L497 151L501 149L509 148L515 148L520 147L523 147L523 151L521 155L523 159L525 161L527 168L527 172L527 175L526 178L528 181L530 182L533 185L516 196L509 197L507 195L505 193L486 181L476 174Z",JO:"M599 160L602 160L609 161L603 162L605 166L602 167L600 169L597 168L598 163L599 160Z",AE:"M643 183L644 183L648 183L652 181L656 178L657 181L655 183L654 184L653 186L653 188L643 183Z",QA:"M641 181L642 178L643 178L643 182L641 181Z",KW:"M633 167L634 169L633 171L629 169L633 167Z",IQ:"M609 161L614 154L615 149L618 147L622 147L624 147L628 151L627 153L628 158L633 162L633 164L635 167L631 167L624 169L612 161L609 161Z",OM:"M653 187L654 185L656 183L655 181L658 183L661 184L664 186L666 187L665 190L664 191L661 193L660 195L660 197L657 198L656 200L654 201L652 203L649 204L647 202L653 194L653 187ZM656 179L656 178L657 177L657 178L656 179Z",KH:"M785 216L786 210L792 210L796 210L799 212L794 218L792 220L787 220L785 216Z",TH:"M792 210L786 210L785 216L780 215L778 213L776 220L776 224L779 227L781 231L784 233L781 234L778 232L777 231L775 228L773 228L773 225L775 220L776 214L775 212L773 208L775 205L772 201L772 198L775 195L778 193L779 196L781 199L784 200L786 200L789 199L791 204L793 209L792 210Z",LA:"M798 211L795 211L793 209L791 204L789 199L786 200L784 200L781 199L779 196L778 193L781 190L783 191L784 188L787 192L791 195L789 196L794 201L798 206L798 211Z",MM:"M778 193L775 195L772 198L772 201L775 205L773 208L775 212L776 214L775 220L773 220L773 217L773 212L771 205L768 204L763 206L763 202L760 196L759 195L756 190L757 189L758 187L759 183L763 181L764 178L768 174L770 173L770 171L773 173L774 176L771 180L774 183L776 186L778 190L781 189L779 192L778 193Z",VN:"M790 221L795 220L799 216L798 211L798 206L794 201L789 196L791 195L787 192L784 188L788 187L793 185L796 187L797 189L796 193L794 197L798 204L802 208L803 218L798 221L792 226L792 222L790 221Z",KP:"M863 132L862 133L860 134L859 137L857 138L854 140L854 141L857 143L855 144L852 145L850 145L849 145L848 145L846 144L848 143L848 141L846 140L847 137L852 134L856 135L860 132L863 132Z",KR:"M850 145L852 145L855 144L857 143L860 148L859 153L854 154L851 153L850 148L850 145Z",MN:"M744 113L752 110L759 110L763 111L770 112L772 108L778 107L784 108L788 111L794 110L800 112L804 113L810 113L818 110L821 112L823 114L822 117L826 118L830 117L832 120L826 120L822 123L815 126L811 125L810 128L809 129L803 132L795 133L790 134L783 132L776 132L768 131L765 127L760 125L753 124L753 120L747 116L744 113Z",IN:"M770 171L770 173L768 174L764 178L763 181L759 183L758 187L757 189L755 184L753 185L755 183L755 180L750 180L748 178L745 178L745 181L746 183L747 186L747 190L742 190L740 194L733 199L728 203L727 205L723 206L723 212L722 217L720 221L720 224L717 227L713 225L710 219L708 215L707 209L703 200L702 193L698 192L692 189L693 187L691 182L697 180L695 176L696 172L702 170L707 164L709 160L706 157L706 153L714 154L719 155L720 158L718 159L721 164L724 167L725 171L731 174L737 176L742 177L745 176L745 173L747 174L749 176L753 176L756 174L757 173L763 169L767 168L767 171L770 171Z",BD:"M757 189L756 190L756 191L755 188L751 187L751 189L749 189L747 189L746 184L745 182L747 180L746 177L750 178L752 180L757 181L754 183L755 186L756 184L757 189Z",BT:"M755 173L756 175L751 175L747 175L749 172L752 172L755 173Z",NP:"M745 173L745 176L742 177L737 176L731 174L725 171L724 167L726 165L731 168L734 170L738 172L745 173Z",PK:"M716 151L710 154L705 155L707 159L707 162L704 167L699 172L693 175L695 179L697 182L689 184L687 181L679 180L671 180L676 176L674 174L672 170L669 167L677 168L679 168L684 167L686 163L688 162L691 162L692 160L695 157L697 156L698 154L699 151L700 149L706 148L709 147L712 150L716 151Z",AF:"M685 146L688 147L691 146L693 146L695 145L697 143L698 145L698 147L701 147L703 146L708 146L707 147L703 148L698 150L699 152L698 155L694 156L694 158L693 161L690 162L688 163L684 165L681 168L678 168L674 169L672 165L669 162L668 158L668 156L670 151L675 152L678 150L680 147L683 145L685 146Z",TJ:"M688 147L689 142L688 140L692 139L696 136L696 138L696 139L693 140L699 141L705 143L708 143L708 146L703 146L701 147L698 147L698 145L697 143L695 145L693 146L691 146L688 147Z",KG:"M697 133L700 131L705 130L710 131L716 131L721 132L723 133L717 136L713 138L708 138L705 140L699 141L693 140L696 139L699 138L700 135L696 135L697 133Z",TM:"M646 134L650 132L654 135L659 135L661 133L667 133L668 135L672 136L676 141L681 143L685 146L683 145L680 147L678 150L675 152L670 151L668 149L662 146L657 144L654 145L650 147L650 142L648 139L647 136L652 136L649 133L647 136L646 134Z",IR:"M635 167L633 164L633 162L628 158L627 153L628 151L624 147L623 144L624 140L626 142L629 142L633 140L633 142L636 144L639 146L645 148L650 147L654 145L657 144L662 146L668 149L670 151L668 156L668 158L669 162L672 165L670 169L674 172L676 174L672 177L666 179L659 179L657 175L652 176L646 173L641 170L638 167L635 167Z",SY:"M599 159L600 159L600 156L601 154L600 152L601 150L602 148L606 147L610 148L614 147L616 148L615 151L608 157L599 159Z",AM:"M629 142L627 141L626 140L624 140L621 138L621 136L625 136L626 137L627 139L629 140L629 142Z",SE:"M531 87L534 83L533 78L535 72L539 71L542 66L547 61L550 60L556 58L561 59L565 66L562 67L559 71L550 76L550 82L550 86L546 92L541 94L536 96L533 90L531 87Z",BY:"M578 94L582 95L586 96L585 98L588 100L590 101L590 102L587 103L588 105L585 106L584 107L581 107L578 107L573 106L568 106L565 107L564 104L566 103L565 100L571 99L574 97L575 95L578 94Z",UA:"M588 105L590 105L594 105L595 107L597 108L598 110L604 110L607 111L611 113L611 116L608 117L606 119L602 120L597 121L597 123L596 122L593 122L588 121L585 121L582 124L580 124L579 123L580 122L581 121L583 121L582 120L581 118L580 116L576 115L574 116L572 117L569 117L566 117L563 117L561 115L563 114L563 113L566 110L565 107L568 106L573 106L578 107L581 107L584 107L585 106L588 105Z",PL:"M565 100L566 103L564 104L565 107L566 110L563 113L563 114L558 113L555 113L553 113L551 111L549 110L546 111L545 109L542 108L541 105L539 103L539 101L545 99L552 98L555 99L563 99L565 100Z",AT:"M547 116L545 117L545 120L542 120L538 121L534 119L531 120L528 120L527 118L529 118L534 117L536 118L536 116L538 114L541 114L545 115L547 115L547 116Z",HU:"M561 115L563 117L560 119L556 122L552 122L549 122L546 121L545 120L545 117L547 116L550 117L552 116L555 116L556 116L558 115L561 115Z",MD:"M574 116L576 115L580 116L581 118L582 120L583 121L581 121L580 122L579 123L578 122L578 120L576 117L574 116Z",RO:"M578 124L581 124L582 125L580 125L578 128L572 128L567 128L564 128L562 127L562 126L560 126L558 124L556 122L560 119L563 117L566 117L569 117L572 117L574 116L576 117L578 120L578 122L578 124Z",LT:"M574 96L572 98L568 100L565 99L563 98L562 97L558 94L566 94L569 94L574 96Z",LV:"M576 90L577 92L575 95L571 94L569 93L562 94L559 92L563 90L567 92L570 89L574 90L576 90Z",EE:"M578 85L576 87L576 90L571 89L568 89L567 88L565 86L572 84L578 85Z",DE:"M539 101L539 103L541 105L542 108L540 108L537 109L534 110L535 112L538 114L536 116L536 118L534 117L529 118L527 118L524 117L521 118L522 114L517 113L517 111L517 106L519 105L519 101L522 101L524 100L524 97L528 97L530 99L533 99L538 100L539 101Z",BG:"M563 127L565 128L571 129L576 127L579 129L577 132L575 133L573 135L568 134L564 135L562 132L564 130L562 128L563 127Z",GR:"M573 152L569 153L565 152L567 152L572 152L573 152ZM564 135L568 134L573 135L574 135L572 137L569 136L568 139L565 139L563 138L565 141L565 143L567 145L565 146L564 149L560 148L559 144L556 141L557 139L558 137L560 136L563 136L564 135Z",TR:"M624 147L622 147L618 147L613 147L607 148L603 148L602 149L600 150L600 148L596 148L590 150L585 148L582 150L577 148L573 144L573 140L580 138L587 136L593 133L603 135L610 136L615 135L621 136L621 138L624 140L623 144L624 147ZM573 134L578 133L581 135L577 136L573 138L572 137L574 135L573 134Z",AL:"M558 137L557 138L556 140L555 139L554 137L554 134L554 133L555 132L556 132L557 134L557 136L558 137Z",HR:"M546 121L549 122L552 122L554 124L552 125L547 124L545 125L544 126L546 128L548 129L552 132L549 131L544 129L543 127L541 125L539 126L538 124L540 124L541 124L543 123L544 122L546 121Z",CH:"M527 118L526 119L529 120L528 121L525 122L523 122L520 123L518 121L517 120L519 118L521 118L524 117L527 118Z",LU:"M517 111L517 113L516 113L516 112L516 111L517 111Z",BE:"M517 109L516 111L513 111L510 110L507 109L509 107L514 107L517 109Z",NL:"M519 101L519 105L517 106L516 108L511 108L511 107L517 101L519 101Z",PT:"M475 134L477 133L479 134L481 134L481 136L480 138L479 140L480 143L480 145L479 147L477 147L476 145L474 143L474 141L475 138L476 136L475 134Z",ES:"M479 147L480 145L480 143L479 140L480 138L481 136L481 134L479 134L477 133L475 134L474 130L481 129L488 129L495 129L501 132L505 132L508 134L502 136L500 139L500 142L498 145L494 148L488 148L485 150L483 149L479 147Z",IE:"M483 100L481 105L472 106L473 100L479 97L479 100L483 100Z",SB:"M950 279L951 280L949 280L948 278L950 279ZM949 277L947 275L946 273L947 273L948 275L949 277ZM947 277L946 277L944 277L943 277L944 276L945 276L946 277L947 277ZM943 272L944 274L941 272L940 270L943 272ZM936 270L938 270L937 271L936 270L935 269L935 268L936 270Z",NZ:"M991 361L989 365L986 365L987 362L983 360L985 358L985 354L984 351L981 348L981 346L984 348L987 353L988 352L991 355L994 354L995 357L992 359L992 361L991 361ZM971 371L975 368L978 365L980 362L981 365L984 365L983 367L980 370L979 372L976 375L972 379L968 379L963 378L964 375L969 372L971 371Z",AU:"M910 363L912 367L911 370L908 371L906 371L904 367L902 363L907 364L910 363ZM850 339L845 342L843 344L839 344L835 344L831 346L829 347L826 347L821 346L820 343L821 342L822 339L820 335L820 332L818 329L817 326L815 323L815 321L817 323L816 319L815 318L816 315L816 312L817 313L821 310L824 308L826 308L830 306L831 305L836 305L838 302L840 299L842 296L844 297L844 295L845 293L848 291L849 290L850 289L853 288L857 291L860 292L861 288L862 286L865 284L868 284L866 281L869 282L873 283L876 284L878 283L880 284L879 287L878 288L876 291L879 293L882 295L885 297L887 298L891 298L892 296L894 292L893 290L893 286L894 284L895 281L896 280L897 283L898 284L899 287L900 290L902 291L904 293L905 297L906 299L907 303L912 305L913 307L916 312L918 313L919 315L922 318L925 322L925 326L926 331L925 334L925 338L921 342L919 345L918 349L917 353L915 355L909 356L906 358L902 357L901 356L897 357L893 356L889 354L888 350L884 349L884 346L880 348L882 345L883 341L879 345L876 346L874 342L873 341L867 339L860 338L853 340L850 339Z",LK:"M727 229L726 233L722 231L723 223L726 226L727 229Z",CN:"M804 199L802 196L806 194L808 195L806 198L804 199ZM723 132L725 130L728 124L731 119L738 118L741 115L744 113L747 116L753 120L753 124L760 125L765 127L768 131L776 132L783 132L790 134L795 133L803 132L809 129L810 128L811 125L815 126L822 123L826 120L832 120L830 117L826 118L822 117L823 114L827 112L831 109L835 106L834 103L840 102L847 102L852 106L854 109L859 113L864 117L870 116L874 118L872 122L866 124L865 127L863 131L861 131L856 133L854 135L851 136L845 139L839 141L838 141L839 138L835 137L831 141L826 142L830 145L833 147L838 146L840 147L835 150L831 153L835 157L839 162L837 165L839 167L838 172L834 175L830 182L822 187L817 188L815 189L808 191L805 194L805 191L800 190L796 188L794 186L790 187L785 187L782 188L781 191L781 189L778 190L776 186L774 183L771 180L774 176L773 173L770 171L768 170L765 169L759 170L755 173L752 172L749 172L746 172L742 172L736 170L733 169L729 166L725 166L719 162L720 160L719 157L716 151L711 148L708 146L708 143L705 143L705 140L708 138L713 138L717 136L723 133L723 132Z",TW:"M838 182L835 189L834 185L837 180L838 182Z",IT:"M529 120L531 120L534 120L538 122L537 123L534 125L535 128L539 131L544 133L544 135L549 136L551 138L549 138L546 139L547 142L545 144L544 144L545 142L543 139L541 137L538 136L534 134L529 131L527 128L523 127L521 129L519 127L520 124L519 122L522 123L524 122L526 121L529 121L529 120ZM541 144L542 146L542 148L538 147L535 144L541 144ZM524 136L527 137L526 141L523 141L523 136L524 136Z",DK:"M528 97L524 97L522 93L524 91L527 90L529 91L529 93L530 94L527 96L528 97ZM534 94L535 96L534 98L531 96L530 95L534 94Z",GB:"M483 100L481 100L479 100L480 98L479 97L481 97L484 98L483 100ZM491 102L492 100L490 98L486 97L486 95L484 94L484 89L488 87L489 90L495 90L491 95L494 95L499 99L501 103L504 105L504 108L498 109L492 109L487 110L484 111L491 107L486 107L488 105L487 101L491 102Z",IS:"M460 65L462 69L451 73L445 73L440 71L438 69L432 68L439 66L447 66L455 65L460 65Z",AZ:"M629 134L632 136L633 135L636 135L639 137L638 138L637 142L636 144L633 142L633 140L629 142L628 140L627 138L627 137L625 135L628 136L630 136L629 134ZM628 142L625 141L625 140L627 140L628 142Z",GE:"M611 129L614 129L622 131L624 131L627 133L628 134L629 136L626 135L621 136L615 135L615 132L612 130L611 129Z",PH:"M836 215L834 213L837 213L838 214L837 216L836 215ZM841 222L842 220L843 221L844 221L843 224L840 223L841 222ZM851 227L851 230L850 230L849 233L845 233L845 230L842 229L839 231L840 228L843 226L846 226L849 225L851 224L851 227ZM829 224L827 225L831 221L832 221L829 224ZM840 199L840 203L838 206L838 210L841 210L844 213L845 215L841 212L839 212L835 212L836 210L835 210L833 207L834 205L835 199L839 199L840 199ZM839 218L840 218L842 219L839 221L839 218ZM849 216L847 219L848 221L847 220L845 218L847 217L848 215L849 216Z",MY:"M778 232L781 233L783 234L784 233L787 237L787 240L788 242L790 245L788 247L782 242L780 239L778 235L778 232ZM827 239L822 238L820 242L816 247L812 246L809 247L805 246L807 245L809 243L814 241L817 237L819 238L821 236L823 233L825 231L827 233L831 235L829 236L827 239Z",BN:"M821 235L821 236L820 238L819 238L818 239L817 237L818 236L821 235Z",SI:"M538 121L542 120L545 120L546 121L544 123L543 124L541 123L538 124L538 122L538 121Z",FI:"M579 58L583 62L584 67L585 72L588 75L584 78L573 82L564 84L559 81L558 76L562 73L571 69L566 67L565 61L557 58L562 59L569 59L573 56L581 56L579 58Z",SK:"M563 114L561 115L558 115L556 116L555 116L552 116L550 117L547 116L547 115L549 114L550 114L550 113L552 113L553 113L555 113L558 113L563 114Z",CZ:"M542 108L545 109L546 111L549 110L551 111L552 113L550 113L550 114L549 114L547 115L545 115L541 114L538 114L535 112L534 110L537 109L540 108L542 108Z",ER:"M601 210L602 205L603 202L607 200L609 206L614 210L617 213L620 215L618 215L616 213L614 211L609 210L607 210L604 211L601 210Z",JP:"M894 141L892 147L891 150L886 154L877 157L875 154L867 156L867 158L863 164L862 160L859 158L864 155L868 152L877 151L882 148L887 144L889 137L893 135L894 141ZM902 128L904 130L898 133L892 134L888 132L893 129L894 123L900 127L902 128ZM868 157L871 156L874 155L873 158L870 158L868 158L868 157Z",PY:"M338 306L339 311L343 311L346 313L346 317L348 316L349 318L348 321L345 326L340 326L340 321L337 319L331 316L327 308L328 305L336 304L338 306Z",YE:"M644 197L648 204L645 206L642 208L635 211L633 211L630 213L627 213L625 214L624 215L621 215L620 212L619 209L619 208L619 206L620 204L621 201L622 202L626 202L630 202L632 202L636 198L644 197Z",SA:"M597 168L601 168L604 167L606 165L608 161L612 161L624 169L632 169L634 171L637 174L639 176L639 178L640 180L641 181L643 182L643 183L653 188L655 189L644 197L634 200L631 203L629 202L626 202L622 202L620 203L619 205L618 203L616 200L614 196L611 194L608 189L607 184L604 183L603 180L602 178L599 174L596 172L597 170L597 168Z",AQ:"M365 467L370 466L378 468L380 471L375 473L366 475L353 475L350 473L358 471L361 469L365 467ZM316 473L328 473L332 471L334 474L327 475L317 474L316 473ZM295 448L300 448L301 445L302 442L306 442L308 445L310 447L310 449L306 451L299 451L297 451L292 450L295 448ZM216 450L221 450L228 450L233 451L227 451L220 451L216 450ZM159 455L163 454L170 454L166 456L159 455ZM146 454L148 453L151 454L155 455L154 455L150 455L146 454ZM45 468L52 468L57 470L52 471L47 469L45 468ZM0 485L3 484L8 484L11 484L16 485L20 484L31 484L36 485L50 486L69 486L87 488L102 486L92 485L81 483L74 481L76 479L71 477L64 475L78 475L86 475L93 473L89 471L79 470L69 470L63 468L60 464L64 465L73 464L80 465L87 464L94 462L93 460L97 459L103 459L111 459L118 458L124 456L128 457L136 457L144 456L152 457L160 457L167 457L174 456L180 456L185 456L188 458L194 458L201 459L209 458L217 459L222 458L219 456L214 455L212 452L218 452L225 453L229 454L236 454L243 453L250 454L254 453L261 453L267 454L274 455L277 453L284 454L288 455L295 455L301 454L309 453L313 451L313 449L311 447L310 445L310 443L312 440L312 438L313 436L317 434L321 432L323 430L328 429L331 428L336 427L339 426L340 427L336 429L332 429L328 430L326 432L327 434L323 435L320 437L318 439L320 441L324 442L326 444L328 446L330 450L331 452L331 455L328 457L323 458L317 460L310 461L304 463L295 463L285 463L291 465L295 466L288 467L283 469L287 471L291 473L302 474L311 476L324 477L334 479L338 481L346 479L357 478L369 477L381 478L387 476L399 475L410 474L421 473L418 471L412 470L401 471L401 468L406 466L414 465L420 463L427 462L434 462L441 461L447 460L454 458L457 456L455 454L460 453L466 451L469 449L475 448L479 449L481 447L485 448L492 448L498 448L502 448L508 447L514 446L520 445L524 445L528 446L533 446L537 444L542 446L547 444L553 444L560 445L563 446L569 446L575 446L581 445L586 444L591 443L594 440L598 442L603 442L607 444L611 442L617 441L623 440L627 438L632 438L636 436L641 436L644 434L649 433L654 433L659 434L661 436L666 437L671 439L676 438L681 438L686 438L691 439L694 442L691 444L689 446L691 447L689 450L694 451L699 449L701 447L704 445L707 444L713 443L717 442L720 440L725 439L728 437L733 437L738 436L743 436L745 435L749 437L754 436L760 437L764 437L769 437L774 436L779 436L782 434L787 433L791 434L798 436L803 436L808 435L813 434L818 434L821 435L826 436L833 437L838 436L842 435L848 435L853 435L858 435L863 435L869 434L874 434L875 431L877 433L879 435L885 436L891 436L897 436L904 436L906 438L910 439L917 440L924 441L929 440L933 442L939 443L944 444L949 446L955 446L961 447L968 447L974 448L975 450L973 452L970 455L965 456L960 458L956 460L954 462L954 464L956 466L963 468L959 469L949 470L947 473L944 475L949 477L955 479L963 481L971 483L979 484L989 484L1000 485L0 485Z",CY:"M591 152L592 152L593 152L593 153L594 153L590 154L591 152Z",MA:"M494 152L495 156L497 159L493 161L490 162L487 165L483 167L476 170L476 173L474 175L472 175L468 175L467 178L461 184L459 189L453 191L453 189L455 187L456 184L458 182L459 179L462 176L464 173L468 172L471 169L473 163L474 160L479 156L483 152L486 151L490 152L494 152Z",EG:"M602 189L581 189L569 179L569 167L569 164L574 162L579 164L582 163L586 162L589 164L592 164L595 163L597 168L596 171L594 173L592 171L590 167L593 173L596 179L599 184L599 186L602 189Z",LY:"M569 189L566 194L555 190L541 186L538 186L532 183L529 182L528 180L527 176L527 173L527 170L526 166L528 164L530 162L532 160L535 159L539 159L544 163L550 165L554 165L555 162L558 159L564 159L566 161L569 161L569 164L569 167L569 179L569 189Z",ET:"M633 228L621 236L617 238L614 239L611 239L608 240L607 240L602 238L599 237L598 235L595 231L593 229L592 227L594 226L595 220L597 219L600 215L601 210L605 208L609 209L611 210L614 212L617 214L617 216L616 218L618 219L619 220L619 222L621 224L633 228Z",DJ:"M618 215L620 215L620 217L620 218L618 219L616 219L616 218L618 215Z",UG:"M594 253L585 253L583 254L582 252L583 248L585 246L587 244L586 240L589 240L593 239L596 240L597 245L595 249L594 253Z",RW:"M584 253L585 256L583 257L581 258L581 256L582 254L584 253Z",BA:"M552 132L548 129L546 128L544 126L545 125L547 124L552 125L554 125L554 128L553 129L552 130L552 132Z",MK:"M562 132L564 135L563 136L560 136L557 136L557 134L558 133L560 133L562 132Z",RS:"M552 122L556 122L558 124L560 126L562 126L562 127L562 128L564 130L562 132L560 133L560 132L560 131L559 131L558 130L557 130L556 131L555 130L554 130L554 129L553 127L553 125L553 124L552 122Z",ME:"M556 132L555 131L554 134L552 133L552 132L553 129L554 130L555 130L556 131L556 132Z",XK:"M557 134L556 132L556 131L557 130L558 130L559 131L560 131L560 132L560 133L558 133L557 134Z",TT:"M329 220L330 220L331 220L331 222L328 222L329 221L329 220Z",SS:"M586 240L583 237L580 238L578 238L576 235L573 232L570 229L568 227L567 226L569 223L572 221L574 223L575 223L578 224L581 223L582 222L586 223L588 221L590 218L591 217L592 216L592 220L594 222L594 224L594 227L592 228L595 230L596 232L596 237L593 239L589 240L586 240Z"};function gs(e){if(e.length<4)return null;let t=1/0,n=-1/0,r=1/0,s=-1/0;for(let a=0;a+1<e.length;a+=2){let o=e[a],L=e[a+1];!Number.isFinite(o)||!Number.isFinite(L)||(o<t&&(t=o),o>n&&(n=o),L<r&&(r=L),L>s&&(s=L))}return Number.isFinite(t)?{minX:t,maxX:n,minY:r,maxY:s}:null}function hs(e){return e.maxX-e.minX>=700&&e.maxY-e.minY<=10}function vs(e){return[...e.matchAll(/-?\d+(?:\.\d+)?/g)].map(t=>Number(t[0]))}function bs(e){let t=[],n=/[Mm][^Mm]*/g,r;for(;r=n.exec(e);){let s=r[0].trim();s&&t.push(s)}return t}function ys(e){let t=gs(vs(e));return!!(t&&hs(t))}function ks(e){let t=[...e.matchAll(/[A-Za-z]|-?\d+(?:\.\d+)?/g)].map(L=>L[0]);if(t.length<5)return e;let n=[],r="",s=NaN,a=NaN,o=0;for(;o<t.length;){let L=t[o];if(/^[A-Za-z]$/.test(L)){r=L,n.push(L),o++;continue}let c=Number(L);if(r==="H"||r==="h"){Number.isFinite(s)&&Math.abs(c-s)>=700?n.push("M",String(c),String(a)):n.push(L),s=c,o++;continue}if(r==="V"||r==="v"){n.push(L),a=c,o++;continue}if(o+1>=t.length){n.push(L),o++;continue}let p=c,u=Number(t[o+1]);Number.isFinite(s)&&Number.isFinite(a)&&Math.abs(p-s)>=700&&Math.abs(u-a)<=10?n.push("M",String(p),String(u)):n.push(L,t[o+1]),s=p,a=u,o+=2}return n.join(" ")}function nt(e){return bs(e).filter(t=>!ys(t)).map(ks).join("")}function j(e,t=220,n=56){if(!e.length||e.every(c=>c===0))return`<svg class="spark" viewBox="0 0 ${t} ${n}" preserveAspectRatio="none"><line x1="0" y1="${n-2}" x2="${t}" y2="${n-2}" stroke="var(--hair)" /></svg>`;let r=Math.max(...e,1),s=e.length>1?t/(e.length-1):t,a=e.map((c,p)=>`${(p*s).toFixed(1)},${(n-c/r*(n-4)-2).toFixed(1)}`),o=`M0,${n} L${a.join(" L")} L${t},${n} Z`,L=`M${a.join(" L")}`;return`<svg class="spark" viewBox="0 0 ${t} ${n}" preserveAspectRatio="none">
    <path d="${o}" fill="url(#spark-fill)" />
    <path d="${L}" fill="none" stroke="var(--chart-4)" stroke-width="1.5" />
  </svg>`}function G(e,t=220,n=56){if(!e.length||e.every(o=>o===0))return`<svg class="spark" viewBox="0 0 ${t} ${n}" preserveAspectRatio="none"><line x1="0" y1="${n/2}" x2="${t}" y2="${n/2}" stroke="var(--hair)" /></svg>`;let r=Math.max(...e,1),s=e.length>1?t/(e.length-1):t,a=e.map((o,L)=>`${(L*s).toFixed(1)},${(n-o/r*(n-6)-3).toFixed(1)}`);return`<svg class="spark" viewBox="0 0 ${t} ${n}" preserveAspectRatio="none">
    <path d="M${a.join(" L")}" fill="none" stroke="var(--chart-4)" stroke-width="1.6" />
  </svg>`}function xs(e,t){return{x:(t+180)/360*1e3,y:(90-e)/180*500}}var ws="#2563EB",Rn="#E5E7EB",_s="#FFFFFF",Ss="#6B7280",Ms="#111827",As="#10B981";function rt(e,t=220,n=36){if(!e.length||e.every(c=>c===0))return`<svg class="spark bars" viewBox="0 0 ${t} ${n}" preserveAspectRatio="none"><line x1="0" y1="${n-2}" x2="${t}" y2="${n-2}" stroke="#EDEDED" /></svg>`;let r=Math.max(...e,1),s=1.5,a=e.length,o=Math.max(1.5,(t-s*(a+1))/a),L=e.map((c,p)=>{if(c<=0)return"";let u=Math.max(2.4,c/r*(n-4));return`<rect x="${(s+p*(o+s)).toFixed(1)}" y="${(n-u).toFixed(1)}" width="${o.toFixed(1)}" height="${u.toFixed(1)}" fill="${ws}" rx="0.6" />`}).join("");return`<svg class="spark bars" viewBox="0 0 ${t} ${n}" preserveAspectRatio="none">${L}</svg>`}var Es=[{id:"na",x:200,y:130,isos:["US","CA","MX","GT","BZ","HN","SV","NI","CR","PA","CU","HT","DO","JM","PR"]},{id:"sa",x:300,y:340,isos:["BR","AR","CL","PE","CO","VE","EC","BO","PY","UY","GY","SR"]},{id:"eu",x:520,y:115,isos:["GB","IE","FR","DE","ES","PT","IT","NL","BE","CH","AT","PL","SE","NO","FI","DK","CZ","HU","RO","GR","UA","RU"]},{id:"af",x:530,y:270,isos:["MA","DZ","TN","EG","LY","SD","NG","GH","CI","SN","KE","ET","TZ","UG","ZA","AO","CD","CM"]},{id:"as",x:760,y:155,isos:["TR","SA","AE","IL","IQ","IR","IN","PK","BD","CN","JP","KR","TW","HK","TH","VN","ID","MY","PH","SG","MN"]},{id:"oc",x:870,y:380,isos:["AU","NZ","PG","FJ"]}];function Cn(e,t="stat-choro"){let n=new Map(e.map(a=>[a.iso,a.devices])),r=Math.max(1,...e.map(a=>a.devices)),s="";for(let[a,o]of Object.entries(tt)){let L=n.get(a)??0,c=L?`rgba(37,99,235,${(.2+L/r*.7).toFixed(2)})`:"#F3F4F6";s+=`<path data-iso="${a}" d="${nt(o)}" fill="${c}" stroke="#F5F5F5" stroke-width="0.35" />`}return`<svg class="${t}" viewBox="0 0 1000 500" role="img" aria-label="Countries">
    <rect width="1000" height="500" fill="#F8F8F8"/>
    ${s}
  </svg>`}function Pn(e="world shoey-world"){let t="";for(let[n,r]of Object.entries(tt)){let s=nt(r);s&&(t+=`<path class="world-land" data-iso="${n}" d="${s}" fill="${Rn}" stroke="${Ss}" stroke-width="1.15" />`)}return`<svg class="${e}" viewBox="0 0 1000 500" width="1000" height="500" preserveAspectRatio="xMidYMid meet" role="img" aria-label="Unique seats by country" data-land="${Rn}">
    <rect class="world-ocean" width="1000" height="500" fill="${_s}"/>
    ${t}
  </svg>`}var xe=Pn();function $n(e,t,n="world shoey-world"){let r=new Map(e.map(p=>[p.iso,p.devices])),s=e.length===0&&t.length===0,a=s?"":t.map(p=>{let u=xs(p.lat,p.lon);return`<circle class="seat-dot" cx="${u.x.toFixed(1)}" cy="${u.y.toFixed(1)}" r="4.2" fill="${Ms}" stroke="#fff" stroke-width="1.2" />`}).join(""),o=s?"":Es.map(p=>{let u=p.isos.filter(h=>(r.get(h)??0)>0),l=u.reduce((h,k)=>h+(r.get(k)??0),0);if(!l)return"";let d=u.length===1?Rs(u[0]):`${u.length} countries`,g=Math.max(96,36+d.length*6.4);return`<g class="pill-g" transform="translate(${p.x},${p.y})">
          <rect x="0" y="-13" width="${g}" height="26" rx="13" fill="#fff" stroke="#E5E5E5"/>
          <circle cx="12" cy="0" r="4" fill="${As}"/>
          <text x="22" y="4" font-size="11" font-weight="650" fill="#18181B">${l}</text>
          <line x1="42" y1="-7" x2="42" y2="7" stroke="#E5E5E5"/>
          <text x="48" y="4" font-size="11" fill="#71717A">${Cs(d)}</text>
        </g>`}).join(""),L=s?'<div class="empty map-empty">No heartbeats yet. The map stays empty until a seat checks in. Empty is an empty world, not sample dots.</div>':"",c=Pn(n).replace("</svg>",`${a}${o}</svg>`);return`${L}${c}`}function Rs(e){return{US:"United States",CA:"Canada",BR:"Brazil",GB:"United Kingdom",FR:"France",DE:"Germany",AU:"Australia",JP:"Japan",IN:"India"}[e]||e}function Cs(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/"/g,"&quot;")}var Ps={pending:"Pending",in_progress:"In progress",in_review:"In review",submitted:"Submitted",success:"Success",failed:"Failed",expired:"Expired"},$s={pending:'<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/>',failed:'<circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/>',success:'<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',in_progress:'<circle cx="12" cy="12" r="10" stroke-dasharray="4 4"/>',in_review:'<path d="M3 7V5a2 2 0 0 1 2-2h2"/><path d="M17 3h2a2 2 0 0 1 2 2v2"/><path d="M21 17v2a2 2 0 0 1-2 2h-2"/><path d="M7 21H5a2 2 0 0 1-2-2v-2"/><circle cx="12" cy="12" r="3"/><path d="m16 16 1.5 1.5"/>',expired:'<circle cx="12" cy="12" r="10"/><path d="M12 6v6l3 2"/>',submitted:'<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>'},Ts={pending:"pending",failed:"failed",success:"success",expired:"expired",submitted:"submitted","in-progress":"in_progress",in_progress:"in_progress","in-review":"in_review",in_review:"in_review","dead-letter":"expired",dead_letter:"expired"};function Os(e){return typeof e!="string"?null:Ts[e.trim().toLowerCase()]??null}function st(e,t){let n=Os(e);if(!n)return"";let r=t?.label??Ps[n];return`<span class="status-badge status-${n}" data-status="${n}">
    <svg class="status-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${$s[n]}</svg>
    <span>${Is(r)}</span>
  </span>`}function Is(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/"/g,"&quot;")}var Tn=`
.status-badge {
  display: inline-flex; align-items: center; gap: 5px;
  border: 1px solid var(--hair); border-radius: 999px;
  padding: 2px 8px 2px 6px;
  font-family: var(--mono); font-size: 10px; letter-spacing: 0.04em;
  text-transform: uppercase; color: var(--ink2); background: rgba(255,255,255,0.03);
}
.status-icon { width: 11px; height: 11px; flex: 0 0 auto; }
.status-pending { color: #e4c36a; border-color: rgba(228,195,106,0.28); }
.status-failed { color: var(--danger); border-color: rgba(240,113,122,0.28); }
.status-success { color: var(--ok); border-color: rgba(131,192,146,0.28); }
.status-in_progress { color: #7dd3fc; border-color: rgba(125,211,252,0.28); }
.status-in_review { color: #facc15; border-color: rgba(250,204,21,0.28); }
.status-expired { color: #a1a1aa; border-color: rgba(161,161,170,0.28); }
.status-submitted { color: #a78bfa; border-color: rgba(167,139,250,0.32); }
.tab.on .status-badge { background: rgba(10,10,11,0.06); }
`;var On=`/* M\xE9tis Operator SPA \u2014 Shoey Overview / Realtime / Events */
@import url('https://cdn.jsdelivr.net/npm/geist@1.3.1/dist/fonts/geist-sans/style.min.css');
@import url('https://cdn.jsdelivr.net/npm/geist@1.3.1/dist/fonts/geist-mono/style.min.css');
:root {
  --bg: #FFFFFF;
  --panel: #FFFFFF;
  --hair: #EDEDED;
  --ink: #18181B;
  --ink2: #71717A;
  --ink3: #A1A1AA;
  --accent: #2563EB;
  --ok: #16A34A;
  --danger: #DC2626;
  --live: #10B981;
  --land: #E5E7EB;
  --ocean: #FFFFFF;
  --land-stroke: #6B7280;
  --chart-1: #EFF6FF;
  --chart-2: #BFDBFE;
  --chart-3: #60A5FA;
  --chart-4: #2563EB;
  --chart-5: #1D4ED8;
  --nav: #FFFFFF;
  --nav-on: #F4F4F5;
  --mono: ui-monospace, SFMono-Regular, 'Geist Mono', monospace;
  --sans: Inter, Geist, system-ui, sans-serif;
}
[data-theme="dark"] {
  --bg: #0a0a0b;
  --panel: #111113;
  --hair: rgba(255,255,255,0.10);
  --ink: rgba(255,255,255,0.94);
  --ink2: rgba(255,255,255,0.55);
  --ink3: rgba(255,255,255,0.38);
  --land: #3f3f46;
  --ocean: #0a0a0b;
  --land-stroke: #111827;
  --nav: #0d0d0f;
  --nav-on: rgba(255,255,255,0.08);
}
* { box-sizing: border-box; }
html { color-scheme: light; }
html[data-theme="dark"] { color-scheme: dark; }
html, body { margin: 0; height: 100%; color: var(--ink); background: var(--bg); font: 12px/1.4 var(--sans); }
body { background: var(--bg); color: var(--ink); }
a { color: var(--accent); text-decoration: none; }
.shell { display: grid; grid-template-columns: 185px 1fr; min-height: 100%; }
.rail {
  display: flex; flex-direction: column; gap: 8px;
  background: var(--nav); border-right: 1px solid var(--hair);
  padding: 12px 10px 14px; min-height: 100vh; position: sticky; top: 0;
  width: 185px;
}
.rail-brand { display: flex; align-items: center; gap: 8px; }
.rail-logo {
  width: 28px; height: 28px; border-radius: 999px; background: #2563EB; color: #fff;
  display: grid; place-items: center; font: 700 10px/1 var(--sans); letter-spacing: -0.04em;
}
.rail-brand h1 { margin: 0; font-size: 13px; font-weight: 650; letter-spacing: -0.03em; }
.rail-brand .chev { color: var(--ink3); font-size: 11px; }
.rail nav { display: flex; flex-direction: column; gap: 14px; flex: 1; }
.nav-sec { display: flex; flex-direction: column; gap: 1px; }
.nav-sec p {
  font-size: 11px; letter-spacing: 0.02em; color: var(--ink3); margin: 8px 8px 4px; font-weight: 550;
}
.nav-item {
  display: block; padding: 6px 8px; border-radius: 6px; color: var(--ink);
  font-size: 12px; font-weight: 500;
}
.nav-item:hover { background: var(--nav-on); }
.nav-item.on { background: var(--nav-on); font-weight: 600; }
.rail-foot { margin-top: auto; display: flex; flex-direction: column; gap: 8px; padding-top: 12px; }
.rail-utils { display: flex; gap: 8px; flex-wrap: wrap; }
.rail-utils a, .rail-utils button { color: var(--ink2); font-size: 11px; background: none; border: 0; cursor: pointer; padding: 0; }
.who { font-family: var(--mono); font-size: 10px; color: var(--ink2); word-break: break-all; }
.theme-btn {
  border: 1px solid var(--hair); background: transparent; color: var(--ink2);
  font: 11px/1 var(--mono); letter-spacing: 0.06em; text-transform: uppercase;
  padding: 6px 8px; border-radius: 8px; cursor: pointer;
}
.main { min-width: 0; background: var(--bg); }
.top {
  display: flex; align-items: center; justify-content: space-between; gap: 12px;
  padding: 10px 16px; border-bottom: 1px solid var(--hair); background: var(--panel);
  position: sticky; top: 0; z-index: 4;
}
.top-left, .top-right { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.tool {
  border: 1px solid var(--hair); background: var(--panel); color: var(--ink);
  border-radius: 8px; padding: 6px 10px; font: 12px var(--sans); cursor: pointer;
}
.top-search {
  flex: 1; min-width: 180px; border: 1px solid var(--hair); background: var(--panel); color: var(--ink);
  border-radius: 8px; padding: 7px 12px; font: 12px var(--sans);
}
.live-dot {
  display: inline-flex; align-items: center; gap: 6px; font: 12px/1 var(--sans); color: var(--ink);
  border: 1px solid var(--hair); border-radius: 999px; padding: 5px 10px; background: var(--panel);
}
.live-dot i { width: 7px; height: 7px; border-radius: 99px; background: var(--live); display: inline-block; }
.top h2 { margin: 0; font-size: 16px; font-weight: 650; letter-spacing: -0.03em; }
.eyebrow {
  font-size: 10px; letter-spacing: 0.12em;
  text-transform: uppercase; color: var(--ink3); margin: 0 0 8px; font-weight: 600;
}
.wrap { padding: 14px 16px 36px; display: grid; gap: 12px; }
.kpis { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; }
.kpis-extra { display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); gap: 10px; }
.ov-10 { display: grid; grid-template-columns: repeat(5, minmax(0, 1fr)); gap: 10px; }
.stat-card {
  background: var(--panel); border: 1px solid var(--hair); border-radius: 10px;
  padding: 12px 12px 0; overflow: hidden; min-width: 0; color: var(--ink);
}
.stat-card-head { display: flex; justify-content: space-between; align-items: center; gap: 8px; }
.stat-card h3 { margin: 0; font-size: 13px; font-weight: 600; letter-spacing: -0.02em; color: var(--ink); }
.trend-badge {
  font: 600 11px var(--sans); padding: 2px 7px; border-radius: 999px;
  border: 1px solid rgba(22,163,74,0.2); background: rgba(22,163,74,0.08); color: #16A34A;
}
.trend-badge.down { border-color: rgba(220,38,38,0.2); background: rgba(220,38,38,0.08); color: #DC2626; }
.trend-badge.flat { border-color: var(--hair); background: var(--nav-on); color: var(--ink2); }
.stat-flow { display: flex; align-items: baseline; gap: 8px; margin: 10px 0 4px; }
.stat-flow .n { font-size: 28px; font-weight: 650; letter-spacing: -0.04em; line-height: 1; color: var(--ink); }
.stat-flow .lbl { font-size: 11px; color: var(--ink2); }
.stat-card .spark, .stat-card .stat-spark { display: block; width: calc(100% + 24px); margin: 6px -12px 0; height: 72px; }
.stat-gauge, .stat-ring { height: 64px; margin-left: auto; margin-right: auto; width: 88px; }
.stat-choro-wrap { margin: 6px -12px 0; height: 78px; overflow: hidden; }
.stat-choro { display: block; width: 100%; height: 78px; }
.ov-chips { display: flex; flex-wrap: wrap; gap: 6px; }
.ov-chip {
  display: inline-flex; align-items: center; gap: 6px;
  border: 1px solid var(--hair); border-radius: 999px; padding: 4px 10px;
  font-size: 11px; color: var(--ink2); background: var(--panel);
}
.ov-chip b { color: var(--ink); font-weight: 600; }
.ev-grid { display: grid; grid-template-columns: 1fr; gap: 12px; align-items: start; }
.ev-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; margin: 0 0 10px; }
.ev-sub { margin: 4px 0 0; font-size: 12px; }
.ev-tabs { margin: 0 0 10px; }
.page-hero { display: grid; gap: 4px; margin: 2px 0 4px; }
.page-title { margin: 0; font-size: 22px; font-weight: 650; letter-spacing: -0.04em; color: var(--ink); }
.page-sub { margin: 0; font-size: 13px; color: var(--ink2); }
.page-tabs { display: flex; flex-wrap: wrap; gap: 4px; margin: 8px 0 12px; }
.page-tab {
  border: 0; background: transparent; color: var(--ink2);
  font: 500 13px/1 var(--sans); padding: 7px 12px; border-radius: 8px; cursor: pointer;
}
.page-tab.on { background: #F4F4F5; color: #18181B; font-weight: 600; }
[data-theme="dark"] .page-tab.on { background: rgba(255,255,255,0.08); color: rgba(255,255,255,0.94); }
.page-tabs.underline { gap: 16px; border-bottom: 1px solid var(--hair); padding-bottom: 0; }
.page-tabs.underline .page-tab { border-radius: 0; padding: 8px 2px 10px; }
.page-tabs.underline .page-tab.on {
  background: transparent; color: var(--ink);
  box-shadow: inset 0 -2px 0 #18181B;
}
[data-theme="dark"] .page-tabs.underline .page-tab.on { box-shadow: inset 0 -2px 0 #f4f4f5; }
.page-toolbar {
  display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin: 0 0 10px;
}
.page-toolbar .toolbar-search { flex: 1; min-width: 160px; margin-bottom: 0; }
.page-toolbar .page-view { margin-left: auto; }
.page-toolbar .tool { display: inline-flex; align-items: center; gap: 6px; }
.tool-ic { width: 14px; height: 14px; display: block; flex-shrink: 0; }
.search-wrap {
  position: relative; flex: 1; min-width: 180px; display: flex; align-items: center;
}
.search-wrap .tool-ic {
  position: absolute; left: 10px; color: var(--ink3); pointer-events: none;
}
.search-wrap .toolbar-search { padding-left: 32px; width: 100%; }
.listen-pill, .live-events {
  display: inline-flex; align-items: center; gap: 6px;
  border: 1px solid var(--hair); background: var(--panel); border-radius: 999px;
  padding: 5px 10px; font-size: 12px; font-weight: 600; color: var(--ink);
}
.listen-pill i, .live-events i {
  width: 8px; height: 8px; border-radius: 999px; background: var(--live);
  box-shadow: 0 0 0 3px rgba(16,185,129,0.16);
}
.table-frame { min-height: 280px; }
.empty-data {
  display: grid; justify-items: center; gap: 8px; text-align: center;
  padding: 48px 16px; color: var(--ink);
}
.empty-data strong { font-size: 14px; font-weight: 650; }
.empty-data p { margin: 0; color: var(--ink2); font-size: 12px; }
.empty-dash {
  width: 36px; height: 36px; border: 1.5px dashed var(--ink3); border-radius: 8px;
}
.stat-line {
  display: flex; justify-content: space-between; gap: 12px;
  padding: 8px 2px; border-bottom: 1px solid var(--hair); font-size: 13px;
}
.stat-line b { font-weight: 650; }
.ev-table-card { padding-top: 12px; }
.ev-names { display: flex; flex-direction: column; gap: 2px; max-height: 560px; overflow: auto; }
.grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; }
.card {
  position: relative;
  background: var(--panel);
  border: 1px solid var(--hair);
  border-radius: 8px;
  padding: 10px 12px 0;
  overflow: hidden;
  color: var(--ink);
}
.card h3 { margin: 0; font-size: 13px; font-weight: 600; color: var(--ink); }
.kpi-top { display: flex; justify-content: space-between; align-items: flex-start; gap: 8px; }
.kpi { padding-bottom: 8px; }
.kpi .eyebrow { margin-bottom: 4px; }
.kpi .n { font-size: 28px; font-weight: 650; letter-spacing: -0.04em; line-height: 1; margin-top: 6px; color: var(--ink); }
.rt-h { margin: 0; font-size: 16px; font-weight: 650; letter-spacing: -0.03em; color: var(--ink); }
.rt-n { font-size: 44px !important; margin-top: 8px !important; letter-spacing: -0.05em; }
.rt-unique { padding-top: 14px; }
.delta { font-size: 11px; font-weight: 600; }
.delta.up { color: var(--ok); }
.delta.down { color: var(--danger); }
.delta.flat { color: var(--ink3); }
.rt-grid { display: grid; grid-template-columns: minmax(220px, 28%) minmax(0, 1fr); gap: 16px; align-items: stretch; }
.rt-map { min-width: 0; min-height: 480px; }
.rt-map #map-root { min-height: 480px; height: 100%; background: #FFFFFF; }
#map-root[data-land="inline"] { min-height: 480px; background: #FFFFFF; }
#map-root[data-land="inline"] svg.shoey-world {
  display: block; width: 100%; height: auto; min-height: 480px;
}
[data-theme="dark"] .rt-map #map-root,
[data-theme="dark"] #map-root[data-land="inline"] { background: #0a0a0b; }
.rt-map .world.shoey-world { min-height: 480px; max-height: none; }
.rt-stream { display: flex; flex-direction: column; gap: 2px; max-height: 420px; overflow: auto; }
.rt-row {
  display: flex; align-items: center; justify-content: space-between; gap: 8px;
  padding: 6px 2px; border-bottom: 1px solid var(--hair); font-size: 11px;
}
.rt-row .ago { color: var(--ink3); font-size: 11px; white-space: nowrap; }
.rt-ics { display: inline-flex; gap: 3px; margin-left: 6px; vertical-align: middle; }
.ic-mac, .ic-win, .ic-desk {
  display: inline-block; width: 12px; height: 12px; border-radius: 2px; background: #2563EB;
}
.ic-win { background: #0A84FF; }
.ic-desk { background: #71717A; }
.vol { position: relative; }
.vol-row {
  display: grid; grid-template-columns: 1fr 56px 64px; gap: 8px; align-items: center;
  padding: 5px 8px; position: relative; font-size: 11px;
}
.vol-bar {
  position: absolute; inset: 2px auto 2px 0; background: var(--nav-on); border-radius: 4px; z-index: 0;
}
.vol-bar.blue { background: #DBEAFE; }
[data-theme="dark"] .vol-bar.blue { background: rgba(37,99,235,0.28); }
.vol-row > * { position: relative; z-index: 1; }
.table-card .tabs { margin: 0 0 8px; }
.table-search {
  width: 100%; border: 1px solid var(--hair); border-radius: 8px; padding: 6px 10px;
  font: 12px var(--sans); margin-bottom: 8px;
  background: var(--panel); color: var(--ink);
}
.empty-card { background: var(--panel); border: 1px solid var(--hair); border-radius: 8px; padding: 28px 20px; }
.empty-card h3 { margin: 0 0 6px; font-size: 16px; }
.empty-card p { margin: 0; color: var(--ink2); }
.kpi .sub { font-family: var(--mono); font-size: 10px; color: var(--ink3); margin: 4px 0 8px; }
.spark { display: block; width: calc(100% + 24px); margin: 0 -12px; height: 56px; }
.chart { display: block; width: 100%; height: 140px; }
.world { display: block; width: 100%; height: auto; max-height: 420px; }
.world.shoey-world {
  width: 100%; height: auto; max-height: none; min-height: 0;
  aspect-ratio: 2 / 1; background: #FFFFFF;
}
.world.shoey-world.ov { min-height: 0; max-height: 220px; }
.world.shoey-world .world-ocean { fill: #FFFFFF; }
.world.shoey-world path.world-land, .world.shoey-world path[data-iso] {
  fill: #E5E7EB !important;
  stroke: #6B7280 !important;
  stroke-width: 1.15;
  vector-effect: none;
}
[data-theme="dark"] .world.shoey-world { background: #0a0a0b; }
[data-theme="dark"] .world.shoey-world .world-ocean { fill: #0a0a0b; }
[data-theme="dark"] .world.shoey-world path.world-land,
[data-theme="dark"] .world.shoey-world path[data-iso] {
  fill: #3f3f46 !important;
  stroke: #111827 !important;
}
.world.shoey-world .seat-dot { fill: #111827; stroke: #fff; }
[data-theme="dark"] .world.shoey-world .seat-dot { fill: #F8FAFC; stroke: #0a0a0b; }
.heat { display: block; width: 100%; max-width: 280px; height: auto; }
.grat { stroke: color-mix(in srgb, var(--ink) 18%, transparent); stroke-width: 0.6; }
.dot { fill: var(--accent); stroke: var(--bg); stroke-width: 0.8; }
.tick { fill: var(--ink3); font-size: 9px; font-family: var(--mono); }
.tabs { display: flex; flex-wrap: wrap; gap: 4px; margin: 0 0 8px; }
.tab {
  border: 1px solid transparent; background: transparent; color: var(--ink2);
  font: 11px/1 var(--mono); letter-spacing: 0.04em; text-transform: uppercase;
  padding: 4px 9px; border-radius: 999px; cursor: pointer;
}
.tab.on { background: #18181b; color: #ffffff; }
[data-theme="dark"] .tab.on { background: #f4f4f5; color: #0a0a0b; }
.tab.on .status-badge { color: inherit; border-color: currentColor; background: transparent; }
.pill {
  display: inline-block; padding: 1px 7px; border-radius: 999px; font-size: 10px;
  font-family: var(--mono); border: 1px solid var(--hair); color: var(--ink2);
}
.pill.up, .pill.hit { color: var(--ok); }
.pill.down { color: var(--danger); }
.chip {
  display: inline-flex; align-items: center; gap: 4px;
  padding: 2px 8px; border-radius: 999px; border: 1px solid var(--hair);
  font-family: var(--mono); font-size: 10px; color: var(--ink2); background: var(--nav-on);
}
.empty { color: var(--ink2); font-size: 12px; padding: 10px 0 12px; }
.fail-loud { color: var(--danger); font-size: 13px; font-weight: 600; padding: 10px 0 12px; }
.key-form { display: grid; gap: 8px; margin: 0 0 14px; }
.key-form .row input, .key-form .row select {
  border: 1px solid var(--hair); background: var(--bg); color: var(--ink);
  border-radius: 8px; padding: 6px 8px; font: 12px var(--sans); min-width: 120px;
}
.map-empty { position: absolute; left: 12px; top: 42px; z-index: 1; }
table { width: 100%; border-collapse: collapse; }
th, td { text-align: left; padding: 6px 6px; border-bottom: 1px solid var(--hair); font-size: 11px; vertical-align: top; }
th { color: var(--ink3); font-weight: 500; font-family: var(--mono); font-size: 10px; letter-spacing: 0.08em; text-transform: uppercase; }
button, .btn {
  background: transparent; color: var(--ink); border: 1px solid var(--hair);
  padding: 4px 9px; font-size: 11px; cursor: pointer; border-radius: 999px;
}
button.primary { background: var(--chart-5); color: #ffffff; border-color: transparent; font-weight: 600; }
.key-msg { padding: 8px 0; font-size: 12px; }
.key-msg.ok { color: var(--ok); font-weight: 600; }
article[data-cf-overview], article[data-cf-page] { background: var(--panel); color: var(--ink); }
button.danger { color: var(--danger); }
pre, textarea {
  width: 100%; background: color-mix(in srgb, var(--bg) 70%, #000); color: var(--ink);
  border: 1px solid var(--hair); padding: 8px; font: 11px var(--mono);
}
textarea { min-height: 120px; }
.row { display: flex; gap: 6px; flex-wrap: wrap; align-items: center; }
.muted { color: var(--ink2); }
.legend { display: flex; gap: 12px; font-family: var(--mono); font-size: 10px; color: var(--ink3); padding: 6px 0 10px; }
.legend i { display: inline-block; width: 10px; height: 2px; background: var(--chart-5); vertical-align: middle; margin-right: 4px; }
.legend i.ask { background: var(--accent); }
.funnel { display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 8px; }
.crm-funnel { display: grid; gap: 6px; margin: 0 0 10px; }
.crm-funnel-row { display: grid; grid-template-columns: 88px 1fr auto; gap: 8px; align-items: center; }
.crm-funnel-track { height: 6px; background: var(--nav-on); border: 1px solid var(--hair); position: relative; overflow: hidden; }
.crm-funnel-ok { position: absolute; inset: 0 auto 0 0; background: var(--ok); opacity: 0.7; }
.crm-funnel-fail { position: absolute; inset: 0 0 0 auto; background: var(--danger); opacity: 0.7; }
.crm-kpis { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 8px; margin: 0 0 10px; }
.crm-kpis .n { font-size: 22px; margin-top: 4px; }
.remote a { color: var(--accent); }
.heat-wrap { display: flex; gap: 16px; align-items: flex-start; }
.heat-meta { font-family: var(--mono); font-size: 10px; color: var(--ink3); }
.event {
  display: grid; grid-template-columns: 130px 1.1fr 1.1fr 1fr 90px 90px; gap: 10px; align-items: center;
  padding: 10px 8px; border-bottom: 1px solid var(--hair); font-size: 12px;
}
.event-head {
  font-size: 10px; letter-spacing: 0.08em; text-transform: uppercase; color: var(--ink3);
  font-weight: 550; padding-bottom: 6px;
}
.event-name { font-weight: 650; }
.event-profile { color: var(--ink2); }
.event-country, .event-os, .event-browser { color: var(--ink2); }
.event-chips { display: flex; flex-wrap: wrap; gap: 4px; }
.event-time { font-family: var(--sans); font-size: 12px; color: var(--ink3); text-align: left; }
.live { display: inline-block; padding: 1px 7px; border-radius: 999px; background: #18181b; color: #fff; font: 10px var(--mono); letter-spacing: 0.08em; }
[data-theme="dark"] .live { background: #f4f4f5; color: #0a0a0b; }
.page[hidden] { display: none !important; }
.event[hidden],
.event.is-hidden,
.vol-row[hidden],
.seat-row[hidden],
.sess-row[hidden],
[data-nt-row][hidden] {
  display: none !important;
}
.seat-card {
  border: 1px solid color-mix(in srgb, var(--hair) 80%, transparent);
  background: var(--panel);
  border-radius: 12px;
  overflow: hidden;
  position: relative;
}
.seat-head, .seat-row {
  display: grid;
  grid-template-columns: 44px 1.3fr 1.2fr 1.3fr 110px 88px 92px;
  gap: 8px; align-items: center;
  padding: 10px 14px;
}
.sess-head, .sess-row {
  grid-template-columns: 130px 1fr 1.2fr 1fr 1fr 88px;
}
.seat-head {
  font-size: 10px; letter-spacing: 0.08em; text-transform: uppercase;
  color: var(--ink3); font-weight: 550; border-bottom: 1px solid var(--hair);
}
.seat-row {
  border-bottom: 1px solid var(--hair); cursor: pointer;
  transition: transform 160ms ease, box-shadow 160ms ease, background 160ms ease;
}
.seat-row:hover {
  transform: translateY(-1px);
  box-shadow: 0 8px 20px rgba(15, 23, 42, 0.08);
  background: color-mix(in srgb, var(--nav-on) 80%, transparent);
}
@media (prefers-reduced-motion: reduce) {
  .seat-row { transition: none; }
  .seat-row:hover { transform: none; }
}
.seat-no { font-family: var(--mono); font-size: 11px; color: var(--ink3); }
.seat-name { display: inline-flex; align-items: center; gap: 8px; font-weight: 600; }
.os-badge {
  width: 22px; height: 22px; border-radius: 999px; display: grid; place-items: center;
  font: 700 8px/1 var(--sans); letter-spacing: 0.02em; color: #fff; text-transform: lowercase;
}
.os-badge.mac { background: #18181B; }
.os-badge.windows { background: #0A84FF; }
.os-badge.linux { background: #16A34A; }
.seat-loc { color: var(--ink2); font-size: 12px; }
.seat-flag {
  display: inline-block; min-width: 22px; padding: 1px 5px; margin-right: 6px;
  border-radius: 4px; border: 1px solid var(--hair); font: 700 9px var(--mono);
}
.seat-meter { height: 6px; background: var(--nav-on); border-radius: 99px; overflow: hidden; }
.seat-meter i { display: block; height: 100%; background: #2563EB; border-radius: 99px; }
.seat-status {
  display: inline-flex; justify-content: center; padding: 2px 8px; border-radius: 999px;
  font: 600 10px var(--sans); border: 1px solid var(--hair);
}
.seat-status.active { color: #16A34A; background: rgba(22,163,74,0.08); border-color: rgba(22,163,74,0.22); }
.seat-status.paused { color: #CA8A04; background: rgba(202,138,4,0.10); border-color: rgba(202,138,4,0.22); }
.seat-status.inactive { color: var(--ink3); background: var(--nav-on); }
.seat-overlay {
  position: absolute; inset: 12px; background: var(--panel);
  border: 1px solid var(--hair); border-radius: 10px;
  box-shadow: 0 16px 40px rgba(15,23,42,0.16); padding: 16px; z-index: 3;
  overflow: auto;
}
[data-theme="dark"] .seat-overlay { box-shadow: 0 16px 40px rgba(0,0,0,0.45); }
.seat-overlay[hidden] { display: none !important; }
.seat-overlay h4 { margin: 0 0 4px; font-size: 15px; }
.seat-overlay-head { display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; margin-bottom: 12px; }
.seat-overlay-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px 18px; }
.seat-field { display: grid; gap: 3px; }
.seat-field .lbl {
  font-size: 10px; letter-spacing: 0.08em; text-transform: uppercase; color: var(--ink3); font-weight: 600;
}
.seat-field .val { font-size: 13px; color: var(--ink); }
.seat-overlay-wide { grid-column: 1 / -1; }
.sess-profile { display: inline-flex; align-items: center; gap: 8px; min-width: 0; }
.sess-host { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-weight: 550; }
.sess-id {
  font-family: var(--mono); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.sess-avatar {
  width: 22px; height: 22px; border-radius: 6px; display: inline-grid; place-items: center;
  font: 700 10px/1 var(--sans); color: #3F3F46; flex-shrink: 0;
}
.seat-hbars { display: flex; align-items: flex-end; gap: 3px; height: 28px; }
.seat-hbars i { width: 6px; background: #2563EB; border-radius: 2px 2px 0 0; display: block; min-height: 3px; }
.nt-head { display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; margin: 0 0 10px; }
.nt-sub { margin: 4px 0 0; font-size: 12px; }
svg:not(.shoey-world) path { vector-effect: non-scaling-stroke; }
#spark-defs { position: absolute; width: 0; height: 0; }
@media (max-width: 980px) {
  .shell { grid-template-columns: 1fr; }
  .rail { position: relative; min-height: auto; }
  .kpis, .kpis-extra, .ov-10, .grid-2, .grid-3, .crm-kpis, .event, .rt-grid, .ev-grid { grid-template-columns: 1fr; }
}
${Tn}

.brand-mark {
  display: inline-flex; align-items: center; justify-content: center;
  width: 16px; height: 16px; border-radius: 4px; flex: 0 0 auto;
  color: #18181B; vertical-align: middle;
}
.brand-mark.os-mark.mac, .brand-mark.os-mark.mac svg { color: #18181B; }
.brand-mark.os-mark.win, .brand-mark.os-mark.win svg { color: #0A84FF; }
.brand-mark.os-mark.linux, .brand-mark.os-mark.linux svg { color: #16A34A; }
.brand-mark.browser-mark.electron, .brand-mark.browser-mark.electron svg { color: #47848F; }
.flag-mark { font-size: 14px; line-height: 1; }
.country-cell, .browser-cell, .os-cell, .profile-cell {
  display: inline-flex; align-items: center; gap: 6px; min-width: 0;
}
.country-cell span, .browser-cell span, .os-cell span, .profile-cell span {
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.os-badge {
  display: inline-flex; align-items: center; gap: 4px;
  padding: 2px 8px 2px 4px; border-radius: 999px;
  border: 1px solid var(--hair); background: var(--nav-on);
  font: 600 10px/1 var(--sans); color: var(--ink2);
}
.os-badge .brand-mark { width: 14px; height: 14px; }
.page-hero[data-map-dashboard] { margin-bottom: 12px; }
.ic-mac, .ic-win, .ic-desk {
  display: inline-block; width: 12px; height: 12px; border-radius: 2px; background: #2563EB;
}
.ic-win { background: #0A84FF; }
.ic-desk { background: #71717A; }

`;var at="location.pathname.replace(/^\\//, '')",In=`/* M\xE9tis Operator SPA \u2014 Shoey Overview / Realtime / Events
 * Content-hashed chrome. Authenticated HTML script-src this file.
 * 0 LLM tokens. Live heartbeats only. Fail loud: this is not a METIS_OPERATOR stub.
 * Shoey land fill #E5E7EB. Events columns: Created at, Name, Profile, Country, OS, Browser.
 * World land is inlined in #map-root HTML as path[data-iso]. paintShoeyMap only restyles theme.
 */
(function metisOperatorSpa() {
  'use strict'
  var pages = ['overview', 'realtime', 'events', 'sessions', 'notifications', 'keys', 'settings']
  self.METIS_OPERATOR_SPA = {
    chrome: 'shoey',
    product: 'M\xE9tis Operator',
    pages: pages,
    nav: pages,
    hydrate: 'post-access'
  }

  var sessionBearer = ''

  async function ensureSession() {
    if (sessionBearer) return
    try {
      var ping = await fetch('/session', {
        method: 'GET',
        credentials: 'include',
        headers: { accept: 'application/json' }
      })
      var issued = ping.headers && ping.headers.get && ping.headers.get('X-Metis-Session')
      if (issued) sessionBearer = issued
      var pingText = await ping.text()
      try {
        var pingJson = JSON.parse(pingText)
        if (pingJson && pingJson.session) sessionBearer = pingJson.session
      } catch (e) {}
    } catch (e) {}
  }

  async function api(path, body) {
    await ensureSession()
    var r
    var headers = { accept: 'application/json' }
    if (body) headers['content-type'] = 'application/json'
    if (sessionBearer) headers.authorization = 'Bearer ' + sessionBearer
    try {
      r = await fetch(path, {
        method: body ? 'POST' : 'GET',
        credentials: 'include',
        headers: headers,
        body: body ? JSON.stringify(body) : undefined
      })
    } catch (e) {
      return { ok: false, error: 'network failed' }
    }
    try {
      var issued = r.headers && r.headers.get && r.headers.get('X-Metis-Session')
      if (issued) sessionBearer = issued
    } catch (e) {}
    var text = await r.text()
    try {
      return JSON.parse(text)
    } catch (e) {
      if (!text || looksLikeAccessHtml(text)) {
        return { ok: false, error: 'Access required. Sign in with Cloudflare Access and retry Add.' }
      }
      return { ok: false, error: text.slice(0, 180) || ('HTTP ' + r.status) }
    }
  }

  var titles = {
    overview: 'Overview', realtime: 'Realtime', events: 'Events', sessions: 'Sessions',
    notifications: 'Notifications', keys: 'Keys', settings: 'Settings', map: 'Realtime'
  }

  function route(to) {
    if (typeof to === 'string') {
      var next = to
      if (next.charAt(0) === '#') next = next.slice(1)
      if (next.charAt(0) === '/') next = next.slice(1)
      if (!next) next = 'overview'
      if (titles[next] || next === 'map') {
        var want = '#' + next
        if (location.hash !== want) location.hash = want
      }
    }
    var raw = (location.hash || '#overview').replace('#', '')
    var requested = titles[raw] ? raw : 'overview'
    var id = requested === 'map' ? 'realtime' : requested
    document.querySelectorAll('[data-page]').forEach(function (p) {
      p.hidden = p.getAttribute('data-page') !== id
    })
    var navOn = requested === 'map' ? 'realtime' : requested
    document.querySelectorAll('[data-nav]').forEach(function (a) {
      a.classList.toggle('on', a.getAttribute('data-nav') === navOn)
    })
    var t = document.getElementById('page-title')
    if (t) t.textContent = titles[id]
    if (id === 'realtime') paintShoeyMap()
    if (id === 'events') applyEventsFilter()
  }
  window.route = route

  var SHOEY_LAND_SVG = ${JSON.stringify(xe)}

  function ensureShoeyLand(root) {
    if (root.querySelector('path[data-iso]')) return
    // HTML already inlines land (#map-root[data-land=inline]). This is a last-resort restyle helper, not the map.
    var box = document.createElement('div')
    box.innerHTML = SHOEY_LAND_SVG
    var fresh = box.querySelector('svg.shoey-world')
    if (!fresh) return
    var old = root.querySelector('svg.world')
    if (old && old.querySelectorAll) {
      old.querySelectorAll('circle.seat-dot, circle.dot, g.pill-g').forEach(function (n) {
        fresh.appendChild(n)
      })
    }
    if (old && typeof old.replaceWith === 'function') {
      old.replaceWith(fresh)
    } else if (old && old.parentNode && old.parentNode.replaceChild) {
      old.parentNode.replaceChild(fresh, old)
    } else {
      root.insertBefore(fresh, root.firstChild)
    }
  }

  function paintShoeyMap() {
    var root = document.getElementById('map-root')
    if (!root) return
    ensureShoeyLand(root)
    var dark = document.documentElement.getAttribute('data-theme') === 'dark'
    var land = dark ? '#3f3f46' : '#E5E7EB'
    var ocean = dark ? '#0a0a0b' : '#FFFFFF'
    var stroke = dark ? '#111827' : '#6B7280'
    root.querySelectorAll('.world-ocean').forEach(function (r) {
      r.setAttribute('fill', ocean)
    })
    root.querySelectorAll('path[data-iso]').forEach(function (p) {
      p.setAttribute('fill', land)
      p.setAttribute('stroke', stroke)
      p.setAttribute('stroke-width', '1.15')
      p.setAttribute('class', ((p.getAttribute('class') || '') + ' world-land').trim())
    })
    var svg = root.querySelector('svg.shoey-world')
    if (svg) svg.setAttribute('data-land', '#E5E7EB')
  }

  window.addEventListener('hashchange', route)
  if (!location.hash) {
    var path = ${at}
    if (path && titles[path]) location.hash = '#' + path
  }
  route()

  document.querySelectorAll('[data-vol-tab]').forEach(function (b) {
    b.addEventListener('click', function () {
      var key = b.getAttribute('data-vol-tab') || ''
      var group = key.split(':')[0]
      document.querySelectorAll('[data-vol-tab^="' + group + ':"]').forEach(function (x) {
        x.classList.toggle('on', x === b)
      })
      document.querySelectorAll('[data-vol-pane^="' + group + ':"]').forEach(function (p) {
        p.hidden = p.getAttribute('data-vol-pane') !== key
      })
    })
  })

  document.querySelectorAll('[data-vol-search]').forEach(function (input) {
    input.addEventListener('input', function () {
      var q = input.value.trim().toLowerCase()
      var id = input.getAttribute('data-vol-search')
      document.querySelectorAll('[data-vol-pane^="' + id + ':"] .vol-row[data-q]').forEach(function (row) {
        row.hidden = Boolean(q) && !(row.getAttribute('data-q') || '').includes(q)
      })
    })
  })

  function syncEmpty(rowsSel, emptyId) {
    var empty = document.getElementById(emptyId)
    if (!empty) return
    var rows = document.querySelectorAll(rowsSel)
    var shown = 0
    rows.forEach(function (row) {
      if (!row.hidden) shown += 1
    })
    empty.hidden = shown > 0
  }

  var evSearch = document.getElementById('events-search')
  function applyEventsFilter() {
    var input = document.getElementById('events-search') || evSearch
    var q = String(input && input.value || '').trim().toLowerCase()
    document.querySelectorAll('#events-list .event[data-q]').forEach(function (row) {
      var hay = (row.getAttribute('data-q') || '').toLowerCase()
      var hit = !q || hay.indexOf(q) >= 0
      row.hidden = !hit
      if (row.classList && row.classList.toggle) row.classList.toggle('is-hidden', !hit)
      if (row.style) row.style.display = hit ? '' : 'none'
      if (!hit && row.setAttribute) row.setAttribute('hidden', 'hidden')
      if (hit && row.removeAttribute) row.removeAttribute('hidden')
    })
    syncEmpty('#events-list .event[data-q]', 'events-empty')
  }
  if (evSearch) {
    evSearch.addEventListener('input', applyEventsFilter)
    evSearch.addEventListener('search', applyEventsFilter)
    evSearch.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault()
        applyEventsFilter()
      }
    })
  }
  if (document.addEventListener) {
    document.addEventListener('input', function (e) {
      var t = e && e.target
      if (t && t.id === 'events-search') applyEventsFilter()
    })
    document.addEventListener('search', function (e) {
      var t = e && e.target
      if (t && t.id === 'events-search') applyEventsFilter()
    })
  }
  var evFilters = document.getElementById('events-filters')
  if (evFilters && evSearch) {
    evFilters.addEventListener('click', function () { evSearch.focus() })
  }
  document.querySelectorAll('[data-ev-tab]').forEach(function (b) {
    b.addEventListener('click', function () {
      var id = b.getAttribute('data-ev-tab') || 'events'
      document.querySelectorAll('[data-ev-tab]').forEach(function (x) { x.classList.toggle('on', x === b) })
      document.querySelectorAll('[data-ev-pane]').forEach(function (pane) {
        pane.hidden = pane.getAttribute('data-ev-pane') !== id
      })
    })
  })
  document.querySelectorAll('[data-nt-tab]').forEach(function (b) {
    b.addEventListener('click', function () {
      var id = b.getAttribute('data-nt-tab') || 'notifications'
      document.querySelectorAll('[data-nt-tab]').forEach(function (x) { x.classList.toggle('on', x === b) })
      document.querySelectorAll('[data-nt-pane]').forEach(function (pane) {
        pane.hidden = pane.getAttribute('data-nt-pane') !== id
      })
    })
  })

  var sessSearch = document.getElementById('sessions-search')
  function applySessionsFilter() {
    var q = sessSearch ? sessSearch.value.trim().toLowerCase() : ''
    document.querySelectorAll('[data-seat-row]').forEach(function (row) {
      row.hidden = Boolean(q) && !(row.getAttribute('data-q') || '').includes(q)
    })
    syncEmpty('[data-seat-row]', 'sessions-empty')
  }
  if (sessSearch) {
    sessSearch.addEventListener('input', applySessionsFilter)
    sessSearch.addEventListener('search', applySessionsFilter)
    sessSearch.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); applySessionsFilter() }
    })
  }
  var sessFilters = document.getElementById('sessions-filters')
  if (sessFilters && sessSearch) {
    sessFilters.addEventListener('click', function () { sessSearch.focus() })
  }

  var ntFilter = 'all'
  var ntSearch = document.getElementById('nt-search')
  function applyNtFilter() {
    var q = ntSearch ? ntSearch.value.trim().toLowerCase() : ''
    document.querySelectorAll('#nt-table [data-nt-row]').forEach(function (row) {
      var status = row.getAttribute('data-status') || ''
      var text = (row.textContent || '').toLowerCase()
      var statusOk = ntFilter === 'all' || status === ntFilter
      var qOk = !q || text.includes(q)
      row.hidden = !(statusOk && qOk)
    })
    var empty = document.querySelector('#nt-table [data-nt-empty]')
    if (empty) {
      var shown = 0
      document.querySelectorAll('#nt-table [data-nt-row]').forEach(function (row) {
        if (!row.hidden) shown += 1
      })
      empty.hidden = shown > 0
    }
  }
  if (ntSearch) ntSearch.addEventListener('input', applyNtFilter)

  var themeBtn = document.getElementById('theme-btn')
  function applyTheme(v) {
    var theme = v === 'dark' ? 'dark' : 'light'
    document.documentElement.setAttribute('data-theme', theme)
  }
  try { applyTheme(localStorage.getItem('metis-operator-theme') || 'light') } catch (e) { applyTheme('light') }
  paintShoeyMap()
  if (themeBtn) {
    themeBtn.addEventListener('click', function () {
      var cur = document.documentElement.getAttribute('data-theme')
      var next = cur === 'dark' ? 'light' : 'dark'
      applyTheme(next)
      paintShoeyMap()
      try { localStorage.setItem('metis-operator-theme', next) } catch (e) {}
    })
  }

  function addSeatField(body, label, value, wide) {
    var field = document.createElement('div')
    field.className = wide ? 'seat-field seat-overlay-wide' : 'seat-field'
    var k = document.createElement('span')
    k.className = 'lbl'
    k.textContent = label
    var v = document.createElement('span')
    v.className = 'val'
    v.textContent = value
    field.appendChild(k)
    field.appendChild(v)
    body.appendChild(field)
    return field
  }
  function fillSeatOverlay(row) {
    var overlay = document.getElementById('seat-overlay')
    if (!overlay) return
    overlay.hidden = false
    var title = overlay.querySelector('[data-seat-title]')
    var no = overlay.querySelector('[data-seat-no]')
    var body = overlay.querySelector('[data-seat-body]')
    var computer = row.getAttribute('data-seat-computer') || '\u2014'
    if (title) title.textContent = computer
    if (no) no.textContent = row.getAttribute('data-seat-no') || ''
    if (!body) return
    body.textContent = ''
    addSeatField(body, 'Computer', computer)
    addSeatField(body, 'OS', row.getAttribute('data-os') || '\u2014')
    addSeatField(body, 'Location', row.getAttribute('data-seat-location') || '\u2014')
    addSeatField(body, 'IP', row.getAttribute('data-seat-ip') || '\u2014')
    addSeatField(body, 'License', row.getAttribute('data-seat-license') || '\u2014')
    addSeatField(body, 'Identity', row.getAttribute('data-seat-identity') || '\u2014')
    addSeatField(body, 'Last seen', row.getAttribute('data-seat-last') || '\u2014')
    addSeatField(body, 'Version', row.getAttribute('data-seat-version') || '\u2014')
    var statusField = addSeatField(body, 'Status', '')
    var pill = document.createElement('span')
    var statusId = row.getAttribute('data-seat-status-id') || 'inactive'
    pill.className = 'seat-status ' + statusId
    pill.textContent = row.getAttribute('data-seat-status') || 'Inactive'
    statusField.querySelector('.val').appendChild(pill)
    var meterField = addSeatField(body, 'Heartbeat', '', true)
    var meter = document.createElement('div')
    meter.className = 'seat-meter'
    var fill = document.createElement('i')
    fill.style.width = (row.getAttribute('data-seat-meter') || '8') + '%'
    meter.appendChild(fill)
    meterField.querySelector('.val').appendChild(meter)
    var barsField = addSeatField(body, 'Heartbeat bars', '', true)
    var hbars = document.createElement('div')
    hbars.className = 'seat-hbars'
    ;(row.getAttribute('data-seat-bars') || '8').split(',').forEach(function (n) {
      var bar = document.createElement('i')
      var v = Math.max(8, Math.min(100, parseInt(n, 10) || 8))
      bar.style.height = v + '%'
      hbars.appendChild(bar)
    })
    barsField.querySelector('.val').appendChild(hbars)
    var recent = row.getAttribute('data-seat-recent') || ''
    addSeatField(body, 'Recent', recent || 'No recent heartbeats for this seat.', true)
  }
  document.querySelectorAll('[data-seat-row]').forEach(function (row) {
    row.addEventListener('click', function () { fillSeatOverlay(row) })
  })
  var seatClose = document.getElementById('seat-overlay-close')
  if (seatClose) {
    seatClose.addEventListener('click', function () {
      var overlay = document.getElementById('seat-overlay')
      if (overlay) overlay.hidden = true
    })
  }

  document.querySelectorAll('[data-scale]').forEach(function (b) {
    b.addEventListener('click', function () {
      document.querySelectorAll('[data-scale]').forEach(function (x) { x.classList.toggle('on', x === b) })
      document.getElementById('scale-24').hidden = b.getAttribute('data-scale') !== '24h'
      document.getElementById('scale-7').hidden = b.getAttribute('data-scale') !== '7d'
    })
  })

  document.querySelectorAll('#map-root path[data-iso]').forEach(function (p) {
    p.addEventListener('click', function () {
      var iso = p.getAttribute('data-iso')
      document.querySelectorAll('[data-vol-pane="geo:geo"] .vol-row[data-q]').forEach(function (row) {
        row.hidden = Boolean(iso) && !(row.getAttribute('data-q') || '').toUpperCase().includes(iso)
      })
    })
  })

  document.querySelectorAll('[data-crm-filter]').forEach(function (b) {
    b.addEventListener('click', function () {
      document.querySelectorAll('[data-crm-filter]').forEach(function (x) { x.classList.toggle('on', x === b) })
      ntFilter = b.getAttribute('data-crm-filter') || 'all'
      applyNtFilter()
      document.querySelectorAll('#crm-table tbody tr').forEach(function (tr) {
        tr.hidden = ntFilter !== 'all' && tr.getAttribute('data-status') !== ntFilter
      })
    })
  })

  document.querySelectorAll('[data-reveal]').forEach(function (b) {
    b.addEventListener('click', async function () {
      var id = b.getAttribute('data-reveal')
      var j = await api('/v1/admin/asks/' + id)
      document.getElementById('reveal').textContent = j.ok ? (j.question || '(empty)') : (j.error || 'reveal failed')
    })
  })

  document.querySelectorAll('[data-approve]').forEach(function (b) {
    b.addEventListener('click', async function () {
      var id = b.getAttribute('data-approve')
      var diff = document.querySelector('[data-diff="' + id + '"]').value
      await api('/v1/admin/skills/' + id + '/approve', { diff: diff })
      location.reload()
    })
  })

  document.querySelectorAll('[data-reject]').forEach(function (b) {
    b.addEventListener('click', async function () {
      var id = b.getAttribute('data-reject')
      await api('/v1/admin/skills/' + id + '/reject', { reason: 'rejected in console' })
      location.reload()
    })
  })

  document.querySelectorAll('[data-push]').forEach(function (b) {
    b.addEventListener('click', async function () {
      var id = b.getAttribute('data-push')
      await api('/v1/admin/skills/' + id + '/push', {})
      location.reload()
    })
  })

  document.querySelectorAll('[data-draft]').forEach(function (b) {
    b.addEventListener('click', async function () {
      await api('/v1/admin/skills/draft', { skillId: b.getAttribute('data-draft') })
      location.reload()
    })
  })

  document.querySelectorAll('[data-retry]').forEach(function (b) {
    b.addEventListener('click', async function () {
      await api('/v1/admin/crm/' + b.getAttribute('data-retry') + '/retry', {})
      location.reload()
    })
  })

  function looksLikeAccessHtml(text) {
    var t = String(text || '').toLowerCase()
    return t.indexOf('<!doctype') >= 0 || t.indexOf('<html') >= 0 || t.indexOf('cf-access') >= 0
  }

  function showKey(el, j) {
    if (!el) return
    if (j && j.ok) {
      el.className = 'key-msg ok'
      el.textContent = j.last4 ? ('saved \xB7\xB7' + j.last4) : (j.status || 'ok')
    } else {
      el.className = 'key-msg fail-loud'
      var err = (j && j.error) || 'Add failed'
      if (err === 'Access required' || looksLikeAccessHtml(err)) {
        err = 'Access required. Sign in with Cloudflare Access and retry Add.'
      }
      el.textContent = err
    }
  }

  function bindKeyAdd(form, msgId) {
    if (!form) return
    form.addEventListener('submit', async function (e) {
      e.preventDefault()
      var msg = document.getElementById(msgId || 'key-msg')
      var fd = new FormData(form)
      var j = await api('/v1/admin/keys', {
        provider: fd.get('provider'),
        label: fd.get('label'),
        secret: fd.get('secret')
      })
      showKey(msg, j)
      if (j && j.ok) location.reload()
    })
  }
  bindKeyAdd(document.getElementById('key-add'), 'key-msg')
  bindKeyAdd(document.getElementById('key-add-settings'), 'key-msg-settings')

  document.querySelectorAll('[data-rotate]').forEach(function (b) {
    b.addEventListener('click', async function () {
      var secret = window.prompt('New secret or token')
      if (!secret) return
      var j = await api('/v1/admin/keys/' + b.getAttribute('data-rotate') + '/rotate', { secret: secret })
      if (j && j.ok) location.reload()
      else showKey(document.getElementById('key-msg'), j)
    })
  })

  document.querySelectorAll('[data-revoke]').forEach(function (b) {
    b.addEventListener('click', async function () {
      var j = await api('/v1/admin/keys/' + b.getAttribute('data-revoke') + '/revoke', {})
      if (j && j.ok) location.reload()
      else showKey(document.getElementById('key-msg'), j)
    })
  })
})();
`;var Nn=2e3;function it(e){let t=2166136261,n=16777619;for(let r=0;r<e.length;r++){let s=e.charCodeAt(r);t=Math.imul(t^s,16777619),n=Math.imul(n+s,2246822519)^t>>>7}return((t>>>0).toString(16).padStart(8,"0")+(n>>>0).toString(16).padStart(8,"0")).slice(0,12)}var N=In,ne=On;if(N.length<Nn||ne.length<Nn)throw new Error(`M\xE9tis Operator refused to ship a stub SPA (js=${N.length} css=${ne.length})`);if(N.includes("self.METIS_OPERATOR =")&&N.length<500)throw new Error("M\xE9tis Operator refused to ship METIS_OPERATOR stub");if(!N.includes(at))throw new Error("M\xE9tis Operator refused to ship a pathname strip that will not parse");if(!N.includes("window.route = route"))throw new Error("M\xE9tis Operator refused to ship a SPA without window.route");var Ns=it(N),Zs=it(ne),Fs=`operator-${Ns}.js`,Us=`operator-${Zs}.css`,re=`/assets/${Fs}`,we=`/assets/${Us}`,Zn="/assets/index.js",ot=xe,Bs=it(ot),lt=`/assets/world-${Bs}.svg`,Fn="/assets/world.svg";function Un(e){return e==="/favicon.ico"?!0:e==="/assets"||e.startsWith("/assets/")}function _e(e,t){return{"content-type":e,"cache-control":t?"public, max-age=31536000, immutable":"public, max-age=60"}}function Bn(e){return e==="/favicon.ico"?new Response("",{status:200,headers:_e("image/x-icon",!1)}):e===re||e===Zn?new Response(N,{status:200,headers:_e("application/javascript; charset=utf-8",e===re)}):e===we?new Response(ne,{status:200,headers:_e("text/css; charset=utf-8",!0)}):e===lt||e===Fn?new Response(ot,{status:200,headers:_e("image/svg+xml; charset=utf-8",e===lt)}):null}function U(e){return String(e??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/"/g,"&quot;")}function T(e){return e>=1e6?`${Math.round(e/1e5)/10}M`:e>=1e3?`${Math.round(e/100)/10}K`:String(e)}function Lt(e){return e==null?"0":typeof e=="number"?T(e):e}function Ds(e){return e==null?"0":e<1e3?`${Math.round(e)}ms`:e<6e4?`${Math.round(e/1e3)}s`:`${Math.round(e/6e4)}m`}function Hs(e){return e==null?"0%":`${e}%`}function qs(e,t){if(t===0||e.length<4)return null;let n=Math.floor(e.length/2),r=e.slice(0,n).reduce((L,c)=>L+c,0)/n,s=e.slice(n).reduce((L,c)=>L+c,0)/(e.length-n);if(r<1)return null;let a=(s-r)/r*100;if(!Number.isFinite(a)||Math.abs(a)>400)return null;let o=Math.abs(a)<.05?0:Math.round(a*10)/10;return o===0?null:{text:`${o>0?"+":""}${o}%`,cls:o>0?"up":"down"}}function Vs(e,t){let n=t<=0?0:Math.min(1,e/t),s=Math.PI*34;return`<svg class="stat-spark stat-gauge" viewBox="0 0 88 56" aria-hidden="true">
    <path d="M10 48 A 34 34 0 0 1 78 48" fill="none" stroke="#EDEDED" stroke-width="8" stroke-linecap="round"/>
    <path d="M10 48 A 34 34 0 0 1 78 48" fill="none" stroke="#2563EB" stroke-width="8" stroke-linecap="round" stroke-dasharray="${(n*s).toFixed(1)} ${s.toFixed(1)}"/>
  </svg>`}function Dn(e,t=!1){let r=2*Math.PI*22;return`<svg class="stat-spark stat-ring" viewBox="0 0 64 56" aria-hidden="true">
    <circle cx="32" cy="28" r="22" fill="none" stroke="#EDEDED" stroke-width="7"/>
    <circle cx="32" cy="28" r="22" fill="none" stroke="#2563EB" stroke-width="7"
      stroke-dasharray="${((t?0:Math.max(0,Math.min(1,e)))*r).toFixed(1)} ${r.toFixed(1)}" stroke-linecap="round" transform="rotate(-90 32 28)"/>
  </svg>`}function Ks(e,t){let n=e+t;if(!n)return Dn(0,!0);let r=22,s=2*Math.PI*r,a=(e/n*s).toFixed(1),o=(t/n*s).toFixed(1);return`<svg class="stat-spark stat-ring" viewBox="0 0 64 56" aria-hidden="true">
    <circle cx="32" cy="28" r="${r}" fill="none" stroke="#EDEDED" stroke-width="7"/>
    <circle cx="32" cy="28" r="${r}" fill="none" stroke="#2563EB" stroke-width="7"
      stroke-dasharray="${a} ${s.toFixed(1)}" transform="rotate(-90 32 28)"/>
    <circle cx="32" cy="28" r="${r}" fill="none" stroke="#93C5FD" stroke-width="7"
      stroke-dasharray="${o} ${s.toFixed(1)}" stroke-dashoffset="-${a}" transform="rotate(-90 32 28)"/>
  </svg>`}function O(e){let t=Number(e.value.replace(/[^\d.-]/g,"")),n=qs(e.series,Number.isFinite(t)?t:void 0);return`<article class="stat-card" data-stat-card="${U(e.id)}" data-bklit="${U(e.kind)}">
    <div class="stat-card-head">
      <h3>${U(e.title)}</h3>
      ${n?`<span class="trend-badge ${n.cls}">${U(n.text)}</span>`:""}
    </div>
    <div class="stat-flow">
      <div class="n">${U(e.value)}</div>
      <div class="lbl">${U(e.unit)}</div>
    </div>
    ${e.chart}
  </article>`}function Z(e,t){return`<span class="ov-chip"><b>${U(e)}</b> ${U(t)}</span>`}function Hn(e){let t=e.ops,n=e.map.countries,r=n.length,s=t.cliAsks,a=t.operatorAsks,o=s+a,L=[O({id:"unique-sessions",title:"Unique sessions",value:T(t.uniqueSessions),unit:"WAU",kind:"area",series:t.uniqueSeries,chart:j(t.uniqueSeries,280,72)}),O({id:"sessions-day",title:"Sessions / day",value:T(t.sessionsDay),unit:"DAU",kind:"line",series:t.sessionsDaySeries,chart:G(t.sessionsDaySeries,280,72)}),O({id:"live-now",title:"Live now",value:T(t.liveNow),unit:"seats",kind:"gauge",series:t.liveSeries,chart:Vs(t.liveNow,Math.max(t.liveNow,t.live30,t.uniqueSessions,1))}),O({id:"time-saved",title:"Time saved",value:Lt(t.timeSaved),unit:"seat-local",kind:"ring",series:[],chart:Dn(0,!0)}),O({id:"tokens",title:"Tokens",value:Lt(t.tokens),unit:"tokens",kind:"area",series:t.tokenSeries,chart:j(t.tokenSeries,280,72)}),O({id:"api-calls",title:"API calls",value:T(t.apiCalls),unit:"asks",kind:"line",series:t.apiSeries,chart:G(t.apiSeries,280,72)}),O({id:"listen-minutes",title:"Listen minutes",value:Lt(t.listenMinutes),unit:"listen",kind:"area",series:[],chart:j([],280,72)}),O({id:"recaps",title:"Recaps",value:T(t.recapCount),unit:"recap",kind:"line",series:t.recapSeries,chart:G(t.recapSeries,280,72)}),O({id:"cli-vs-key",title:"CLI vs Operator-key asks",value:`${s} / ${a}`,unit:"cli \xB7 key",kind:"ring",series:[],chart:Ks(s,a)}),O({id:"countries",title:"Countries",value:T(r),unit:"total",kind:"choropleth",series:[],chart:`<div class="stat-choro-wrap">${Cn(n)}</div>`})],c=e.kpis.cost7d??"0",p=[Z("Mac vs Windows",e.scale.os.map(u=>`${u.label} ${u.value}`).join(" \xB7 ")||"0"),Z("Cost by provider",c),Z("CRM fail",Hs(t.crmFailRate)),Z("Version mix",e.scale.versions.map(u=>`${u.label} ${u.value}`).join(" \xB7 ")||"0"),Z("Duration",Ds(t.durationMs)),Z("Meetings",T(t.meetings)),Z("Live \xB7 30 min",T(t.live30)),Z("CLI asks",T(s)),Z("Operator-key asks",T(a))].join("");return`<div class="ov-10" data-overview-cards="10">${L.join("")}</div>
    <div class="ov-chips">${p}</div>`}var ct=[{id:"fleet",label:"M\xE9tis",items:[{id:"overview",label:"Overview"},{id:"realtime",label:"Realtime"},{id:"events",label:"Events"},{id:"sessions",label:"Sessions"},{id:"notifications",label:"Notifications"},{id:"keys",label:"Keys"},{id:"settings",label:"Settings"}]}],qn=ct.flatMap(e=>e.items.map(t=>t.id)),Vn=["scale","change","console","seo","pages","insights","profiles","groups","cohorts","dashboards","references"],Kn=["map"];var js={AD:"Andorra",AE:"UAE",AF:"Afghanistan",AL:"Albania",AM:"Armenia",AO:"Angola",AR:"Argentina",AT:"Austria",AU:"Australia",AZ:"Azerbaijan",BA:"Bosnia",BD:"Bangladesh",BE:"Belgium",BF:"Burkina Faso",BG:"Bulgaria",BH:"Bahrain",BJ:"Benin",BN:"Brunei",BO:"Bolivia",BR:"Brazil",BT:"Bhutan",BW:"Botswana",BY:"Belarus",BZ:"Belize",CA:"Canada",CD:"DR Congo",CF:"Central African Republic",CG:"Congo",CH:"Switzerland",CI:"C\xF4te d\u2019Ivoire",CL:"Chile",CM:"Cameroon",CN:"China",CO:"Colombia",CR:"Costa Rica",CU:"Cuba",CY:"Cyprus",CZ:"Czechia",DE:"Germany",DJ:"Djibouti",DK:"Denmark",DO:"Dominican Republic",DZ:"Algeria",EC:"Ecuador",EE:"Estonia",EG:"Egypt",ER:"Eritrea",ES:"Spain",ET:"Ethiopia",FI:"Finland",FJ:"Fiji",FR:"France",GA:"Gabon",GB:"United Kingdom",GE:"Georgia",GH:"Ghana",GL:"Greenland",GM:"Gambia",GN:"Guinea",GQ:"Equatorial Guinea",GR:"Greece",GT:"Guatemala",GW:"Guinea-Bissau",GY:"Guyana",HN:"Honduras",HR:"Croatia",HT:"Haiti",HU:"Hungary",ID:"Indonesia",IE:"Ireland",IL:"Israel",IN:"India",IQ:"Iraq",IR:"Iran",IS:"Iceland",IT:"Italy",JM:"Jamaica",JO:"Jordan",JP:"Japan",KE:"Kenya",KG:"Kyrgyzstan",KH:"Cambodia",KP:"North Korea",KR:"South Korea",KW:"Kuwait",KZ:"Kazakhstan",LA:"Laos",LB:"Lebanon",LK:"Sri Lanka",LR:"Liberia",LS:"Lesotho",LT:"Lithuania",LU:"Luxembourg",LV:"Latvia",LY:"Libya",MA:"Morocco",MD:"Moldova",ME:"Montenegro",MG:"Madagascar",MK:"North Macedonia",ML:"Mali",MM:"Myanmar",MN:"Mongolia",MR:"Mauritania",MW:"Malawi",MX:"Mexico",MY:"Malaysia",MZ:"Mozambique",NA:"Namibia",NE:"Niger",NG:"Nigeria",NI:"Nicaragua",NL:"Netherlands",NO:"Norway",NP:"Nepal",NZ:"New Zealand",OM:"Oman",PA:"Panama",PE:"Peru",PG:"Papua New Guinea",PH:"Philippines",PK:"Pakistan",PL:"Poland",PR:"Puerto Rico",PS:"Palestine",PT:"Portugal",PY:"Paraguay",QA:"Qatar",RO:"Romania",RS:"Serbia",RU:"Russia",RW:"Rwanda",SA:"Saudi Arabia",SD:"Sudan",SE:"Sweden",SG:"Singapore",SI:"Slovenia",SK:"Slovakia",SL:"Sierra Leone",SN:"Senegal",SO:"Somalia",SR:"Suriname",SS:"South Sudan",SV:"El Salvador",SY:"Syria",SZ:"Eswatini",TD:"Chad",TG:"Togo",TH:"Thailand",TJ:"Tajikistan",TL:"Timor-Leste",TM:"Turkmenistan",TN:"Tunisia",TR:"Turkey",TW:"Taiwan",TZ:"Tanzania",UA:"Ukraine",UG:"Uganda",US:"United States",UY:"Uruguay",UZ:"Uzbekistan",VE:"Venezuela",VN:"Vietnam",XK:"Kosovo",YE:"Yemen",ZA:"South Africa",ZM:"Zambia",ZW:"Zimbabwe"};function Se(e){if(!e)return"";let t=e.trim().toUpperCase();return js[t]||t}function dt(e){if(!e)return"";let t=e.trim().toUpperCase();if(!/^[A-Z]{2}$/.test(t))return"";let n=127462;return String.fromCodePoint(n+t.charCodeAt(0)-65,n+t.charCodeAt(1)-65)}var A="\u2014";function f(e){return String(e??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/"/g,"&quot;")}function Me(e){return new Date(e).toISOString().replace("T"," ").slice(0,16)}function ae(e,t){let n=t-e;if(n<9e4)return"just now";if(n<36e5){let r=Math.max(1,Math.round(n/6e4));return r===1?"1 minute ago":`${r} minutes ago`}if(n<864e5){let r=Math.max(1,Math.round(n/36e5));return r===1?"1 hour ago":`${r} hours ago`}return Me(e)}function se(e){return!e||b(e)?A:f(e)}function jn(e){if(!e.connected)return`<div class="kpis" data-cf-idle>
      ${z({title:"Requests",value:"0",sub:`${e.worker} \xB7 ${e.range}`,spark:""})}
      ${z({title:"Errors",value:"0",sub:e.worker,spark:""})}
      ${z({title:"CPU",value:"0",sub:"cpuTimeMs",spark:""})}
    </div>
    <div class="sub muted" style="padding-bottom:8px">Connect Cloudflare (login) on Keys. No token on seats. Worker ${f(e.worker)}.</div>`;if(e.error)return`<div class="fail-loud" data-cf-error>${f(e.error)}</div>
      <div class="sub muted" style="padding-bottom:8px">Worker ${f(e.worker)}. Connect Cloudflare (login) on Keys. No token on seats.</div>`;let t=e.workers.length?e.workers.map(a=>f(a)).join(", "):"none listed",n=e.requests==null?"0":String(e.requests),r=e.errors==null?"0":String(e.errors),s=e.cpuMs==null?"0":`${e.cpuMs} ms`;return`<div class="kpis">
      ${z({title:"Requests",value:n,sub:`${e.worker} \xB7 ${e.range}`,spark:""})}
      ${z({title:"Errors",value:r,sub:e.worker,spark:""})}
      ${z({title:"CPU",value:s,sub:"cpuTimeMs",spark:""})}
    </div>
    <div class="sub muted" style="padding-bottom:8px">Workers: ${t}. D1 ${f(e.d1Name||"metis-operator")} ${f(e.d1Id||"")}.</div>`}function z(e){return`<article class="card kpi">
    <div class="kpi-top"><h3>${f(e.title)}</h3>${e.pill??""}</div>
    <div class="n">${f(e.value)}</div>
    <div class="sub">${f(e.sub)}</div>
    ${e.spark}
  </article>`}function Gs(){return`<nav id="rail-nav">${ct.map(t=>{let n=t.items.map(r=>`<a class="nav-item" data-nav="${r.id}" href="#${r.id}">${f(r.label)}</a>`).join("");return`<div class="nav-sec"><p>${f(t.label)}</p>${n}</div>`}).join("")}</nav>`}function zs(e){if(e.length<4)return null;let t=Math.floor(e.length/2),n=e.slice(0,t).reduce((L,c)=>L+c,0)/t,r=e.slice(t).reduce((L,c)=>L+c,0)/(e.length-t);if(n<1)return null;let s=(r-n)/n*100;if(!Number.isFinite(s)||Math.abs(s)>400)return null;let a=Math.abs(s)<.05?0:Math.round(s*10)/10;return a===0?null:{text:`${a>0?"\u2191":"\u2193"} ${Math.abs(a)}%`,cls:a>0?"up":"down"}}function Ws(e){return e>=1e6?`${Math.round(e/1e5)/10}M`:e>=1e3?`${Math.round(e/100)/10}K`:String(e)}function Ys(e,t,n){let r=zs(n);return`<article class="card kpi">
    <p class="eyebrow">${f(e)}</p>
    <div class="kpi-top">
      <div class="n">${f(t)}</div>
      ${r?`<span class="delta ${r.cls}">${f(r.text)}</span>`:""}
    </div>
    ${rt(n)}
  </article>`}function ut(e,t,n,r,s={value:"Views",sess:"Sess"},a="gray"){let o=t.map((p,u)=>`<button class="tab${u===0?" on":""}" data-vol-tab="${e}:${p.id}" type="button">${f(p.label)}</button>`).join(""),L=a==="blue"?"vol-bar blue":"vol-bar",c=t.map((p,u)=>{let l=Js(n[p.id]||[]),d=Math.max(1,...l.map(h=>h.views)),g=l.length?l.map(h=>{let k=Math.round(h.views/d*100);return`<div class="vol-row" data-q="${f(h.name.toLowerCase())}">
                <span class="${L}" style="width:${k}%"></span>
                <span>${f(h.name)}</span>
                <span class="muted">${h.views}</span>
                <span class="muted">${h.sess}</span>
              </div>`}).join(""):`<div class="empty">No ${f(p.label.toLowerCase())} in this window.</div>`;return`<div data-vol-pane="${e}:${p.id}" ${u===0?"":"hidden"}>
        <div class="vol-row muted" style="font-size:10px;letter-spacing:0.08em;text-transform:uppercase">
          <span></span><span>${f(s.value)}</span><span>${f(s.sess)}</span>
        </div>
        ${g}
      </div>`}).join("");return`<article class="card table-card" style="padding-bottom:10px">
    <div class="tabs">${o}</div>
    <input class="table-search" data-vol-search="${e}" type="search" placeholder="${f(r)}" autocomplete="off">
    ${c}
  </article>`}function Js(e){let t=new Map;for(let n of e){let r=t.get(n.name);r?(r.views+=n.views,r.sess+=n.sess):t.set(n.name,{...n})}return[...t.values()].sort((n,r)=>r.views-n.views)}function Qn(e){let t=e.toLowerCase();return t.includes("darwin")||t.includes("mac")?"mac":t.includes("win")?"windows":t.includes("linux")?"linux":"desk"}function ft(e){let t=Qn(e);return t==="mac"?'<span class="brand-mark os-mark mac" title="macOS" aria-label="macOS"><svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path fill="currentColor" d="M16.5 3.2c-.9.1-2 .7-2.6 1.5-.6.7-1.1 1.8-.9 2.8 1 .1 2-.5 2.6-1.3.6-.8 1-1.9.9-3zM19.8 12.3c-.1-2.1 1.7-3.1 1.8-3.2-1-1.4-2.5-1.6-3-1.7-1.3-.1-2.5.8-3.1.8-.7 0-1.7-.7-2.8-.7-1.4 0-2.8.9-3.5 2.2-1.5 2.6-.4 6.5 1.1 8.6.7 1 1.6 2.2 2.7 2.1 1.1 0 1.5-.7 2.8-.7s1.6.7 2.8.7c1.2 0 1.9-1 2.6-2 .8-1.2 1.1-2.3 1.1-2.4-.1 0-2.2-.9-2.5-3.7z"/></svg></span>':t==="windows"?'<span class="brand-mark os-mark win" title="Windows" aria-label="Windows"><svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path fill="currentColor" d="M3 5.5l8-.9v7.2H3V5.5zm9-.9l9-1.1v8.3h-9V4.6zM3 12.9h8v7.3l-8-.9v-6.4zm9 0h9v8.4l-9-1.2v-7.2z"/></svg></span>':t==="linux"?'<span class="brand-mark os-mark linux" title="Linux" aria-label="Linux"><svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path fill="currentColor" d="M12.5 2.2c-.6 0-1.2.5-1.4 1.2-.3 1.1.1 2.3.7 3.3-.9.3-1.7 1-2.2 1.9-.8 1.4-.8 3.2-.2 5.1.4 1.3.4 2.2-.2 3.1-.5.7-1.4 1.1-2.2 1.5-.6.3-1.1.8-1 1.4.1.7.8 1 1.5 1.1 1.2.2 2.4-.2 3.3-.9.4 1.2 1.2 2.2 2.4 2.2 1.1 0 1.9-.9 2.3-2 .8.5 1.8.8 2.8.6.8-.1 1.5-.6 1.5-1.3 0-.6-.5-1-1.1-1.3-.7-.3-1.5-.7-1.9-1.3-.5-.8-.5-1.7-.1-3 .6-1.9.7-3.7-.1-5.1-.5-.9-1.3-1.6-2.3-1.9.4-.9.6-1.9.3-2.8-.3-.9-1-1.5-1.8-1.5z"/></svg></span>':e?'<span class="brand-mark os-mark desk" title="device" aria-label="device"><i class="ic-desk"></i></span>':""}function Xs(e){if(!e||b(e))return"";let t=e.toLowerCase();return t.includes("electron")||t.includes("metis")||t.includes("m\xE9tis")?'<span class="brand-mark browser-mark electron" title="Electron" aria-label="Electron"><svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><circle cx="12" cy="12" r="2.2" fill="currentColor"/><ellipse cx="12" cy="12" rx="10" ry="4.2" fill="none" stroke="currentColor" stroke-width="1.4"/><ellipse cx="12" cy="12" rx="10" ry="4.2" fill="none" stroke="currentColor" stroke-width="1.4" transform="rotate(60 12 12)"/><ellipse cx="12" cy="12" rx="10" ry="4.2" fill="none" stroke="currentColor" stroke-width="1.4" transform="rotate(120 12 12)"/></svg></span>':`<span class="brand-mark browser-mark" title="${f(e)}">${f(e.slice(0,2).toUpperCase())}</span>`}function Qs(e,t){let n=e&&!b(e)?e.trim().toUpperCase():"",r=t&&!b(t)?t:"";if(!n&&!r)return A;let s=n?`<span class="flag-mark" title="${f(Se(n)||n)}">${dt(n)}</span>`:"",a=[r,n?Se(n)||n:""].filter(Boolean).join(" \xB7 ");return`<span class="country-cell">${s}<span>${f(a)}</span></span>`}function ea(e){return!e||b(e)?A:`<span class="profile-cell">${er(e)}<span>${f(e)}</span></span>`}function ta(e){let t=Qn(e),n=t==="desk"?"os":t;return`<span class="os-badge ${t}" title="${f(e||"os")}">${ft(e)}<span class="os-badge-label">${n==="windows"?"win":n}</span></span>`}function na(e,t){let n=t-e;return n<=te?{id:"active",label:"Active"}:n<=1800*1e3?{id:"paused",label:"Paused"}:{id:"inactive",label:"Inactive"}}function ra(e){return e.filter(t=>t.label&&!b(t.label)).map(t=>({name:t.label,views:t.value,sess:t.value}))}function W(e="We could not find any data here yet"){return`<div class="empty-data">
      <div class="empty-dash" aria-hidden="true"></div>
      <strong>No data</strong>
      <p>${f(e)}</p>
    </div>`}function Gn(e,t){let n=`<div class="event event-head" aria-hidden="true">
      <div>Created at</div><div>Name</div><div>Profile</div><div>Country</div><div>OS</div><div>Browser</div>
    </div>`;if(!e.length)return`${n}${W("No events yet.")}`;let r=e.map(s=>{let a=b(s.name)?"event":s.name,o=s.hostname||s.email||null,L=[s.city,s.country].filter(h=>h&&!b(h)).join(" \xB7 "),c=s.browser&&!b(s.browser)?s.browser:null,p=s.chips.map(h=>`${h.key} ${h.value}`).join(" "),u=s.chips.find(h=>h.key==="path")?.value||"/",l=`${a} ${u} ${o||""} ${L} ${s.os||""} ${c||""} ${p}`.toLowerCase(),d=c?`<span class="browser-cell">${Xs(c)}<span>${f(c)}</span></span>`:A,g=s.os?`<span class="os-cell">${ft(s.os)}<span>${f(s.os)}</span></span>`:A;return`<div class="event" data-event="${f(s.id)}" data-q="${f(l)}">
        <div class="event-time">${f(ae(s.ts,t))}</div>
        <div class="event-name">${f(a)}</div>
        <div class="event-profile">${ea(o)}</div>
        <div class="event-country">${Qs(s.country,s.city)}</div>
        <div class="event-os">${g}</div>
        <div class="event-browser">${d}</div>
      </div>`}).join("");return`${n}${r}`}function sa(e){let t=new Map;for(let r of e){let s=b(r.name)?"event":r.name;t.set(s,(t.get(s)||0)+1)}return t.size?`<p class="eyebrow">Live ingest</p>${[...t.entries()].sort((r,s)=>s[1]-r[1]).map(([r,s])=>`<div class="stat-line"><span>${f(r)}</span><b>${s}</b></div>`).join("")}`:W()}function zn(e,t){if(!e.length)return"heartbeat";let n=t==="entry"?e[e.length-1]:e[0],r=n.chips.find(a=>a.key==="path")?.value;return r&&r!=="/"&&!b(r)?r:(b(n.name)?"event":n.name)||"heartbeat"}function aa(e){if(e<1e3)return"0s";if(e<6e4){let t=e/1e3;return t<10&&t%1>=.05?`${Math.round(t*10)/10}s`:`${Math.round(t)}s`}return`${Math.round(e/6e4)}m`}function Wn(e,t){let n=t-e;if(n<=te)return 100;if(n<=1800*1e3)return Math.max(36,Math.round(100-n/(1800*1e3)*64));let r=n/(3600*1e3);return Math.max(8,Math.round(28-Math.min(20,r)))}var Yn=["#BBF7D0","#BFDBFE","#FBCFE8","#FDE68A","#DDD6FE","#FED7AA"];function er(e){let t=0;for(let s=0;s<e.length;s++)t=t*31+e.charCodeAt(s)>>>0;let n=Yn[t%Yn.length],r=(e.replace(/[^A-Za-z0-9]/g,"")[0]||"M").toUpperCase();return`<span class="sess-avatar" style="background:${n}" aria-hidden="true">${f(r)}</span>`}function pt(){return'<svg class="tool-ic" viewBox="0 0 16 16" aria-hidden="true"><circle cx="7" cy="7" r="4.5" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M10.4 10.4L14 14" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>'}function Jn(){return'<svg class="tool-ic" viewBox="0 0 16 16" aria-hidden="true"><path d="M2 3.5h12L9.5 9v4l-3 1.2V9L2 3.5z" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/></svg>'}function mt(){return'<svg class="tool-ic" viewBox="0 0 16 16" aria-hidden="true"><rect x="2" y="2" width="5" height="5" rx="1" fill="none" stroke="currentColor" stroke-width="1.3"/><rect x="9" y="2" width="5" height="5" rx="1" fill="none" stroke="currentColor" stroke-width="1.3"/><rect x="2" y="9" width="5" height="5" rx="1" fill="none" stroke="currentColor" stroke-width="1.3"/><rect x="9" y="9" width="5" height="5" rx="1" fill="none" stroke="currentColor" stroke-width="1.3"/></svg>'}function Xn(){return`<div class="seat-overlay" id="seat-overlay" hidden>
      <div class="seat-overlay-head">
        <div>
          <p class="eyebrow">Seat <span data-seat-no></span></p>
          <h4 data-seat-title>Seat</h4>
        </div>
        <button type="button" id="seat-overlay-close">Close</button>
      </div>
      <div class="seat-overlay-grid" data-seat-body></div>
    </div>`}function ia(e,t){return e.filter(n=>n.device&&n.device===t.device||t.hostname&&n.hostname===t.hostname||t.email&&n.email===t.email).sort((n,r)=>r.ts-n.ts)}function oa(e,t,n){let r=`<div class="seat-head sess-head" aria-hidden="true">
      <div>Started</div><div>Session id</div><div>Profile</div><div>Entry page</div><div>Exit page</div><div>Duration</div>
    </div>`;if(!e.length)return`<div class="seat-card" data-seat-table>${r}<div class="empty" style="padding:28px 16px">No seats on the fleet yet. Heartbeats will fill this. Empty is an empty card, not sample servers.</div>
    ${Xn()}
  </div>`;let s=e.map((a,o)=>{let L=na(a.lastSeen,n),c=a.hostname&&!b(a.hostname)?a.hostname:A,p=a.email&&!b(a.email)?a.email:c,u=[a.city,a.country].filter(E=>E&&!b(E)).join(" \xB7 ")||A,l=a.license&&!b(a.license)?a.license:A,d=ia(t,a),g=d.slice(0,6).map(E=>`${ae(E.ts,n)} \xB7 ${b(E.name)?"event":E.name}`).join(" | "),h=a.firstSeen||a.lastSeen,k=zn(d,"entry"),_=zn(d,"exit"),m=aa(Math.max(0,a.lastSeen-h)),y=Wn(a.lastSeen,n),S=(d.length?d.slice(0,8).map(E=>E.ts):[a.lastSeen]).map(E=>String(Wn(E,n))).join(","),C=`${c} ${a.device} ${p} ${a.os} ${k} ${_} ${u} ${L.label} ${l}`.toLowerCase(),R=String(o+1).padStart(2,"0");return`<div class="seat-row sess-row" data-seat-row data-q="${f(C)}" data-country="${f(a.country||"")}" data-os="${f(a.os)}" data-seat-name="${f(c)}" data-seat-computer="${f(c)}" data-seat-identity="${f(p)}" data-seat-location="${f(u)}" data-seat-ip="${A}" data-seat-license="${f(l)}" data-seat-status="${f(L.label)}" data-seat-status-id="${L.id}" data-seat-meter="${y}" data-seat-bars="${f(S)}" data-seat-last="${f(Me(a.lastSeen))}" data-seat-version="${f(a.appVersion||A)}" data-seat-session="${f(a.device)}" data-seat-recent="${f(g)}" data-seat-no="${R}">
        <div class="muted">${f(ae(h,n))}</div>
        <div class="sess-id" title="${f(a.device)}">${f(a.device)}${a.device.length>=8?"\u2026":""}</div>
        <div class="sess-profile">${er(c===A?a.device:c)} ${ta(a.os)} <span class="sess-host">${c===A?A:f(c)}</span></div>
        <div class="muted">${f(k)}</div>
        <div class="muted">${f(_)}</div>
        <div>${f(m)}</div>
      </div>`}).join("");return`<div class="seat-card" data-seat-table>
    ${r}${s}
    ${Xn()}
  </div>`}function la(e){return e.length?`<table><thead><tr><th>Computer</th><th>SSO email</th><th>License</th><th>OS</th><th>Version</th></tr></thead><tbody>${e.map(n=>`<tr>
        <td>${se(n.hostname)}</td>
        <td>${se(n.email)}</td>
        <td>${se(n.license)}</td>
        <td class="muted">${f(n.os)}</td>
        <td class="muted">${f(n.appVersion)}</td>
      </tr>`).join("")}</tbody></table>`:'<div class="empty">No seats on the fleet yet.</div>'}function tr(e){let t=e.kpis,n=e.ops,r=m=>m==="failed"||m==="expired",s=e.crm.rows.map(m=>{let y=m.remoteUrl?`<a href="${f(m.remoteUrl)}" rel="noreferrer">${f(m.remoteId||"open")}</a>`:m.remoteId?f(m.remoteId):"",S=r(m.status)?`<button data-retry="${f(m.id)}">Retry</button>`:m.retryRequested?'<span class="muted">retry asked</span>':"";return`<tr data-status="${f(m.status)}">
        <td>${st(m.status)}</td>
        <td>${f(m.title)}${m.error?`<div class="muted">${f(m.error)}</div>`:""}</td>
        <td class="muted">${f(m.connector)}${m.action?` \xB7 ${f(m.action)}`:""}</td>
        <td class="muted remote">${y}</td>
        <td class="muted">${m.attempt||""}</td>
        <td class="muted">${f(m.meetingHash||"")}</td>
        <td class="muted">${f(Me(m.ts))}</td>
        <td>${S}</td>
      </tr>`}).join(""),a=ln.map(m=>`<button class="tab" data-crm-filter="${m}" type="button">${st(m)} ${e.crm.counts[m]}</button>`).join(""),o=e.keys.vault.map(m=>`<tr data-key="${f(m.id)}">
        <td>${f(m.provider)}</td>
        <td>${f(m.label)}</td>
        <td class="muted">\xB7\xB7${f(m.last4)}</td>
        <td>${f(m.status)}</td>
        <td>${m.status==="revoked"?"":`<button data-rotate="${f(m.id)}">Rotate</button>`}</td>
        <td>${m.status==="revoked"?"":`<button class="danger" data-revoke="${f(m.id)}">Revoke</button>`}</td>
      </tr>`).join(""),L=[...e.crm.rows.map(m=>{let y=e.profiles.find(S=>m.device&&S.device===m.device);return`<tr data-status="${f(m.status)}" data-nt-row>
        <td>${f(m.title)}</td>
        <td class="muted">${f(m.connector)}</td>
        <td class="muted">${f(y?.country||A)}</td>
        <td class="muted">${f(y?.os||A)}</td>
        <td class="muted">${A}</td>
        <td class="muted">${se(y?.hostname||y?.email)}</td>
        <td class="muted">${f(ae(m.ts,e.now))}</td>
      </tr>`}),...e.proposals.filter(m=>m.status==="pending"||m.status==="draft").map(m=>`<tr data-status="${f(m.status)}" data-nt-row>
        <td>${f(m.skill_id)} ${f(m.status)}</td>
        <td class="muted">skill</td>
        <td class="muted">${A}</td>
        <td class="muted">${A}</td>
        <td class="muted">${A}</td>
        <td class="muted">${se(m.created_by)}</td>
        <td class="muted">${f(ae(m.created_at,e.now))}</td>
      </tr>`)].join(""),c=n.live30,p=n.live30Series,u=$n(e.map.countries,e.map.dots),l=e.profiles.filter(m=>m.live30),d=new Map;for(let m of l){let y=m.country&&!b(m.country)?m.country.trim().toUpperCase():"";if(!y&&!(m.city&&!b(m.city)))continue;let S=y||"(Not set)",C=y?`${dt(y)} ${Se(y)||y}`:"(Not set)",R=d.get(S);R?(R.views+=1,R.sess+=1):d.set(S,{name:C,views:1,sess:1})}let g=[...d.values()].sort((m,y)=>y.views-m.views),h=e.events.filter(m=>m.name==="heartbeat").slice(0,24),k=c?[{name:"(Not set)",views:c,sess:c}]:[],_=ra(h.map(m=>({label:m.name,value:1})));return`<!doctype html>
<html lang="en" data-theme="light"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>M\xE9tis Operator</title>
<link rel="stylesheet" href="${we}">
<script src="${re}" defer></script>
</head>
<body>
<svg id="spark-defs"><defs>
  <linearGradient id="spark-fill" x1="0" x2="0" y1="0" y2="1">
    <stop offset="0" stop-color="#2563EB" stop-opacity="0.28"/>
    <stop offset="1" stop-color="#2563EB" stop-opacity="0"/>
  </linearGradient>
  <linearGradient id="shoey-fill" x1="0" x2="0" y1="0" y2="1">
    <stop offset="0" stop-color="#2563EB" stop-opacity="0.22"/>
    <stop offset="1" stop-color="#2563EB" stop-opacity="0"/>
  </linearGradient>
</defs></svg>
<div class="shell">
  <aside class="rail">
    <div class="rail-brand">
      <span class="rail-logo">M</span>
      <h1>M\xE9tis</h1>
      <span class="chev">\u25BE</span>
    </div>
    ${Gs()}
    <div class="rail-foot">
      <div class="rail-utils">
        <a href="#notifications">Give feedback</a>
        <a href="#settings">Docs</a>
        <form method="post" action="/logout"><button type="submit">Back to workspace</button></form>
      </div>
      <div class="who">${f(e.email)}</div>
      <button class="theme-btn" id="theme-btn" type="button">Theme</button>
    </div>
  </aside>
  <div class="main">
    <header class="top">
      <div class="top-left">
        <button class="tool" type="button">Last 7 days</button>
        <button class="tool" type="button">Day</button>
        <button class="tool" type="button">Filters</button>
      </div>
      <input class="top-search" type="search" placeholder='Try: "last 7 days, seats only"' autocomplete="off">
      <div class="top-right">
        <span class="live-dot"><i></i>${c}</span>
        <button class="tool" type="button">Private</button>
      </div>
      <h2 id="page-title" hidden>Overview</h2>
    </header>

    <section class="page wrap" data-page="overview">
      ${Hn(e)}
      <article class="card" style="padding-bottom:10px" data-cf-overview>
        <p class="eyebrow">Cloudflare</p>
        ${jn(e.cloudflare)}
      </article>
    </section>

    <section class="page wrap" data-page="realtime" hidden>
      <div class="page-hero" data-map-dashboard>
        <h3 class="page-title">Map and dashboard</h3>
        <p class="page-sub">Users per countries and live seats from heartbeats. Map dots are Cloudflare request.cf only.</p>
      </div>
      <div class="rt-grid">
        <div>
          <article class="card kpi rt-unique" style="padding-bottom:10px">
            <h3 class="rt-h">Unique seats last 30 min</h3>
            <div class="n rt-n">${Ws(c)}</div>
            ${rt(p,280,56)}
          </article>
          <article class="card" style="padding:8px 10px 10px;margin-top:10px">
            <div class="rt-stream" id="rt-stream">
              ${h.length?h.map(m=>{let y=b(m.name)?"event":m.name,S=e.now-m.ts<9e4?"just now":Me(m.ts),C=m.chips.find(R=>R.key==="os")?.value||"";return`<div class="rt-row">
                          <span>${f(y)}<span class="rt-ics">${ft(C)}</span></span>
                          <span class="ago">${f(S)}</span>
                        </div>`}).join(""):'<div class="empty">No live events yet.</div>'}
            </div>
          </article>
        </div>
        <article class="card rt-map" style="padding:0;overflow:hidden">
          <div id="map-root" data-land="inline" style="position:relative">${u}</div>
        </article>
      </div>
      <div class="grid-3">
        ${ut("geo",[{id:"geo",label:"Users per countries"}],{geo:g},"Search countries",{value:"Events",sess:"Sessions"},"blue")}
        ${ut("rt-refs",[{id:"refs",label:"Referrals"}],{refs:k},"Search referrals",{value:"Events",sess:"Sessions"},"blue")}
        ${ut("rt-paths",[{id:"path",label:"Paths"}],{path:_},"Search paths",{value:"Events",sess:"Sessions"},"blue")}
      </div>
    </section>

    <section class="page wrap" data-page="events" hidden>
      <div class="page-hero">
        <h3 class="page-title">Events</h3>
        <p class="page-sub">Paginate through your events, conversions and overall stats</p>
      </div>
      <div class="page-tabs" role="tablist">
        <button class="page-tab on" type="button" data-ev-tab="events">Events</button>
        <button class="page-tab" type="button" data-ev-tab="conversions">Conversions</button>
        <button class="page-tab" type="button" data-ev-tab="stats">Stats</button>
      </div>
      <div class="page-toolbar">
        <span class="listen-pill" data-live-events="${e.events.length}"><i></i>Listening</span>
        <button class="tool" type="button">Date range</button>
        <button class="tool" type="button" id="events-filters">${Jn()} Filters</button>
        <label class="search-wrap">
          ${pt()}
          <input class="table-search toolbar-search" id="events-search" type="search" placeholder="Search ..." autocomplete="off">
        </label>
        <button class="tool page-view" type="button">${mt()} View</button>
      </div>
      <article class="card ev-table-card table-frame" data-ev-pane="events" style="padding-bottom:10px">
        <div id="events-list">${Gn(e.events,e.now)}</div>
        <div class="empty" id="events-empty" hidden>${W("No events match that search.")}</div>
      </article>
      <article class="card table-frame" data-ev-pane="conversions" hidden>
        ${e.events.some(m=>/^ask$/i.test(m.name))?Gn(e.events.filter(m=>/^ask$/i.test(m.name)),e.now):W("No Asks yet. Heartbeats stay on Events.")}
      </article>
      <article class="card table-frame" data-ev-pane="stats" hidden>
        ${sa(e.events)}
      </article>
    </section>

    <section class="page wrap" data-page="sessions" hidden>
      <div class="page-hero">
        <h3 class="page-title">Sessions</h3>
        <p class="page-sub">Access all your sessions here. Live M\xE9tis seats only \u2014 no sample rows.</p>
      </div>
      <div class="page-toolbar">
        <label class="search-wrap">
          ${pt()}
          <input class="table-search toolbar-search" id="sessions-search" type="search" placeholder="Search ..." autocomplete="off">
        </label>
        <button class="tool" type="button" id="sessions-filters">${Jn()} Filters</button>
        <button class="tool page-view" type="button">${mt()} View</button>
      </div>
      ${oa(e.profiles,e.events,e.now)}
      <div class="empty" id="sessions-empty" hidden>No sessions match that search.</div>
    </section>

    <section class="page wrap" data-page="notifications" hidden>
      <div class="page-hero nt-head">
        <h3 class="page-title">Notifications</h3>
        <p class="page-sub nt-sub">See notifications and manage your rules when to get notifications</p>
      </div>
      <div class="page-tabs underline" role="tablist">
        <button class="page-tab on" type="button" data-nt-tab="notifications">Notifications</button>
        <button class="page-tab" type="button" data-nt-tab="rules">Rules</button>
      </div>
      <div class="page-toolbar">
        <label class="search-wrap">
          ${pt()}
          <input class="table-search toolbar-search" id="nt-search" type="search" placeholder="Search ..." autocomplete="off">
        </label>
        <button class="tool" type="button">Created at</button>
        <button class="tool page-view" type="button">${mt()} View</button>
      </div>
      <div data-nt-pane="notifications">
        <div class="tabs" id="crm-filters">
          <button class="tab on" data-crm-filter="all">All ${e.crm.rows.length}</button>
          ${a}
        </div>
        <article class="card table-frame" style="padding-bottom:10px">
          <table id="nt-table">
            <thead><tr><th>Title</th><th>Integration</th><th>Country</th><th>OS</th><th>Browser</th><th>Profile</th><th>Created at</th></tr></thead>
            <tbody>
              ${L||""}
              <tr data-nt-empty ${L?"hidden":""}><td colspan="7">${W()}</td></tr>
            </tbody>
          </table>
          ${s?`<table id="crm-table" hidden><thead><tr><th>Status</th><th>Title</th><th>Connector</th><th>Remote</th><th>Try</th><th>Meeting</th><th>When</th><th></th></tr></thead><tbody>${s}</tbody></table>`:""}
        </article>
      </div>
      <div data-nt-pane="rules" hidden>
        <article class="card table-frame">${W("No rules yet.")}</article>
      </div>
    </section>

    <section class="page wrap" data-page="map" hidden data-alias="realtime"></section>

    <section class="page wrap" data-page="keys" hidden>
      <article class="card" style="padding-bottom:10px">
        <p class="eyebrow">Keys</p>
        <div class="sub muted" style="padding-bottom:8px">Tony adds LLM APIs and Cloudflare here. last4 only. Never a secret, cipher, token, or grant. CLI tokens stay on the seat.</div>
        <table>
          <thead><tr><th>Binding</th><th>Status</th></tr></thead>
          <tbody>
            <tr><td>Ingest HMAC</td><td>${e.keys.ingestBound?"bound":"missing"}</td></tr>
            <tr><td>Prompt key</td><td>${e.keys.promptBound?"bound":"missing"}</td></tr>
            <tr><td>Skill signing</td><td>${e.keys.skillBound?"bound":"missing"}</td></tr>
            <tr><td>Vault key</td><td>${e.keys.vaultBound?"bound":"missing"}</td></tr>
          </tbody>
        </table>
        <p class="eyebrow" style="margin-top:14px">Add an API</p>
        <form class="key-form" id="key-add" autocomplete="off">
          <div class="row">
            <select name="provider" required>
              <option value="anthropic">Anthropic</option>
              <option value="openai">OpenAI</option>
              <option value="gemini">Gemini</option>
              <option value="nvidia">NVIDIA NIM</option>
              <option value="deepseek">DeepSeek</option>
              <option value="minimax">MiniMax</option>
              <option value="qwen">Qwen</option>
              <option value="kimi">Kimi</option>
              <option value="openrouter">OpenRouter</option>
              <option value="groq">Groq</option>
              <option value="mistral">Mistral</option>
              <option value="grok">Grok</option>
              <option value="custom">Custom</option>
            </select>
            <input name="label" type="text" placeholder="Label" maxlength="80">
            <input name="secret" type="password" placeholder="API key" required autocomplete="off">
            <button class="primary" type="submit">Add</button>
          </div>
        </form>
        <p class="eyebrow">Cloudflare connection</p>
        <div class="sub muted" style="padding-bottom:8px">Login redirect. Not Account ID + token paste. Seats never hold a Cloudflare token.</div>
        <p><a class="btn primary" id="cf-connect" href="/cloudflare/connect">Connect Cloudflare</a></p>
        <p class="eyebrow" style="margin-top:14px">Vault</p>
        <table id="vault-table">
          <thead><tr><th>Provider</th><th>Label</th><th>Last4</th><th>Status</th><th>Rotate</th><th>Revoke</th></tr></thead>
          <tbody>
            ${o||'<tr data-vault-empty><td colspan="6" class="empty">No provider keys on Operator yet. Add an API. Rotate and Revoke land on each row. Seats never hold the raw key.</td></tr>'}
          </tbody>
        </table>
        <div id="key-msg" class="key-msg" role="status"></div>
      </article>
    </section>

    <section class="page wrap" data-page="settings" hidden>
      <article class="card" style="padding-bottom:10px">
        <p class="eyebrow">Settings</p>
        <div class="sub muted" style="padding-bottom:8px">Keys fund seats. Add an API once. last4 only. Heartbeats list fundedProviders. Seats never hold the raw key.</div>
        <p class="eyebrow" style="margin-top:14px">Add an API</p>
        <form class="key-form" id="key-add-settings" autocomplete="off">
          <div class="row">
            <select name="provider" required>
              <option value="anthropic">Anthropic</option>
              <option value="openai">OpenAI</option>
              <option value="gemini">Gemini</option>
              <option value="nvidia">NVIDIA NIM</option>
              <option value="deepseek">DeepSeek</option>
              <option value="minimax">MiniMax</option>
            </select>
            <input name="label" type="text" placeholder="Label" maxlength="80">
            <input name="secret" type="password" placeholder="API key" required autocomplete="off">
            <button class="primary" type="submit">Add</button>
          </div>
        </form>
        <div id="key-msg-settings" class="key-msg" role="status"></div>
        <p><a href="#keys">Open Keys</a> for rotate / revoke and Cloudflare.</p>
      </article>
      <article class="card" style="padding-bottom:10px" data-cf-page>
        <p class="eyebrow">Cloudflare</p>
        ${jn(e.cloudflare)}
      </article>
    </section>
  </div>
</div>
</body></html>`}var ie={anthropic:{id:"anthropic",label:"Claude \xB7 Anthropic",blurb:"The models M\xE9tis is built and tuned for by default.",kind:"anthropic",tier:"featured",baseUrl:"",models:["claude-opus-4-8","claude-sonnet-4-6","claude-haiku-4-5-20251001"],defaultModel:"claude-opus-4-8",fastModel:"claude-haiku-4-5-20251001",thinkModel:"claude-sonnet-4-6",deepModel:"claude-opus-4-8",keyHint:"sk-ant-\u2026",keyPattern:"^sk-ant-",vision:!0,keyUrl:"https://console.anthropic.com/settings/keys"},openai:{id:"openai",label:"GPT \xB7 OpenAI",blurb:"Strong general models with wide tool support.",kind:"openai",tier:"featured",baseUrl:"https://api.openai.com/v1",models:["gpt-4o","gpt-4o-mini","gpt-4.1","gpt-4.1-mini","o4-mini"],defaultModel:"gpt-4o",fastModel:"gpt-4o-mini",keyHint:"sk-\u2026",keyPattern:"",vision:!0,keyUrl:"https://platform.openai.com/api-keys"},nvidia:{id:"nvidia",freeTier:!0,label:"NVIDIA \xB7 NIM",blurb:"Open-weight models hosted on NVIDIA infrastructure, including DeepSeek R1.",kind:"openai",tier:"featured",baseUrl:"https://integrate.api.nvidia.com/v1",models:["meta/llama-3.3-70b-instruct","meta/llama-3.1-8b-instruct","deepseek-ai/deepseek-r1","qwen/qwen2.5-coder-32b-instruct","nvidia/llama-3.1-nemotron-70b-instruct"],defaultModel:"meta/llama-3.3-70b-instruct",fastModel:"meta/llama-3.1-8b-instruct",thinkModel:"deepseek-ai/deepseek-r1",keyHint:"nvapi-\u2026",keyPattern:"^nvapi-",vision:!1,keyUrl:"https://build.nvidia.com/"},deepseek:{id:"deepseek",label:"DeepSeek",blurb:"Very cheap million-token models; V4 Flash is the low-cost default for everyday use.",kind:"openai",tier:"featured",baseUrl:"https://api.deepseek.com/v1",models:["deepseek-v4-flash","deepseek-v4-pro"],defaultModel:"deepseek-v4-flash",fastModel:"deepseek-v4-flash",thinkModel:"deepseek-v4-pro",deepModel:"deepseek-v4-pro",keyHint:"sk-\u2026",keyPattern:"",vision:!1,keyUrl:"https://platform.deepseek.com/api_keys"},qwen:{id:"qwen",label:"Qwen \xB7 Alibaba",blurb:"Alibaba's models, strong at Chinese-language and vision tasks.",kind:"openai",tier:"more",baseUrl:"https://dashscope-intl.aliyuncs.com/compatible-mode/v1",models:["qwen-max","qwen-plus","qwen-turbo","qwen-vl-max"],defaultModel:"qwen-plus",fastModel:"qwen-turbo",keyHint:"sk-\u2026",keyPattern:"",vision:!1,keyUrl:"https://bailian.console.alibabacloud.com/"},minimax:{id:"minimax",label:"MiniMax",blurb:"A China-market model family with a generous free tier.",kind:"openai",tier:"featured",baseUrl:"https://api.minimax.io/v1",models:["MiniMax-Text-01","abab6.5s-chat"],defaultModel:"MiniMax-Text-01",fastModel:"abab6.5s-chat",keyHint:"eyJ\u2026 (JWT)",keyPattern:"^eyJ",vision:!1,keyUrl:"https://www.minimax.io/platform/user-center/basic-information"},kimi:{id:"kimi",label:"Kimi \xB7 Code (K2.7)",blurb:"A coding-focused reasoning model built for agentic, multi-step work.",kind:"openai",tier:"featured",baseUrl:"https://api.kimi.com/coding/v1",models:["kimi-for-coding"],defaultModel:"kimi-for-coding",fastModel:"kimi-for-coding",thinkModel:"kimi-for-coding",keyHint:"sk-kimi-\u2026",keyPattern:"^sk-kimi-",vision:!0,keyUrl:"https://www.kimi.com/code/docs/en/"},openrouter:{id:"openrouter",freeTier:!0,label:"OpenRouter",blurb:"One key routes to dozens of models from every major lab.",kind:"openai",tier:"more",baseUrl:"https://openrouter.ai/api/v1",models:["openai/gpt-4o-mini","anthropic/claude-sonnet-5","meta-llama/llama-3.3-70b-instruct","deepseek/deepseek-v4-flash","google/gemini-2.0-flash-001"],defaultModel:"openai/gpt-4o-mini",fastModel:"openai/gpt-4o-mini",keyHint:"sk-or-\u2026",keyPattern:"^sk-or-",vision:!0,keyUrl:"https://openrouter.ai/keys"},groq:{id:"groq",freeTier:!0,label:"Groq",blurb:"The fastest responses, great for live meetings.",kind:"openai",tier:"more",baseUrl:"https://api.groq.com/openai/v1",models:["llama-3.3-70b-versatile","llama-3.1-8b-instant","moonshotai/kimi-k2-instruct"],defaultModel:"llama-3.3-70b-versatile",fastModel:"llama-3.1-8b-instant",keyHint:"gsk_\u2026",keyPattern:"^gsk_",vision:!1,keyUrl:"https://console.groq.com/keys"},mistral:{id:"mistral",freeTier:!0,label:"Mistral",blurb:"European-hosted models, useful where data residency matters.",kind:"openai",tier:"more",baseUrl:"https://api.mistral.ai/v1",models:["mistral-large-latest","mistral-small-latest","pixtral-large-latest"],defaultModel:"mistral-large-latest",fastModel:"mistral-small-latest",keyHint:"API key",keyPattern:"",vision:!1,keyUrl:"https://console.mistral.ai/api-keys"},grok:{id:"grok",label:"Grok \xB7 xAI",blurb:"xAI's models, with real-time knowledge from X.",kind:"openai",tier:"more",baseUrl:"https://api.x.ai/v1",models:["grok-4","grok-3","grok-3-mini"],defaultModel:"grok-4",fastModel:"grok-3-mini",thinkModel:"grok-4",keyHint:"xai-\u2026",keyPattern:"^xai-",vision:!0,keyUrl:"https://console.x.ai/"},dust:{id:"dust",label:"Dust \xB7 your agents",blurb:"Your own Second Brain agents \u2014 the deepest integration with your meeting history.",kind:"dust",tier:"more",baseUrl:"https://dust.tt",models:[],defaultModel:"",fastModel:"",keyHint:"sk-\u2026 (Dust API key)",keyPattern:"",vision:!1,keyUrl:"https://docs.dust.tt/reference/developer-platform-overview"},"claude-cli":{id:"claude-cli",label:"Claude Code \xB7 CLI",blurb:"Routes through your existing Claude Code subscription, no separate API key.",kind:"cli",tier:"cli",baseUrl:"",models:["sonnet","opus","haiku"],defaultModel:"sonnet",fastModel:"haiku",thinkModel:"sonnet",deepModel:"opus",keyHint:"",keyPattern:"",vision:!1,keyUrl:""},"codex-cli":{id:"codex-cli",label:"Codex \xB7 OpenAI CLI",blurb:"Routes through your existing ChatGPT or OpenAI Codex CLI subscription.",kind:"cli",tier:"cli",baseUrl:"",models:[],defaultModel:"",fastModel:"",thinkModel:"",keyHint:"",keyPattern:"",vision:!1,keyUrl:""},gemini:{id:"gemini",freeTier:!0,label:"Gemini \xB7 Google",blurb:"Google's models with a very large context window.",kind:"openai",tier:"more",baseUrl:"https://generativelanguage.googleapis.com/v1beta/openai/",models:["gemini-2.5-flash","gemini-2.5-pro","gemini-2.0-flash"],defaultModel:"gemini-2.5-flash",fastModel:"gemini-2.5-flash",thinkModel:"gemini-2.5-pro",keyHint:"AIza\u2026",keyPattern:"^AIza",vision:!0,keyUrl:"https://aistudio.google.com/apikey"},cloudflare:{id:"cloudflare",label:"Cloudflare \xB7 AI Gateway",blurb:"Your company's own Cloudflare Worker \u2014 one endpoint reaching Workers AI, OpenAI, Anthropic and Google.",kind:"openai",tier:"featured",baseUrl:"",models:["@cf/meta/llama-4-scout-17b-16e-instruct","@cf/meta/llama-3.3-70b-instruct-fp8-fast","@cf/openai/gpt-oss-120b"],defaultModel:"@cf/meta/llama-4-scout-17b-16e-instruct",fastModel:"@cf/meta/llama-4-scout-17b-16e-instruct",thinkModel:"@cf/meta/llama-3.3-70b-instruct-fp8-fast",deepModel:"@cf/openai/gpt-oss-120b",keyHint:"METIS_PROXY_KEY from your operator",keyPattern:"",vision:!0,keyUrl:""},local:{id:"local",label:"M\xE9tis Local \xB7 on-device",blurb:"Runs a small Qwen model on this machine \u2014 instant, free, private; handles live suggestions, summaries and screenshots.",kind:"local",tier:"featured",baseUrl:"",models:["qwen3.5-0.8b"],defaultModel:"qwen3.5-0.8b",fastModel:"qwen3.5-0.8b",keyHint:"",keyPattern:"",vision:!0,keyUrl:""},custom:{id:"custom",label:"Custom \xB7 OpenAI-compatible",blurb:"Point at any OpenAI-compatible endpoint you already run.",kind:"openai",tier:"more",baseUrl:"",models:[],defaultModel:"",fastModel:"",keyHint:"API key",keyPattern:"",vision:!1,keyUrl:""}},Vi=Object.keys(ie);function nr(e){return e==="custom"||e==="cloudflare"}var La=32e3,ca=16e3,da=20,ua=64e3,pa="https://api.anthropic.com/v1/messages";function sr(e,t=200){return new Response(JSON.stringify(e),{status:t,headers:{"content-type":"application/json; charset=utf-8"}})}function H(e,t){return sr({ok:!1,error:e},t)}function gt(e,t){return e.length<=t?e:e.slice(0,t)}function rr(e){let t=e.toLowerCase();return t.includes("data:image/")||t.includes('"type":"image"')||t.includes('"image_url"')||t.includes('"source":{"type":"base64"')}function ma(e){let t;try{t=JSON.parse(e)}catch{return{ok:!1,error:"invalid json",status:400}}if(!t||typeof t!="object")return{ok:!1,error:"invalid json",status:400};let n=t;if(n.image!=null||n.vision===!0||n.mode==="vision")return{ok:!1,error:"screenshots are not accepted on Operator use",status:400};let r=typeof n.provider=="string"?n.provider.trim():"",s=typeof n.model=="string"?n.model.trim():"";if(!r||!s)return{ok:!1,error:"provider and model required",status:400};if(b(r)||b(s))return{ok:!1,error:"provider not allowed",status:400};if(he(r)||!ze(r)||r==="custom")return{ok:!1,error:"provider not allowed",status:400};if(r in ie&&nr(r))return{ok:!1,error:"provider not allowed",status:400};let a=typeof n.system=="string"?gt(n.system,La):"";if(rr(a))return{ok:!1,error:"screenshots are not accepted on Operator use",status:400};if(!Array.isArray(n.messages)||n.messages.length===0)return{ok:!1,error:"messages required",status:400};let o=[];for(let p of n.messages.slice(0,da)){if(!p||typeof p!="object")continue;let u=p,l=u.role==="assistant"?"assistant":u.role==="user"?"user":"",d=typeof u.content=="string"?gt(u.content,ca):"";if(!(!l||!d)){if(rr(d))return{ok:!1,error:"screenshots are not accepted on Operator use",status:400};o.push({role:l,content:d})}}if(!o.length)return{ok:!1,error:"messages required",status:400};let L=typeof n.temperature=="number"&&Number.isFinite(n.temperature)?n.temperature:void 0,c=typeof n.maxTokens=="number"&&Number.isFinite(n.maxTokens)?Math.min(8192,Math.max(16,Math.floor(n.maxTokens))):void 0;return{ok:!0,req:{provider:r,model:s,system:a,messages:o,temperature:L,maxTokens:c}}}async function fa(e,t,n){let s=(await e.listVaultRows()).find(a=>a.provider===n&&a.status==="active");if(!s)return null;try{let a=ee(await Q(s.cipher,s.iv,t));return a.secret?{secret:a.secret,row:s}:null}catch{return null}}function ga(e,t,n){return{ok:!0,text:gt(e,ua),...typeof t=="number"?{inputTokens:t}:{},...typeof n=="number"?{outputTokens:n}:{}}}function ha(e){if(!e||typeof e!="object")return null;let t=e,r=(Array.isArray(t.content)?t.content:[]).map(s=>s&&typeof s=="object"&&s.type==="text"?String(s.text??""):"").join("").trim();return r?{text:r,inputTokens:typeof t.usage?.input_tokens=="number"?t.usage.input_tokens:void 0,outputTokens:typeof t.usage?.output_tokens=="number"?t.usage.output_tokens:void 0}:null}function va(e){if(!e||typeof e!="object")return null;let t=e,n=typeof t.choices?.[0]?.message?.content=="string"?t.choices[0].message.content.trim():"";return n?{text:n,inputTokens:typeof t.usage?.prompt_tokens=="number"?t.usage.prompt_tokens:void 0,outputTokens:typeof t.usage?.completion_tokens=="number"?t.usage.completion_tokens:void 0}:null}async function ba(e,t,n){let r=await n(pa,{method:"POST",headers:{"content-type":"application/json","x-api-key":e,"anthropic-version":"2023-06-01"},body:JSON.stringify({model:t.model,max_tokens:t.maxTokens??4096,...typeof t.temperature=="number"?{temperature:t.temperature}:{},...t.system?{system:t.system}:{},messages:t.messages})});if(!r.ok)return{ok:!1,error:"provider refused the Operator key",status:502};let s=ha(await r.json().catch(()=>null));return s||{ok:!1,error:"provider returned an empty answer",status:502}}async function ya(e,t,n,r){let s=n.replace(/\/$/,""),a=s.endsWith("/chat/completions")?s:`${s}/chat/completions`,o=[...t.system?[{role:"system",content:t.system}]:[],...t.messages],L=await r(a,{method:"POST",headers:{"content-type":"application/json",authorization:`Bearer ${e}`},body:JSON.stringify({model:t.model,messages:o,...typeof t.temperature=="number"?{temperature:t.temperature}:{},...t.maxTokens?{max_tokens:t.maxTokens}:{}})});if(!L.ok)return{ok:!1,error:"provider refused the Operator key",status:502};let c=va(await L.json().catch(()=>null));return c||{ok:!1,error:"provider returned an empty answer",status:502}}async function ar(e,t,n,r,s,a=fetch){if(!t.OPERATOR_VAULT_KEY)return H("Operator cannot issue a use",503);let o=ma(r);if(!o.ok)return H(o.error,o.status);let L=await fa(e,t.OPERATOR_VAULT_KEY,o.req.provider);if(!L)return H("Operator cannot issue a use",503);let c=o.req.provider in ie?ie[o.req.provider]:null;if(!c||c.kind==="cli"||c.kind==="dust"||c.kind==="local")return H("provider not allowed",400);let p;try{p=c.kind==="anthropic"?await ba(L.secret,o.req,a):await ya(L.secret,o.req,c.baseUrl,a)}catch{return H("Operator cannot issue a use",503)}if("ok"in p&&p.ok===!1)return H(p.error,p.status);let u=ga(p.text,p.inputTokens,p.outputTokens),l=JSON.stringify(u);return l.includes(L.secret)||l.includes(L.row.cipher)||l.includes(L.row.iv)?H("Operator cannot issue a use",503):(await e.audit(crypto.randomUUID(),s,n,"use",null,o.req.provider),await e.insertEvent({id:crypto.randomUUID(),ts:s,kind:"use",actor:n,device_id:n,country:null,detail:`use ${o.req.provider}`}),sr(u))}var ka=6e4,xa=90;function x(e,t=200){return new Response(JSON.stringify(e),{status:t,headers:{"content-type":"application/json; charset=utf-8"}})}function wa(e){return new Response(e,{headers:{"content-type":"text/html; charset=utf-8"}})}function _a(e,t){return t?`${t} ask`:"Ask"}async function Sa(e,t,n,r={}){let s=new URL(e.url),a=r.store??(t.DB?kn(t.DB):yn()),o=r.now??Date.now(),L=r.access?{access:r.access}:n;if(s.pathname==="/health")return x({ok:!0,service:"metis-operator",configured:!!(t.OPERATOR_INGEST_SECRET&&t.OPERATOR_PROMPT_KEY)});if(Un(s.pathname))return Bn(s.pathname)??x({ok:!1,error:"not found"},404);if(s.pathname==="/logout"&&e.method==="POST")return new Response(null,{status:303,headers:{Location:"/","Set-Cookie":zt()}});if(Ve(s.pathname)||Ke(s.pathname)){let c=await Jt(e,L,t,o);if(c.status==="misconfigured")return je(c.error);if(c.status==="ok"){let p=await Ma(e,s,t,a,c.email,o,r),u=t.OPERATOR_PROMPT_KEY?.trim();if(!u)return p;let l=await Wt(c.email,o,u),d=new Headers(p.headers);return d.append("Set-Cookie",Yt(l)),d.set("X-Metis-Session",l),s.pathname==="/session"?(d.set("content-type","application/json; charset=utf-8"),new Response(JSON.stringify({ok:!0,session:l}),{status:200,headers:d})):new Response(p.body,{status:p.status,headers:d})}return c.status==="denied"||Ke(s.pathname)||e.method!=="GET"?Xt():jt(e,t)}if(s.pathname==="/v1/ingest"||s.pathname==="/v1/heartbeat"||s.pathname==="/v1/skills/manifest"||s.pathname==="/v1/use"){let c=e.method==="GET"?"":await e.text(),p=await Vt(e,c,t.OPERATOR_INGEST_SECRET,o,l=>a.takeNonce(l,o));if(!p.ok)return x({ok:!1,error:p.error},p.status);if(await a.hitRate(p.deviceId,o,ka,xa))return x({ok:!1,error:"rate limited"},429);let u=r.geo??bn(e);return s.pathname==="/v1/heartbeat"?Ra(a,p.deviceId,c,o,u):s.pathname==="/v1/skills/manifest"?Pa(a):s.pathname==="/v1/use"?e.method!=="POST"?x({ok:!1,error:"method not allowed"},405):ar(a,t,p.deviceId,c,o,r.providerFetch??r.cfFetch??fetch):Ca(a,t,p.deviceId,c,o,u)}return x({ok:!1,error:"not found"},404)}async function Ma(e,t,n,r,s,a,o={}){if(Ve(t.pathname)&&e.method==="GET"){if(t.pathname==="/session")return x({ok:!0});if(t.pathname==="/cloudflare/connect")return Qt(e);if(t.pathname==="/cloudflare/callback")return en();let d=await ke(r,s,a,ht(n),await ir(r,n,o,a));return wa(tr(d))}if(t.pathname==="/v1/admin/dashboard"&&e.method==="GET")return x(or(await ke(r,s,a,ht(n),await ir(r,n,o,a))));if(t.pathname==="/v1/admin/keys"&&e.method==="GET")return x(or({ok:!0,...await xn(r,ht(n))}));if(t.pathname==="/v1/admin/keys"&&e.method==="POST"){let d=await e.json().catch(()=>({})),g=await _n(r,n,s,a,d);return g.ok?x(g):x({ok:!1,error:g.error},g.status)}let L=/^\/v1\/admin\/keys\/([^/]+)\/rotate$/.exec(t.pathname);if(L&&e.method==="POST"){let d=await e.json().catch(()=>({})),g=await Sn(r,n,s,a,L[1],d);return g.ok?x(g):x({ok:!1,error:g.error},g.status)}let c=/^\/v1\/admin\/keys\/([^/]+)\/revoke$/.exec(t.pathname);if(c&&e.method==="POST"){let d=await Mn(r,s,a,c[1]);return d.ok?x(d):x({ok:!1,error:d.error},d.status)}if(t.pathname==="/v1/admin/summary"&&e.method==="GET"){let d=await ke(r,s,a);return x({ok:!0,live:d.kpis.live,dau:d.kpis.dau,wau:d.kpis.wau,costToday:d.kpis.costToday,hitRate:d.kpis.cacheHit,pending:d.kpis.pendingDiffs})}if(t.pathname==="/v1/admin/asks"&&e.method==="GET"){let d=await r.listAsks(100);return x({ok:!0,asks:d.map(g=>({...g,prompt_cipher:void 0,prompt_iv:void 0,question:void 0}))})}let p=/^\/v1\/admin\/asks\/([^/]+)$/.exec(t.pathname);if(p&&e.method==="GET"){let d=await r.getAsk(p[1]);if(!d)return x({ok:!1,error:"not found"},404);let g="";return d.prompt_cipher&&d.prompt_iv&&(g=await Dt(d.prompt_cipher,d.prompt_iv,n.OPERATOR_PROMPT_KEY)),await r.audit(crypto.randomUUID(),a,s,"reveal",d.id,"ask text"),x({ok:!0,id:d.id,question:g})}if(t.pathname==="/v1/admin/skills/draft"&&e.method==="POST"){let g=(await e.json().catch(()=>({}))).skillId||"general",h=(await r.listAsks(80)).filter(y=>y.mode===g||y.skill_id===g),k=h.map(y=>y.preview||"").filter(Boolean).slice(0,8),_=h.find(y=>y.skill_version)?.skill_version||"1.1.0",m=crypto.randomUUID();return await r.putProposal({id:m,skill_id:g,from_version:_,evidence_json:JSON.stringify(k),diff:`# unified diff against ${g} v${_}
# Edit, then Approve. Push is a separate click.
`,rationale:k.length?`Clustered ${k.length} recent Asks in ${g}.`:`No recent Asks in ${g} yet. Draft is a blank edit.`,status:"pending",created_by:s,created_at:a,decided_at:null,reject_reason:null}),await r.audit(crypto.randomUUID(),a,s,"draft",null,g),x({ok:!0,id:m})}let u=/^\/v1\/admin\/skills\/([^/]+)\/(approve|reject|push)$/.exec(t.pathname);if(u&&e.method==="POST"){let d=u[1],g=u[2],h=await r.getProposal(d);if(!h)return x({ok:!1,error:"not found"},404);let k=await e.json().catch(()=>({}));if(g==="reject")return await r.putProposal({...h,status:"rejected",reject_reason:k.reason||"rejected",decided_at:a}),await r.audit(crypto.randomUUID(),a,s,"reject",null,h.skill_id),x({ok:!0});if(g==="approve")return await r.putProposal({...h,status:"approved",diff:typeof k.diff=="string"?k.diff:h.diff,decided_at:a}),await r.audit(crypto.randomUUID(),a,s,"approve",null,h.skill_id),x({ok:!0,pushed:!1});if(h.status!=="approved")return x({ok:!1,error:"approve first"},400);if(!n.OPERATOR_SKILL_PRIVATE_KEY)return x({ok:!1,error:"skill signing key missing"},500);let _=Aa(h.from_version),m=Ea(h.skill_id,_,k.body||h.diff),y=await ue(m),S=await Ht({skillId:h.skill_id,version:_,sha256:y,body:m},n.OPERATOR_SKILL_PRIVATE_KEY);return await r.putPack({id:crypto.randomUUID(),skill_id:h.skill_id,version:_,sha256:y,body:m,signed:S,pushed_at:a,pushed_by:s}),await r.putProposal({...h,status:"pushed",decided_at:a}),await r.audit(crypto.randomUUID(),a,s,"push",null,`${h.skill_id}@${_}`),x({ok:!0,pushed:!0,version:_,signed:S})}let l=/^\/v1\/admin\/crm\/([^/]+)\/retry$/.exec(t.pathname);if(l&&e.method==="POST"){let d=await r.getCrm(l[1]);return d?d.status!=="failed"&&d.status!=="expired"?x({ok:!1,error:"only Failed or Expired can retry"},400):(await r.upsertCrm({...d,status:"pending",retry_requested:1,ts:a}),await r.audit(crypto.randomUUID(),a,s,"crm-retry",null,d.id),x({ok:!0,autoSend:!1})):x({ok:!1,error:"not found"},404)}return x({ok:!1,error:"not found"},404)}function Aa(e){let t=/^(\d+)\.(\d+)\.(\d+)$/.exec(e);return t?`${t[1]}.${t[2]}.${Number(t[3])+1}`:"1.0.1"}function Ea(e,t,n){let r=n.replace(/\r\n/g,`
`).trim();return r.startsWith("---")?r.replace(/^version:\s*.*$/m,`version: ${t}`):`---
id: ${e}
version: ${t}
locked: true
---

${r}
`}async function Ra(e,t,n,r,s){let a=n?JSON.parse(n):{},o=oe(t,a,r,s);await e.upsertSeat(o);let L=crypto.randomUUID();await e.insertPulse({id:L,device_id:t,ts:r,kind:"heartbeat",country:s.country,city:s.city}),await e.insertEvent({id:L,ts:r,kind:"heartbeat",actor:o.sso_email,device_id:t,country:s.country,detail:le([o.os,typeof a.path=="string"?a.path:"/"].filter(Boolean).join(" "))}),await Oa(e,t,a,r);let c=await e.listCrmRetries(t);return x({ok:!0,retry:c.map(p=>p.id),fundedProviders:await An(e)})}async function Ca(e,t,n,r,s,a){let o=JSON.parse(r||"{}"),L=String(o.id||crypto.randomUUID());if(o.event==="rating"){await e.updateAskRating(L,String(o.rating||""));let h=oe(n,o,s,a);return await e.insertEvent({id:crypto.randomUUID(),ts:s,kind:"rating",actor:h.sso_email,device_id:n,country:a.country,detail:le(String(o.rating||"rating"))}),x({ok:!0})}if(o.event==="listen"||o.event==="recap"){let h=oe(n,o,s,a),k=B(o.minutes);return await e.insertEvent({id:L,ts:s,kind:o.event,actor:h.sso_email,device_id:n,country:a.country,detail:le(k!=null?`${k}m`:String(o.event))}),await e.upsertSeat(h),x({ok:!0,id:L})}if(o.event==="crm"){if(o.confidential===!0)return x({ok:!0,id:L,ingested:!1});await lr(e,n,o,s);let h=oe(n,o,s,a);return await e.insertEvent({id:crypto.randomUUID(),ts:s,kind:"crm",actor:h.sso_email,device_id:n,country:a.country,detail:le(String(o.status||o.connector||"crm"))}),x({ok:!0,id:L})}let c=null,p=null,u=typeof o.question=="string"?o.question:"";if(u){let h=await Bt(u,t.OPERATOR_PROMPT_KEY);c=h.cipher,p=h.iv}let l={id:L,device_id:n,ts:typeof o.ts=="number"?o.ts:s,mode:I(o.mode),skill_id:I(o.skillId),skill_version:I(o.skillVersion),provider:I(o.provider),model:I(o.model),ttft_ms:B(o.ttftMs),total_ms:B(o.totalMs),input_tokens:B(o.inputTokens),output_tokens:B(o.outputTokens),cache_read:B(o.cacheRead),cache_write:B(o.cacheWrite),cache_uncached:B(o.cacheUncached),cache_status:I(o.cacheStatus),cache_ttl:I(o.cacheTtl),outcome:I(o.outcome),rating:I(o.rating),prompt_cipher:c,prompt_iv:p,preview:_a(u,I(o.mode)??void 0)};await e.insertAsk(l);let d=crypto.randomUUID();await e.insertPulse({id:d,device_id:n,ts:l.ts,kind:"ask",country:a.country,city:a.city});let g=oe(n,o,s,a);return await e.upsertSeat(g),await e.insertEvent({id:d,ts:l.ts,kind:"ask",actor:g.sso_email,device_id:n,country:a.country,detail:le(l.mode||l.cache_status||"ask")}),x({ok:!0,id:L})}async function Pa(e){let t=await e.latestPacks();return x({ok:!0,skills:t.map(n=>({skillId:n.skill_id,version:n.version,sha256:n.sha256,signed:n.signed}))})}function $a(e){return typeof e.lastIndexAt=="number"&&Number.isFinite(e.lastIndexAt)?e.lastIndexAt:null}function oe(e,t,n,r){return{device_id:e,seat_hash:String(t.seatHash||e),os:typeof t.os=="string"&&t.os.trim()&&t.os!=="unknown"?t.os.trim():"",app_version:typeof t.appVersion=="string"?t.appVersion.trim():"",first_seen:n,last_seen:n,country:r.country,city:r.city,lat:r.lat,lon:r.lon,last_index_at:$a(t),hostname:Ot(t.hostname),sso_email:It(t.ssoEmail),license:typeof t.license=="string"&&!b(t.license)?t.license.slice(0,32):null}}function le(e){if(!e)return null;let t=e.trim().slice(0,48);return!t||b(t)?null:t}function ht(e){return{ingestBound:!!e.OPERATOR_INGEST_SECRET,promptBound:!!e.OPERATOR_PROMPT_KEY,skillBound:!!e.OPERATOR_SKILL_PRIVATE_KEY,vaultBound:!!e.OPERATOR_VAULT_KEY}}async function ir(e,t,n,r){let s=await En(e,t.OPERATOR_VAULT_KEY);if(!s)return D();try{return await an({accountId:s.accountId,token:s.token,now:r,fetchImpl:n.cfFetch})}catch{return{...D(),connected:!0,error:"Cloudflare pull failed."}}}function Ta(e){if(typeof e.meetingHash=="string"&&/^[a-f0-9]{16,64}$/i.test(e.meetingHash.trim()))return e.meetingHash.trim().toLowerCase().slice(0,16);if(typeof e.meetingFile=="string"){let t=e.meetingFile.replace(/^.*[/\\]/,"").trim();if(!t)return null;if(/^[a-f0-9]{16,64}$/i.test(t))return t.toLowerCase().slice(0,16)}return null}async function lr(e,t,n,r){if(n.confidential===!0)return;let s=Je(n.status);if(!s)return;let a=String(n.id||crypto.randomUUID()),o=typeof n.title=="string"?n.title.replace(/\s+/g," ").trim().slice(0,160):"CRM send",L=typeof n.connector=="string"?n.connector.slice(0,32):"unknown",c=typeof n.error=="string"?n.error.slice(0,200):null,p=typeof n.remoteId=="string"?n.remoteId.slice(0,80):null,u=typeof n.remoteUrl=="string"&&/^https:\/\//i.test(n.remoteUrl)?n.remoteUrl.slice(0,300):null,l=typeof n.action=="string"?n.action.slice(0,32):null,d=typeof n.attempt=="number"&&Number.isFinite(n.attempt)?Math.max(0,Math.floor(n.attempt)):0,g=typeof n.latencyMs=="number"&&Number.isFinite(n.latencyMs)?Math.max(0,Math.floor(n.latencyMs)):0,h=await e.getCrm(a);await e.upsertCrm({id:a,device_id:t,ts:typeof n.ts=="number"?n.ts:r,status:s,title:o||"CRM send",connector:L,meeting_file:null,meeting_hash:Ta(n)??h?.meeting_hash??null,last_error:c,retry_requested:0,attempt:d||h?.attempt||0,latency_ms:g||h?.latency_ms||0,remote_id:p??h?.remote_id??null,remote_url:u??h?.remote_url??null,action:l??h?.action??null})}async function Oa(e,t,n,r){if(Array.isArray(n.crm))for(let s of n.crm.slice(0,40))!s||typeof s!="object"||await lr(e,t,s,r)}function or(e){return JSON.parse(JSON.stringify(e,(t,n)=>{if(!(t==="prompt_cipher"||t==="prompt_iv"||t==="question"||t==="ip"||t==="cipher"||t==="iv"||t==="secret"||t==="token"||t==="grant"))return n}))}function I(e){return typeof e=="string"&&e?e:null}function B(e){return typeof e=="number"&&Number.isFinite(e)?e:null}var mo={async fetch(e,t,n){return Sa(e,t,n)}};export{Kt as ADMIN_EMAILS,mo as default,Sa as handleRequest};
